/**
 * Authentication Middleware for Bot Command Center
 * Protects routes and manages session validation
 */

import { secureAuth } from '../emailAuth.js';

/**
 * Get client IP address considering proxies
 */
function getClientIP(req) {
  return req.ip || 
         req.connection.remoteAddress || 
         req.socket.remoteAddress ||
         (req.connection.socket ? req.connection.socket.remoteAddress : null) ||
         '127.0.0.1';
}

/**
 * Middleware to require authentication
 * Validates session and ensures user is authenticated
 */
export function requireAuth(req, res, next) {
  // Check if session exists and has authentication data
  if (!req.session || !req.session.authenticated || !req.session.sessionToken) {
    return res.status(401).json({
      success: false,
      message: 'Authentication required. Please log in.',
      code: 'AUTH_REQUIRED',
      redirectTo: '/login'
    });
  }

  // Verify session is still valid with the auth system
  const verification = secureAuth.verifySession(req.session.sessionToken);
  
  if (!verification.valid) {
    // Invalid or expired session, clear it
    req.session.authenticated = false;
    req.session.user = null;
    req.session.sessionToken = null;
    
    return res.status(401).json({
      success: false,
      message: verification.message || 'Session invalid or expired.',
      code: 'SESSION_INVALID',
      redirectTo: '/login'
    });
  }

  // Add user information to request object
  req.user = verification.user;
  req.authSession = verification.session;
  
  next();
}

/**
 * Middleware to check authentication status without blocking
 * Adds user info to request if authenticated, but doesn't block access
 */
export function checkAuth(req, res, next) {
  if (req.session?.authenticated && req.session?.sessionToken) {
    const verification = secureAuth.verifySession(req.session.sessionToken);
    
    if (verification.valid) {
      req.user = verification.user;
      req.authSession = verification.session;
      req.isAuthenticated = true;
    } else {
      // Clear invalid session data
      req.session.authenticated = false;
      req.session.user = null;
      req.session.sessionToken = null;
      req.isAuthenticated = false;
    }
  } else {
    req.isAuthenticated = false;
  }
  
  next();
}

/**
 * Middleware to log all authentication attempts and security events
 */
export function authLogger(req, res, next) {
  const ip = getClientIP(req);
  const userAgent = req.get('User-Agent') || 'Unknown';
  const timestamp = new Date().toISOString();
  
  // Log authentication-related requests
  if (req.path.startsWith('/api/auth/')) {
    const logData = {
      method: req.method,
      path: req.path,
      ip,
      userAgent,
      timestamp,
      body: req.method === 'POST' ? { ...req.body, password: '[REDACTED]' } : undefined
    };
    
    console.log('Auth Request:', JSON.stringify(logData, null, 2));
  }
  
  next();
}

/**
 * Middleware to validate session consistency
 * Ensures session IP hasn't changed (helps prevent session hijacking)
 */
export function validateSessionConsistency(req, res, next) {
  if (req.session?.authenticated && req.authSession) {
    const currentIP = getClientIP(req);
    const sessionIP = req.authSession.ip;
    
    // Allow localhost variations
    const isLocalhost = (ip) => 
      ip === '127.0.0.1' || 
      ip === '::1' || 
      ip === 'localhost' || 
      ip === '::ffff:127.0.0.1';
    
    if (!isLocalhost(currentIP) && !isLocalhost(sessionIP) && currentIP !== sessionIP) {
      // IP mismatch detected - potential session hijacking
      secureAuth.log('warn', 'Session IP mismatch detected', {
        sessionIP,
        currentIP,
        userAgent: req.get('User-Agent'),
        sessionToken: req.session.sessionToken?.substring(0, 8) + '...'
      });
      
      // Revoke session for security
      secureAuth.logout(req.session.sessionToken);
      req.session.destroy();
      
      return res.status(401).json({
        success: false,
        message: 'Security violation: Session IP mismatch detected.',
        code: 'SESSION_SECURITY_VIOLATION',
        redirectTo: '/login'
      });
    }
  }
  
  next();
}

/**
 * Middleware to check if admin is accessing from whitelisted IP
 */
export function requireWhitelistedIP(req, res, next) {
  const ip = getClientIP(req);
  
  if (!secureAuth.isIPWhitelisted(ip)) {
    secureAuth.log('warn', 'Non-whitelisted IP attempted to access protected resource', {
      ip,
      path: req.path,
      userAgent: req.get('User-Agent')
    });
    
    return res.status(403).json({
      success: false,
      message: 'Access denied. Your IP address is not authorized.',
      code: 'IP_NOT_WHITELISTED'
    });
  }
  
  next();
}

/**
 * Combined authentication middleware for protected dashboard routes
 * Includes all security checks
 */
export function protectDashboard(req, res, next) {
  // Check whitelisted IP first
  requireWhitelistedIP(req, res, (err) => {
    if (err) return next(err);
    
    // Then check authentication
    requireAuth(req, res, (err) => {
      if (err) return next(err);
      
      // Then validate session consistency
      validateSessionConsistency(req, res, next);
    });
  });
}

/**
 * Middleware to add security headers
 */
export function addSecurityHeaders(req, res, next) {
  // Prevent clickjacking
  res.setHeader('X-Frame-Options', 'DENY');
  
  // Prevent MIME type sniffing
  res.setHeader('X-Content-Type-Options', 'nosniff');
  
  // Enable XSS protection
  res.setHeader('X-XSS-Protection', '1; mode=block');
  
  // Strict transport security (HTTPS only)
  if (req.secure || req.get('x-forwarded-proto') === 'https') {
    res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
  }
  
  // Content Security Policy
  res.setHeader('Content-Security-Policy', 
    "default-src 'self'; " +
    "script-src 'self' 'unsafe-inline' 'unsafe-eval'; " +
    "style-src 'self' 'unsafe-inline'; " +
    "img-src 'self' data: https:; " +
    "font-src 'self' data:; " +
    "connect-src 'self'; " +
    "frame-ancestors 'none';"
  );
  
  next();
}

export default {
  requireAuth,
  checkAuth,
  authLogger,
  validateSessionConsistency,
  requireWhitelistedIP,
  protectDashboard,
  addSecurityHeaders
};