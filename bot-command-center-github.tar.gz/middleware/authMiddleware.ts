/**
 * Authentication Middleware for Bot Command Center
 * Protects routes and manages session validation
 */

import { Request, Response, NextFunction } from 'express';
import { secureAuth } from '../emailAuth';

/**
 * Get client IP address considering proxies
 */
function getClientIP(req: Request): string {
  return req.ip || 
         req.connection?.remoteAddress || 
         (req.socket as any)?.remoteAddress ||
         '127.0.0.1';
}

/**
 * Middleware to require authentication
 * Validates session and ensures user is authenticated
 */
export function requireAuth(req: Request, res: Response, next: NextFunction) {
  // Check if session exists and has authentication data
  if (!(req.session as any) || !(req.session as any).authenticated || !(req.session as any).sessionToken) {
    return res.status(401).json({
      success: false,
      message: 'Authentication required. Please log in.',
      code: 'AUTH_REQUIRED',
      redirectTo: '/login'
    });
  }

  // Verify session is still valid with the auth system
  const verification = secureAuth.verifySession((req.session as any).sessionToken);
  
  if (!verification.valid) {
    // Invalid or expired session, clear it
    (req.session as any).authenticated = false;
    (req.session as any).user = null;
    (req.session as any).sessionToken = null;
    
    return res.status(401).json({
      success: false,
      message: verification.message || 'Session invalid or expired.',
      code: 'SESSION_INVALID',
      redirectTo: '/login'
    });
  }

  // Add user information to request object
  (req as any).user = verification.user;
  (req as any).authSession = verification.session;
  
  next();
}

/**
 * Middleware to check authentication status without blocking
 * Adds user info to request if authenticated, but doesn't block access
 */
export function checkAuth(req: Request, res: Response, next: NextFunction) {
  if ((req.session as any)?.authenticated && (req.session as any)?.sessionToken) {
    const verification = secureAuth.verifySession((req.session as any).sessionToken);
    
    if (verification.valid) {
      (req as any).user = verification.user;
      (req as any).authSession = verification.session;
      (req as any).isAuthenticated = true;
    } else {
      // Clear invalid session data
      (req.session as any).authenticated = false;
      (req.session as any).user = null;
      (req.session as any).sessionToken = null;
      (req as any).isAuthenticated = false;
    }
  } else {
    (req as any).isAuthenticated = false;
  }
  
  next();
}

/**
 * Middleware to log all authentication attempts and security events
 */
export function authLogger(req: Request, res: Response, next: NextFunction) {
  const ip = getClientIP(req);
  const userAgent = req.get('User-Agent') || 'Unknown';
  const timestamp = new Date().toISOString();
  
  // Log authentication-related requests
  if (req.path.startsWith('/api/auth/')) {
    const logData = {
      method: req.method,
      path: req.path,
      ip,
      userAgent,
      timestamp,
      body: req.method === 'POST' ? { ...req.body, password: '[REDACTED]' } : undefined
    };
    
    console.log('Auth Request:', JSON.stringify(logData, null, 2));
  }
  
  next();
}

/**
 * Middleware to validate session consistency
 * Ensures session IP hasn't changed (helps prevent session hijacking)
 */
export function validateSessionConsistency(req: Request, res: Response, next: NextFunction) {
  if ((req.session as any)?.authenticated && (req as any).authSession) {
    const currentIP = getClientIP(req);
    const sessionIP = (req as any).authSession.ip;
    
    // Allow localhost variations
    const isLocalhost = (ip: string) => 
      ip === '127.0.0.1' || 
      ip === '::1' || 
      ip === 'localhost' || 
      ip === '::ffff:127.0.0.1';
    
    if (!isLocalhost(currentIP) && !isLocalhost(sessionIP) && currentIP !== sessionIP) {
      // IP mismatch detected - potential session hijacking
      secureAuth.log('warn', 'Session IP mismatch detected', {
        sessionIP,
        currentIP,
        userAgent: req.get('User-Agent'),
        sessionToken: (req.session as any).sessionToken?.substring(0, 8) + '...'
      });
      
      // Revoke session for security
      secureAuth.logout((req.session as any).sessionToken);
      req.session = null;
      
      return res.status(401).json({
        success: false,
        message: 'Security violation: Session IP mismatch detected.',
        code: 'SESSION_SECURITY_VIOLATION',
        redirectTo: '/login'
      });
    }
  }
  
  next();
}

/**
 * Middleware to check if admin is accessing from whitelisted IP
 */
export function requireWhitelistedIP(req: Request, res: Response, next: NextFunction) {
  const ip = getClientIP(req);
  
  if (!secureAuth.isIPWhitelisted(ip)) {
    secureAuth.log('warn', 'Non-whitelisted IP attempted to access protected resource', {
      ip,
      path: req.path,
      userAgent: req.get('User-Agent')
    });
    
    return res.status(403).json({
      success: false,
      message: 'Access denied. Your IP address is not authorized.',
      code: 'IP_NOT_WHITELISTED'
    });
  }
  
  next();
}

/**
 * Combined authentication middleware for protected dashboard routes
 * Includes all security checks
 */
export function protectDashboard(req: Request, res: Response, next: NextFunction) {
  // Check whitelisted IP first
  requireWhitelistedIP(req, res, (err) => {
    if (err) return next(err);
    
    // Then check authentication
    requireAuth(req, res, (err) => {
      if (err) return next(err);
      
      // Then validate session consistency
      validateSessionConsistency(req, res, next);
    });
  });
}

/**
 * Middleware to add security headers
 */
export function addSecurityHeaders(req: Request, res: Response, next: NextFunction) {
  // Prevent clickjacking
  res.setHeader('X-Frame-Options', 'DENY');
  
  // Prevent MIME type sniffing
  res.setHeader('X-Content-Type-Options', 'nosniff');
  
  // Enable XSS protection
  res.setHeader('X-XSS-Protection', '1; mode=block');
  
  // Strict transport security (HTTPS only)
  if (req.secure || req.get('x-forwarded-proto') === 'https') {
    res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
  }
  
  // Content Security Policy
  res.setHeader('Content-Security-Policy', 
    "default-src 'self'; " +
    "script-src 'self' 'unsafe-inline' 'unsafe-eval'; " +
    "style-src 'self' 'unsafe-inline'; " +
    "img-src 'self' data: https:; " +
    "font-src 'self' data:; " +
    "connect-src 'self'; " +
    "frame-ancestors 'none';"
  );
  
  next();
}

export default {
  requireAuth,
  checkAuth,
  authLogger,
  validateSessionConsistency,
  requireWhitelistedIP,
  protectDashboard,
  addSecurityHeaders
};