# Bot Command Center

A comprehensive AI-powered surplus and liquidation lead matching platform with intelligent bot management and remote connectivity solutions.

## Features

- **Live Bot Management**: Control Craigslist scraper bots via Ngrok integration
- **Real-time Dashboard**: Monitor bot performance and system metrics
- **GPT-4 Integration**: Lead enrichment and AOR generation
- **Supabase Database**: Lead storage and management
- **Mobile Responsive**: Full mobile phone compatibility
- **Secure Authentication**: 2FA email verification system

## Tech Stack

- **Frontend**: React + TypeScript + Vite
- **Backend**: Node.js + Express
- **Database**: Supabase PostgreSQL
- **Styling**: Tailwind CSS + shadcn/ui
- **AI**: OpenAI GPT-4 integration
- **Remote Control**: Ngrok tunnel connectivity

## Environment Variables

Create a `.env` file with:

```
DATABASE_URL=your_supabase_postgresql_url
VITE_NGROK_URL=https://your-ngrok-url.ngrok.io
VITE_BOT_TOKEN=your_secure_bot_token
OPENAI_API_KEY=your_openai_api_key
```

## Development

```bash
npm install
npm run dev
```

## Production Build

```bash
npm run build
npm start
```

## Deployment

This project is configured for deployment on:
- Railway
- Vercel
- Replit

See deployment configuration files:
- `railway.json`
- `vercel.json`
- `.replit`