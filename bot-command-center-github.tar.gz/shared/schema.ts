import { pgTable, text, integer, timestamp, boolean, serial, jsonb, decimal } from 'drizzle-orm/pg-core';
import { createInsertSchema, createSelectSchema } from 'drizzle-zod';
import { z } from 'zod';
import { relations } from 'drizzle-orm';

// Users table (admins and virtual assistants)
export const users = pgTable('users', {
  id: serial('id').primaryKey(),
  email: text('email').notNull().unique(),
  passwordHash: text('password_hash').notNull(),
  role: text('role').notNull().default('VA'), // 'admin' or 'VA'
  name: text('name').notNull(),
  company: text('company'),
  isActive: boolean('is_active').default(true),
  lastLogin: timestamp('last_login'),
  activeSession: boolean('active_session').default(false),
  whitelistedIPs: text('whitelisted_ips').array().default([]),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow()
});

// Subscriptions table
export const subscriptions = pgTable('subscriptions', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').references(() => users.id).notNull(),
  vertical: text('vertical').notNull(), // 'auto', 'real_estate', 'pets', etc
  city: text('city').notNull(),
  maxLeadsPerDay: integer('max_leads_per_day').default(50),
  pricePerLead: decimal('price_per_lead', { precision: 10, scale: 2 }).default('0.00'),
  isActive: boolean('is_active').default(true),
  botId: integer('bot_id').references(() => botInstances.id),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow()
});

// Bot instances table
export const botInstances = pgTable('bot_instances', {
  id: serial('id').primaryKey(),
  name: text('name').notNull(),
  city: text('city').notNull(),
  platform: text('platform').notNull(), // 'craigslist', 'offerup', 'facebook', 'reddit'
  vertical: text('vertical').notNull(), // 'auto', 'real_estate', 'pets'
  type: text('type').notNull(), // 'scraper', 'enrichment', 'outreach', 'matching'
  status: text('status').notNull().default('stopped'), // 'running', 'stopped', 'error'
  dailyCount: integer('daily_count').default(0),
  totalScraped: integer('total_scraped').default(0),
  successRate: decimal('success_rate', { precision: 5, scale: 2 }).default('0.00'),
  progress: integer('progress').default(0),
  version: text('version').default('1.0.0'),
  lastRun: timestamp('last_run'),
  config: jsonb('config'), // Lead targets, scheduling, etc
  gptPrompts: jsonb('gpt_prompts'), // Custom prompts per bot
  processId: integer('process_id'),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow()
});

// Activity logs table
export const activityLogs = pgTable('activity_logs', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').references(() => users.id),
  botId: integer('bot_id').references(() => botInstances.id),
  action: text('action').notNull(),
  status: text('status').notNull(), // 'success', 'error', 'warning'
  message: text('message'),
  ipAddress: text('ip_address'),
  userAgent: text('user_agent'),
  timestamp: timestamp('timestamp').defaultNow()
});

// Authentication sessions table
export const authSessions = pgTable('auth_sessions', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').references(() => users.id).notNull(),
  sessionToken: text('session_token').notNull().unique(),
  ipAddress: text('ip_address').notNull(),
  userAgent: text('user_agent'),
  isActive: boolean('is_active').default(true),
  expiresAt: timestamp('expires_at').notNull(),
  createdAt: timestamp('created_at').defaultNow()
});

// System metrics table
export const systemMetrics = pgTable('system_metrics', {
  id: serial('id').primaryKey(),
  metric: text('metric').notNull(), // 'openai_tokens', 'api_calls', 'cost_estimate'
  value: decimal('value', { precision: 12, scale: 4 }).notNull(),
  botId: integer('bot_id').references(() => botInstances.id),
  timestamp: timestamp('timestamp').defaultNow()
});

// Auto leads table
export const autoLeads = pgTable('auto_leads', {
  id: serial('id').primaryKey(),
  make: text('make'),
  model: text('model'),
  year: integer('year'),
  budget: text('budget'),
  contactName: text('contact_name'),
  contactPhone: text('contact_phone'),
  urgency: text('urgency').default('medium'),
  status: text('status').default('new'),
  createdAt: timestamp('created_at').defaultNow()
});

// Real estate leads table
export const realEstateLeads = pgTable('real_estate_leads', {
  id: serial('id').primaryKey(),
  propertyType: text('property_type').notNull(),
  zipCode: text('zip_code'),
  bedrooms: integer('bedrooms'),
  urgency: text('urgency').default('medium'),
  contactEmail: text('contact_email'),
  contactPhone: text('contact_phone'),
  status: text('status').default('new'),
  createdAt: timestamp('created_at').defaultNow()
});

// Pet leads table
export const petLeads = pgTable('pet_leads', {
  id: serial('id').primaryKey(),
  botId: integer('bot_id').references(() => botInstances.id),
  userId: integer('user_id').references(() => users.id),
  title: text('title').notNull(),
  price: decimal('price', { precision: 10, scale: 2 }),
  location: text('location'),
  breed: text('breed'),
  age: text('age'),
  description: text('description'),
  contactInfo: jsonb('contact_info'),
  images: text('images').array(),
  platform: text('platform').notNull(),
  originalUrl: text('original_url'),
  enrichedData: jsonb('enriched_data'),
  status: text('status').default('new'),
  createdAt: timestamp('created_at').defaultNow()
});

// Raw leads table - holds scraped data before enrichment
export const rawLeads = pgTable('raw_leads', {
  id: serial('id').primaryKey(),
  title: text('title').notNull(),
  description: text('description'),
  city: text('city').notNull(),
  datePosted: timestamp('date_posted'),
  gptStatus: text('gpt_status').default('pending'),
  contactName: text('contact_name'),
  contactEmail: text('contact_email'),
  contactPhone: text('contact_phone'),
  leadSource: text('lead_source').notNull(), // craigslist, facebook, etc
  createdAt: timestamp('created_at').defaultNow()
});

// Goods leads table - general merchandise leads
export const goodsLeads = pgTable('goods_leads', {
  id: serial('id').primaryKey(),
  productType: text('product_type').notNull(),
  quantity: integer('quantity'),
  buyerBudget: text('buyer_budget'),
  contactInfo: text('contact_info'),
  urgency: text('urgency').default('medium'),
  leadStatus: text('lead_status').notNull().default('new'),
  createdAt: timestamp('created_at').defaultNow()
});

// Hot leads table - qualified matches ready for action
export const hotLeads = pgTable('hot_leads', {
  id: serial('id').primaryKey(),
  leadTitle: text('lead_title').notNull(),
  buyerName: text('buyer_name'),
  vertical: text('vertical').notNull(), // auto, real_estate, goods
  buyerBudget: text('buyer_budget'),
  matchUrl: text('match_url'),
  currentPrice: text('current_price'),
  potentialProfit: text('potential_profit'),
  status: text('status').notNull().default('active'),
  aorUrl: text('AOR_url'), // Auction Opportunity Report URL
  createdAt: timestamp('created_at').defaultNow()
});

// Sessions table for login tracking and security audit
export const sessions = pgTable('sessions', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').references(() => users.id),
  timestamp: timestamp('timestamp').defaultNow(),
  ipAddress: text('ip_address'),
  action: text('action').notNull(), // login, logout, access
  createdAt: timestamp('created_at').defaultNow()
});

// GPT Prompts table for versioned prompt management
export const gptPrompts = pgTable('gpt_prompts', {
  id: serial('id').primaryKey(),
  vertical: text('vertical').notNull(), // 'auto', 'real_estate', 'pets'
  promptType: text('prompt_type').notNull(), // 'enrichment', 'outreach', 'matching'
  version: text('version').notNull().default('1.0.0'),
  prompt: text('prompt').notNull(),
  isActive: boolean('is_active').default(true),
  createdBy: integer('created_by').references(() => users.id),
  createdAt: timestamp('created_at').defaultNow()
});

// Bot Files table for file tree management
export const botFiles = pgTable('bot_files', {
  id: serial('id').primaryKey(),
  botId: integer('bot_id').references(() => botInstances.id),
  filePath: text('file_path').notNull(),
  fileName: text('file_name').notNull(),
  fileType: text('file_type').notNull(), // 'js', 'json', 'env', 'txt'
  content: text('content'),
  isProtected: boolean('is_protected').default(false),
  lastModified: timestamp('last_modified').defaultNow(),
  version: text('version').default('1.0.0'),
  createdAt: timestamp('created_at').defaultNow()
});

// File History table for version control
export const fileHistory = pgTable('file_history', {
  id: serial('id').primaryKey(),
  fileId: integer('file_id').references(() => botFiles.id),
  fileName: text('file_name').notNull(),
  content: text('content').notNull(),
  version: integer('version').notNull(),
  timestamp: timestamp('timestamp').defaultNow()
});

// Alerts table for health monitoring
export const alerts = pgTable('alerts', {
  id: serial('id').primaryKey(),
  botId: integer('bot_id').references(() => botInstances.id),
  alertType: text('alert_type').notNull(), // 'error', 'warning', 'info'
  title: text('title').notNull(),
  message: text('message').notNull(),
  severity: text('severity').notNull().default('medium'), // 'low', 'medium', 'high', 'critical'
  isResolved: boolean('is_resolved').default(false),
  slackSent: boolean('slack_sent').default(false),
  errorStack: text('error_stack'),
  suggestedAction: text('suggested_action'),
  createdAt: timestamp('created_at').defaultNow(),
  resolvedAt: timestamp('resolved_at')
});

// Command History table for AI assistant
export const commandHistory = pgTable('command_history', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').references(() => users.id),
  command: text('command').notNull(),
  interpretation: text('interpretation'),
  executed: boolean('executed').default(false),
  result: text('result'),
  createdAt: timestamp('created_at').defaultNow()
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  subscriptions: many(subscriptions),
  activityLogs: many(activityLogs),
  authSessions: many(authSessions),
  autoLeads: many(autoLeads),
  realEstateLeads: many(realEstateLeads),
  petLeads: many(petLeads),
}));

export const subscriptionsRelations = relations(subscriptions, ({ one }) => ({
  user: one(users, {
    fields: [subscriptions.userId],
    references: [users.id],
  }),
  bot: one(botInstances, {
    fields: [subscriptions.botId],
    references: [botInstances.id],
  }),
}));

export const botInstancesRelations = relations(botInstances, ({ many }) => ({
  subscriptions: many(subscriptions),
  activityLogs: many(activityLogs),
  systemMetrics: many(systemMetrics),
  autoLeads: many(autoLeads),
  realEstateLeads: many(realEstateLeads),
  petLeads: many(petLeads),
  botFiles: many(botFiles),
  alerts: many(alerts),
}));

export const gptPromptsRelations = relations(gptPrompts, ({ one }) => ({
  createdBy: one(users, {
    fields: [gptPrompts.createdBy],
    references: [users.id],
  }),
}));

export const botFilesRelations = relations(botFiles, ({ one, many }) => ({
  bot: one(botInstances, {
    fields: [botFiles.botId],
    references: [botInstances.id],
  }),
  history: many(fileHistory),
}));

export const fileHistoryRelations = relations(fileHistory, ({ one }) => ({
  file: one(botFiles, {
    fields: [fileHistory.fileId],
    references: [botFiles.id],
  }),
}));

export const alertsRelations = relations(alerts, ({ one }) => ({
  bot: one(botInstances, {
    fields: [alerts.botId],
    references: [botInstances.id],
  }),
}));

export const commandHistoryRelations = relations(commandHistory, ({ one }) => ({
  user: one(users, {
    fields: [commandHistory.userId],
    references: [users.id],
  }),
}));

// Export types
export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export type Subscription = typeof subscriptions.$inferSelect;
export type InsertSubscription = typeof subscriptions.$inferInsert;

export type BotInstance = typeof botInstances.$inferSelect;
export type InsertBotInstance = typeof botInstances.$inferInsert;

export type ActivityLog = typeof activityLogs.$inferSelect;
export type InsertActivityLog = typeof activityLogs.$inferInsert;

export type AuthSession = typeof authSessions.$inferSelect;
export type InsertAuthSession = typeof authSessions.$inferInsert;

export type SystemMetric = typeof systemMetrics.$inferSelect;
export type InsertSystemMetric = typeof systemMetrics.$inferInsert;

export type AutoLead = typeof autoLeads.$inferSelect;
export type InsertAutoLead = typeof autoLeads.$inferInsert;

export type RealEstateLead = typeof realEstateLeads.$inferSelect;
export type InsertRealEstateLead = typeof realEstateLeads.$inferInsert;

export type PetLead = typeof petLeads.$inferSelect;
export type InsertPetLead = typeof petLeads.$inferInsert;

export type GptPrompt = typeof gptPrompts.$inferSelect;
export type InsertGptPrompt = typeof gptPrompts.$inferInsert;

export type BotFile = typeof botFiles.$inferSelect;
export type InsertBotFile = typeof botFiles.$inferInsert;

export type FileHistory = typeof fileHistory.$inferSelect;
export type InsertFileHistory = typeof fileHistory.$inferInsert;

export type Alert = typeof alerts.$inferSelect;
export type InsertAlert = typeof alerts.$inferInsert;

export type CommandHistory = typeof commandHistory.$inferSelect;
export type InsertCommandHistory = typeof commandHistory.$inferInsert;

// Zod schemas for validation
export const insertUserSchema = createInsertSchema(users).omit({ id: true, createdAt: true, updatedAt: true });
export const insertSubscriptionSchema = createInsertSchema(subscriptions).omit({ id: true, createdAt: true, updatedAt: true });
export const insertBotInstanceSchema = createInsertSchema(botInstances).omit({ id: true, createdAt: true, updatedAt: true });
export const insertActivityLogSchema = createInsertSchema(activityLogs).omit({ id: true });
export const insertAuthSessionSchema = createInsertSchema(authSessions).omit({ id: true, createdAt: true });
export const insertSystemMetricSchema = createInsertSchema(systemMetrics).omit({ id: true });
export const insertAutoLeadSchema = createInsertSchema(autoLeads).omit({ id: true, createdAt: true });
export const insertRealEstateLeadSchema = createInsertSchema(realEstateLeads).omit({ id: true, createdAt: true });
export const insertPetLeadSchema = createInsertSchema(petLeads).omit({ id: true, createdAt: true });
export const insertGptPromptSchema = createInsertSchema(gptPrompts).omit({ id: true, createdAt: true });
export const insertBotFileSchema = createInsertSchema(botFiles).omit({ id: true, createdAt: true, lastModified: true });
export const insertAlertSchema = createInsertSchema(alerts).omit({ id: true, createdAt: true });
export const insertCommandHistorySchema = createInsertSchema(commandHistory).omit({ id: true, createdAt: true });