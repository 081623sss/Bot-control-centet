/**
 * Authentication Routes for Bot Command Center
 * Handles login, 2FA verification, logout, and security management
 */

import express, { Request, Response, NextFunction } from 'express';
import rateLimit from 'express-rate-limit';
import { secureAuth } from '../emailAuth';

const router = express.Router();

// Rate limiting for auth routes
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 10, // Maximum 10 attempts per IP per window
  message: {
    error: 'Too many authentication attempts. Please try again later.',
    code: 'RATE_LIMITED'
  },
  standardHeaders: true,
  legacyHeaders: false,
});

const strictAuthLimiter = rateLimit({
  windowMs: 5 * 60 * 1000, // 5 minutes
  max: 3, // Maximum 3 attempts per IP per window for sensitive operations
  message: {
    error: 'Too many attempts. Please try again later.',
    code: 'RATE_LIMITED'
  }
});

/**
 * Get client IP address considering proxies
 */
function getClientIP(req: Request): string {
  return req.ip || 
         req.connection?.remoteAddress || 
         (req.socket as any)?.remoteAddress ||
         '127.0.0.1';
}

/**
 * Get user agent
 */
function getUserAgent(req: Request): string {
  return req.get('User-Agent') || 'Unknown';
}

/**
 * POST /api/auth/login
 * Step 1: Verify email and password, send 2FA code
 */
router.post('/login', authLimiter, async (req: Request, res: Response) => {
  try {
    const { email, password } = req.body;
    
    // Input validation
    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: 'Email and password are required.',
        code: 'MISSING_FIELDS'
      });
    }

    const ip = getClientIP(req);
    const userAgent = getUserAgent(req);

    // Verify credentials and send 2FA code
    const result = await secureAuth.verifyCredentials(email, password, ip, userAgent);
    
    if (result.success) {
      // Check if this is development mode direct login (has sessionToken)
      if (result.sessionToken) {
        // Development mode - create session and redirect to dashboard
        (req.session as any).sessionToken = result.sessionToken;
        (req.session as any).authenticated = true;
        (req.session as any).user = {
          email,
          ip
        };
        
        res.status(200).json({
          success: true,
          message: result.message,
          sessionToken: result.sessionToken,
          authenticated: true
        });
      } else {
        // Normal 2FA flow
        // Store code ID in session for step 2
        (req.session as any).pendingAuth = {
          codeId: result.codeId,
          email,
          ip,
          timestamp: Date.now()
        };
        
        res.status(200).json({
          success: true,
          message: result.message,
          step: '2fa_required',
          expiresIn: result.expiresIn
        });
      }
    } else {
      res.status(401).json({
        success: false,
        message: result.message,
        code: result.code
      });
    }
    
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({
      success: false,
      message: 'Authentication service temporarily unavailable.',
      code: 'INTERNAL_ERROR'
    });
  }
});

/**
 * POST /api/auth/verify
 * Step 2: Verify 2FA code and create session
 */
router.post('/verify', strictAuthLimiter, async (req: Request, res: Response) => {
  try {
    const { code } = req.body;
    
    if (!code) {
      return res.status(400).json({
        success: false,
        message: 'Verification code is required.',
        code: 'MISSING_CODE'
      });
    }

    // Check if there's a pending auth session
    if (!(req.session as any).pendingAuth) {
      return res.status(400).json({
        success: false,
        message: 'No pending authentication. Please start the login process again.',
        code: 'NO_PENDING_AUTH'
      });
    }

    const { codeId, email, ip: sessionIP, timestamp } = (req.session as any).pendingAuth;
    const currentIP = getClientIP(req);
    
    // Verify IP consistency
    if (sessionIP !== currentIP) {
      (req.session as any).pendingAuth = null;
      return res.status(400).json({
        success: false,
        message: 'Security error: IP address mismatch.',
        code: 'IP_MISMATCH'
      });
    }

    // Check if pending auth is too old (10 minutes max)
    if (Date.now() - timestamp > 10 * 60 * 1000) {
      (req.session as any).pendingAuth = null;
      return res.status(400).json({
        success: false,
        message: 'Authentication session expired. Please start over.',
        code: 'AUTH_SESSION_EXPIRED'
      });
    }

    // Verify 2FA code
    const result = await secureAuth.verify2FACode(codeId, code, currentIP);
    
    if (result.success) {
      // Clear pending auth
      (req.session as any).pendingAuth = null;
      
      // Set session data
      (req.session as any).authenticated = true;
      (req.session as any).user = {
        id: 'admin',
        email: email,
        loginTime: new Date().toISOString()
      };
      (req.session as any).sessionToken = result.sessionToken;
      
      res.json({
        success: true,
        message: result.message,
        user: {
          id: 'admin',
          email: email
        },
        expiresAt: result.expiresAt
      });
    } else {
      res.status(401).json({
        success: false,
        message: result.message,
        code: result.code
      });
    }
    
  } catch (error) {
    console.error('Verification error:', error);
    res.status(500).json({
      success: false,
      message: 'Verification service temporarily unavailable.',
      code: 'INTERNAL_ERROR'
    });
  }
});

/**
 * POST /api/auth/logout
 * Logout and destroy session
 */
router.post('/logout', (req: Request, res: Response) => {
  try {
    const sessionToken = (req.session as any).sessionToken;
    
    if (sessionToken) {
      // Revoke session in auth system
      secureAuth.logout(sessionToken);
    }
    
    // Destroy session
    req.session = null;
    
    res.json({
      success: true,
      message: 'Logged out successfully.'
    });
    
  } catch (error) {
    console.error('Logout error:', error);
    res.status(500).json({
      success: false,
      message: 'Logout service temporarily unavailable.',
      code: 'INTERNAL_ERROR'
    });
  }
});

/**
 * GET /api/auth/status
 * Check authentication status
 */
router.get('/status', (req: Request, res: Response) => {
  try {
    // For development mode, trust the session flag without requiring token verification
    const isDevelopment = process.env.NODE_ENV === 'development';
    
    if (isDevelopment && (req.session as any)?.authenticated) {
      return res.json({
        authenticated: true,
        user: (req.session as any).user || { email: 'admin@supersmartstealz.com' },
        developmentMode: true
      });
    }

    if (!(req.session as any)?.authenticated || !(req.session as any)?.sessionToken) {
      return res.json({
        authenticated: false,
        message: 'Not authenticated'
      });
    }

    // Verify session with auth system
    const verification = secureAuth.verifySession((req.session as any).sessionToken);
    
    if (verification.valid) {
      res.json({
        authenticated: true,
        user: verification.user,
        session: {
          createdAt: verification.session.createdAt,
          expiresAt: verification.session.expiresAt
        }
      });
    } else {
      // Invalid session, clear it
      (req.session as any).authenticated = false;
      (req.session as any).user = null;
      (req.session as any).sessionToken = null;
      
      res.json({
        authenticated: false,
        message: verification.message
      });
    }
    
  } catch (error) {
    console.error('Status check error:', error);
    res.status(500).json({
      authenticated: false,
      message: 'Authentication status unavailable.'
    });
  }
});

/**
 * Middleware to require authentication
 */
function authRequired(req: Request, res: Response, next: NextFunction) {
  if (!(req.session as any)?.authenticated || !(req.session as any)?.sessionToken) {
    return res.status(401).json({
      success: false,
      message: 'Authentication required.',
      code: 'AUTH_REQUIRED'
    });
  }

  // Verify session is still valid
  const verification = secureAuth.verifySession((req.session as any).sessionToken);
  
  if (!verification.valid) {
    (req.session as any).authenticated = false;
    (req.session as any).user = null;
    (req.session as any).sessionToken = null;
    
    return res.status(401).json({
      success: false,
      message: 'Session invalid or expired.',
      code: 'SESSION_INVALID'
    });
  }

  (req as any).user = verification.user;
  next();
}

/**
 * GET /api/auth/security/sessions
 * Get active sessions (admin only)
 */
router.get('/security/sessions', authRequired, (req: Request, res: Response) => {
  try {
    const result = secureAuth.getActiveSessions();
    res.json(result);
  } catch (error) {
    console.error('Get sessions error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to retrieve sessions.'
    });
  }
});

/**
 * GET /api/auth/security/whitelist
 * Get whitelisted IPs (admin only)
 */
router.get('/security/whitelist', authRequired, (req: Request, res: Response) => {
  try {
    const ips = secureAuth.getWhitelistedIPs();
    res.json({
      success: true,
      whitelistedIPs: ips
    });
  } catch (error) {
    console.error('Get whitelist error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to retrieve whitelist.'
    });
  }
});

/**
 * POST /api/auth/security/whitelist
 * Add IP to whitelist (admin only)
 */
router.post('/security/whitelist', authRequired, (req: Request, res: Response) => {
  try {
    const { ip } = req.body;
    
    if (!ip) {
      return res.status(400).json({
        success: false,
        message: 'IP address is required.'
      });
    }

    const result = secureAuth.addWhitelistedIP(ip);
    res.json(result);
  } catch (error) {
    console.error('Add whitelist error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to add IP to whitelist.'
    });
  }
});

/**
 * DELETE /api/auth/security/whitelist/:ip
 * Remove IP from whitelist (admin only)
 */
router.delete('/security/whitelist/:ip', authRequired, (req: Request, res: Response) => {
  try {
    const { ip } = req.params;
    const result = secureAuth.removeWhitelistedIP(ip);
    res.json(result);
  } catch (error) {
    console.error('Remove whitelist error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to remove IP from whitelist.'
    });
  }
});

/**
 * PUT /api/auth/security/password
 * Change admin password (admin only)
 */
router.put('/security/password', authRequired, strictAuthLimiter, async (req: Request, res: Response) => {
  try {
    const { currentPassword, newPassword } = req.body;
    
    if (!currentPassword || !newPassword) {
      return res.status(400).json({
        success: false,
        message: 'Current password and new password are required.'
      });
    }

    const result = await secureAuth.changePassword(currentPassword, newPassword);
    
    if (result.success) {
      // Clear current session since all sessions are revoked
      req.session = null;
    }
    
    res.json(result);
  } catch (error) {
    console.error('Change password error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to change password.'
    });
  }
});

export { router as authRoutes, authRequired };
export default router;