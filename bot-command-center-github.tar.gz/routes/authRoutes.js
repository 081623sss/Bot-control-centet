/**
 * Authentication Routes for Bot Command Center
 * Handles login, 2FA verification, logout, and security management
 */

import express from 'express';
import rateLimit from 'express-rate-limit';
import { secureAuth } from '../emailAuth.js';

const router = express.Router();

// Rate limiting for auth routes
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 10, // Maximum 10 attempts per IP per window
  message: {
    error: 'Too many authentication attempts. Please try again later.',
    code: 'RATE_LIMITED'
  },
  standardHeaders: true,
  legacyHeaders: false,
});

const strictAuthLimiter = rateLimit({
  windowMs: 5 * 60 * 1000, // 5 minutes
  max: 3, // Maximum 3 attempts per IP per window for sensitive operations
  message: {
    error: 'Too many attempts. Please try again later.',
    code: 'RATE_LIMITED'
  }
});

/**
 * Get client IP address considering proxies
 */
function getClientIP(req) {
  return req.ip || 
         req.connection.remoteAddress || 
         req.socket.remoteAddress ||
         (req.connection.socket ? req.connection.socket.remoteAddress : null) ||
         '127.0.0.1';
}

/**
 * Get user agent
 */
function getUserAgent(req) {
  return req.get('User-Agent') || 'Unknown';
}

/**
 * POST /api/auth/login
 * Step 1: Verify email and password, send 2FA code
 */
router.post('/login', authLimiter, async (req, res) => {
  try {
    const { email, password } = req.body;
    
    // Input validation
    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: 'Email and password are required.',
        code: 'MISSING_FIELDS'
      });
    }

    const ip = getClientIP(req);
    const userAgent = getUserAgent(req);

    // Verify credentials and send 2FA code
    const result = await secureAuth.verifyCredentials(email, password, ip, userAgent);
    
    if (result.success) {
      // Store code ID in session for step 2
      req.session.pendingAuth = {
        codeId: result.codeId,
        email,
        ip,
        timestamp: Date.now()
      };
      
      res.status(200).json({
        success: true,
        message: result.message,
        step: '2fa_required',
        expiresIn: result.expiresIn
      });
    } else {
      res.status(401).json({
        success: false,
        message: result.message,
        code: result.code
      });
    }
    
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({
      success: false,
      message: 'Authentication service temporarily unavailable.',
      code: 'INTERNAL_ERROR'
    });
  }
});

/**
 * POST /api/auth/verify
 * Step 2: Verify 2FA code and create session
 */
router.post('/verify', strictAuthLimiter, async (req, res) => {
  try {
    const { code } = req.body;
    
    if (!code) {
      return res.status(400).json({
        success: false,
        message: 'Verification code is required.',
        code: 'MISSING_CODE'
      });
    }

    // Check if there's a pending auth session
    if (!req.session.pendingAuth) {
      return res.status(400).json({
        success: false,
        message: 'No pending authentication. Please start the login process again.',
        code: 'NO_PENDING_AUTH'
      });
    }

    const { codeId, email, ip: sessionIP, timestamp } = req.session.pendingAuth;
    const currentIP = getClientIP(req);
    
    // Verify IP consistency
    if (sessionIP !== currentIP) {
      req.session.pendingAuth = null;
      return res.status(400).json({
        success: false,
        message: 'Security error: IP address mismatch.',
        code: 'IP_MISMATCH'
      });
    }

    // Check if pending auth is too old (10 minutes max)
    if (Date.now() - timestamp > 10 * 60 * 1000) {
      req.session.pendingAuth = null;
      return res.status(400).json({
        success: false,
        message: 'Authentication session expired. Please start over.',
        code: 'AUTH_SESSION_EXPIRED'
      });
    }

    // Verify 2FA code
    const result = await secureAuth.verify2FACode(codeId, code, currentIP);
    
    if (result.success) {
      // Clear pending auth
      req.session.pendingAuth = null;
      
      // Set session data
      req.session.authenticated = true;
      req.session.user = {
        id: 'admin',
        email: email,
        loginTime: new Date().toISOString()
      };
      req.session.sessionToken = result.sessionToken;
      
      res.json({
        success: true,
        message: result.message,
        user: {
          id: 'admin',
          email: email
        },
        expiresAt: result.expiresAt
      });
    } else {
      res.status(401).json({
        success: false,
        message: result.message,
        code: result.code
      });
    }
    
  } catch (error) {
    console.error('Verification error:', error);
    res.status(500).json({
      success: false,
      message: 'Verification service temporarily unavailable.',
      code: 'INTERNAL_ERROR'
    });
  }
});

/**
 * POST /api/auth/logout
 * Logout and destroy session
 */
router.post('/logout', (req, res) => {
  try {
    const sessionToken = req.session.sessionToken;
    
    if (sessionToken) {
      // Revoke session in auth system
      secureAuth.logout(sessionToken);
    }
    
    // Destroy session
    req.session.destroy((err) => {
      if (err) {
        console.error('Session destruction error:', err);
        return res.status(500).json({
          success: false,
          message: 'Failed to logout properly.',
          code: 'LOGOUT_ERROR'
        });
      }
      
      res.json({
        success: true,
        message: 'Logged out successfully.'
      });
    });
    
  } catch (error) {
    console.error('Logout error:', error);
    res.status(500).json({
      success: false,
      message: 'Logout service temporarily unavailable.',
      code: 'INTERNAL_ERROR'
    });
  }
});

/**
 * GET /api/auth/status
 * Check authentication status
 */
router.get('/status', (req, res) => {
  try {
    if (!req.session.authenticated || !req.session.sessionToken) {
      return res.json({
        authenticated: false,
        message: 'Not authenticated'
      });
    }

    // Verify session with auth system
    const verification = secureAuth.verifySession(req.session.sessionToken);
    
    if (verification.valid) {
      res.json({
        authenticated: true,
        user: verification.user,
        session: {
          createdAt: verification.session.createdAt,
          expiresAt: verification.session.expiresAt
        }
      });
    } else {
      // Invalid session, clear it
      req.session.authenticated = false;
      req.session.user = null;
      req.session.sessionToken = null;
      
      res.json({
        authenticated: false,
        message: verification.message
      });
    }
    
  } catch (error) {
    console.error('Status check error:', error);
    res.status(500).json({
      authenticated: false,
      message: 'Authentication status unavailable.'
    });
  }
});

/**
 * Middleware to require authentication
 */
function authRequired(req, res, next) {
  if (!req.session.authenticated || !req.session.sessionToken) {
    return res.status(401).json({
      success: false,
      message: 'Authentication required.',
      code: 'AUTH_REQUIRED'
    });
  }

  // Verify session is still valid
  const verification = secureAuth.verifySession(req.session.sessionToken);
  
  if (!verification.valid) {
    req.session.authenticated = false;
    req.session.user = null;
    req.session.sessionToken = null;
    
    return res.status(401).json({
      success: false,
      message: 'Session invalid or expired.',
      code: 'SESSION_INVALID'
    });
  }

  req.user = verification.user;
  next();
}

/**
 * GET /api/auth/security/sessions
 * Get active sessions (admin only)
 */
router.get('/security/sessions', authRequired, (req, res) => {
  try {
    const result = secureAuth.getActiveSessions();
    res.json(result);
  } catch (error) {
    console.error('Get sessions error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to retrieve sessions.'
    });
  }
});

/**
 * DELETE /api/auth/security/sessions/:token
 * Revoke a specific session (admin only)
 */
router.delete('/security/sessions/:token', authRequired, (req, res) => {
  try {
    const { token } = req.params;
    const result = secureAuth.revokeSession(token);
    res.json(result);
  } catch (error) {
    console.error('Revoke session error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to revoke session.'
    });
  }
});

/**
 * GET /api/auth/security/whitelist
 * Get whitelisted IPs (admin only)
 */
router.get('/security/whitelist', authRequired, (req, res) => {
  try {
    const ips = secureAuth.getWhitelistedIPs();
    res.json({
      success: true,
      whitelistedIPs: ips
    });
  } catch (error) {
    console.error('Get whitelist error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to retrieve whitelist.'
    });
  }
});

/**
 * POST /api/auth/security/whitelist
 * Add IP to whitelist (admin only)
 */
router.post('/security/whitelist', authRequired, (req, res) => {
  try {
    const { ip } = req.body;
    
    if (!ip) {
      return res.status(400).json({
        success: false,
        message: 'IP address is required.'
      });
    }

    const result = secureAuth.addWhitelistedIP(ip);
    res.json(result);
  } catch (error) {
    console.error('Add whitelist error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to add IP to whitelist.'
    });
  }
});

/**
 * DELETE /api/auth/security/whitelist/:ip
 * Remove IP from whitelist (admin only)
 */
router.delete('/security/whitelist/:ip', authRequired, (req, res) => {
  try {
    const { ip } = req.params;
    const result = secureAuth.removeWhitelistedIP(ip);
    res.json(result);
  } catch (error) {
    console.error('Remove whitelist error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to remove IP from whitelist.'
    });
  }
});

/**
 * PUT /api/auth/security/password
 * Change admin password (admin only)
 */
router.put('/security/password', authRequired, strictAuthLimiter, async (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body;
    
    if (!currentPassword || !newPassword) {
      return res.status(400).json({
        success: false,
        message: 'Current password and new password are required.'
      });
    }

    const result = await secureAuth.changePassword(currentPassword, newPassword);
    
    if (result.success) {
      // Clear current session since all sessions are revoked
      req.session.destroy();
    }
    
    res.json(result);
  } catch (error) {
    console.error('Change password error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to change password.'
    });
  }
});

/**
 * GET /api/auth/security/logs
 * Get authentication logs (admin only)
 */
router.get('/security/logs', authRequired, (req, res) => {
  try {
    const { limit = 50 } = req.query;
    const result = secureAuth.getLoginLogs(parseInt(limit));
    res.json(result);
  } catch (error) {
    console.error('Get logs error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to retrieve logs.'
    });
  }
});

/**
 * GET /api/auth/security/stats
 * Get authentication statistics (admin only)
 */
router.get('/security/stats', authRequired, (req, res) => {
  try {
    const stats = secureAuth.getStats();
    res.json({
      success: true,
      stats
    });
  } catch (error) {
    console.error('Get stats error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to retrieve statistics.'
    });
  }
});

export { router as authRoutes, authRequired };
export default router;