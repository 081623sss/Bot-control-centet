import { QueryClient, QueryFunction } from "@tanstack/react-query";

// API Base URLs
const REPLIT_API_BASE = ''; // Local Replit server for auth
const TERMIUS_API_BASE = import.meta.env.VITE_API_BASE || 'https://f1e9-2600-3c0a-00-f03c-95ff.ngrok.io';

async function throwIfResNotOk(res: Response) {
  if (!res.ok) {
    const text = (await res.text()) || res.statusText;
    throw new Error(`${res.status}: ${text}`);
  }
}

// Determine which server to use based on endpoint
function getApiBase(url: string): string {
  // Authentication routes go to local Replit server
  if (url.startsWith('/api/auth')) {
    return REPLIT_API_BASE;
  }
  // Bot commands go to Termius server via Ngrok
  return TERMIUS_API_BASE;
}

export async function apiRequest(
  urlOrMethod: string,
  urlOrOptions?: string | RequestInit,
  data?: unknown | undefined,
): Promise<any> {
  let url: string;
  let options: RequestInit;

  // Support both old and new patterns
  if (typeof urlOrOptions === 'string') {
    // Old pattern: method, url, data
    url = urlOrOptions;
    options = {
      method: urlOrMethod,
      headers: data ? { "Content-Type": "application/json" } : {},
      body: data ? JSON.stringify(data) : undefined,
      credentials: "include",
    };
  } else {
    // New pattern: url, options
    url = urlOrMethod;
    options = {
      credentials: "include",
      ...urlOrOptions,
    };
  }

  // Build full URL with appropriate base
  const apiBase = getApiBase(url);
  const fullUrl = apiBase ? `${apiBase}${url}` : url;

  const res = await fetch(fullUrl, options);
  await throwIfResNotOk(res);
  return await res.json();
}

type UnauthorizedBehavior = "returnNull" | "throw";
export const getQueryFn: <T>(options: {
  on401: UnauthorizedBehavior;
}) => QueryFunction<T> =
  ({ on401: unauthorizedBehavior }) =>
  async ({ queryKey }) => {
    const url = queryKey[0] as string;
    const apiBase = getApiBase(url);
    const fullUrl = apiBase ? `${apiBase}${url}` : url;
    
    const res = await fetch(fullUrl, {
      credentials: "include",
    });

    if (unauthorizedBehavior === "returnNull" && res.status === 401) {
      return null;
    }

    await throwIfResNotOk(res);
    return await res.json();
  };

// Bot commands specifically for Termius server
export async function botCommand(bot: string, action: string, data?: any): Promise<any> {
  const url = `${TERMIUS_API_BASE}/bot-command`;
  
  const response = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      bot,
      action,
      ...data
    }),
  });
  
  if (!response.ok) {
    throw new Error(`Bot command failed: ${response.status} ${response.statusText}`);
  }
  
  return await response.json();
}

// Check connection status for each bot
export async function checkBotConnection(bot: string): Promise<boolean> {
  try {
    const response = await fetch(`${TERMIUS_API_BASE}/status`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
    });
    
    if (response.ok) {
      const data = await response.json();
      return data.status === 'connected';
    }
    return false;
  } catch (error) {
    console.error(`Connection check failed for ${bot}:`, error);
    return false;
  }
}

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      queryFn: getQueryFn({ on401: "throw" }),
      refetchInterval: false,
      refetchOnWindowFocus: false,
      staleTime: Infinity,
      retry: false,
    },
    mutations: {
      retry: false,
    },
  },
});
