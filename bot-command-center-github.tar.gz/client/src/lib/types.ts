export interface DashboardStats {
  activeBots: number;
  totalScraped: number;
  successRate: string;
  avgResponse: string;
  dailyGptCost: number;
  dailyGptTokens: number;
  dailyGptRequests: number;
}

export interface GptStats {
  totalCost: number;
  totalTokens: number;
  requestCount: number;
}

export interface ProcessResult {
  success: boolean;
  processId?: number;
  message: string;
  error?: string;
}

export type BotStatus = "running" | "stopped" | "paused" | "crashed" | "error";
export type LogType = "info" | "success" | "warning" | "error";
export type Platform = "craigslist" | "facebook" | "offerup" | "reddit";

export interface BotFormData {
  name: string;
  city: string;
  platform: Platform;
  config?: {
    maxPages?: number;
    delay?: number;
    userAgent?: string;
  };
}
