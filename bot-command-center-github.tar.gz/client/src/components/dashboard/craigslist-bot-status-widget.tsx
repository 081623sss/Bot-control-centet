import { useQuery } from '@tanstack/react-query'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import {
  Bot,
  CheckCircle,
  XCircle,
  AlertTriangle,
  Clock,
  RefreshCw,
  TrendingUp,
  MapPin,
  Calendar,
  ExternalLink
} from 'lucide-react'

interface CraigslistBotStatus {
  isRunning: boolean
  cities: string[]
  leadsToday: number
  totalLeads: number
  lastRunTime: Date | null
  status: 'running' | 'stopped' | 'error' | 'idle'
  errorMessage?: string
}

export default function CraigslistBotStatusWidget() {
  // Fetch bot status
  const { data: statusData, isLoading: statusLoading, error: statusError } = useQuery({
    queryKey: ['/api/craigslist-bot/status'],
    refetchInterval: 10000, // Auto-refresh every 10 seconds
    retry: 2
  })

  const status: CraigslistBotStatus | null = (statusData as any)?.success ? (statusData as any).data : null

  const getStatusIcon = () => {
    if (statusLoading) return <RefreshCw className="w-4 h-4 text-gray-500 animate-spin" />
    if (!status || statusError) return <XCircle className="w-4 h-4 text-red-500" />
    
    switch (status.status) {
      case 'running': return <CheckCircle className="w-4 h-4 text-green-500" />
      case 'stopped': return <XCircle className="w-4 h-4 text-red-500" />
      case 'error': return <AlertTriangle className="w-4 h-4 text-red-500" />
      case 'idle': return <Clock className="w-4 h-4 text-yellow-500" />
      default: return <XCircle className="w-4 h-4 text-gray-500" />
    }
  }

  const getStatusBadge = () => {
    if (!status || statusError) return <Badge variant="destructive">Offline</Badge>
    
    switch (status.status) {
      case 'running': return <Badge className="bg-green-500/20 text-green-300 border-green-400/50">Running</Badge>
      case 'stopped': return <Badge variant="destructive">Stopped</Badge>
      case 'error': return <Badge variant="destructive">Error</Badge>
      case 'idle': return <Badge className="bg-yellow-500/20 text-yellow-300 border-yellow-400/50">Idle</Badge>
      default: return <Badge variant="secondary">Unknown</Badge>
    }
  }

  const formatLastRun = (date: Date | null) => {
    if (!date) return 'Never'
    const now = new Date()
    const diff = now.getTime() - new Date(date).getTime()
    const minutes = Math.floor(diff / 60000)
    const hours = Math.floor(minutes / 60)
    const days = Math.floor(hours / 24)
    
    if (days > 0) return `${days}d ago`
    if (hours > 0) return `${hours}h ago`
    if (minutes > 0) return `${minutes}m ago`
    return 'Just now'
  }

  return (
    <Card className="bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-blue-950 dark:to-indigo-950 border-blue-200 dark:border-blue-800">
      <CardHeader className="pb-3 p-3 sm:p-4">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-sm sm:text-base text-blue-900 dark:text-blue-100">
            <Bot className="w-4 h-4" />
            Craigslist Bot
            {getStatusBadge()}
          </CardTitle>
          {getStatusIcon()}
        </div>
      </CardHeader>
      <CardContent className="p-3 sm:p-4 pt-0">
        {statusError ? (
          <div className="text-xs text-red-600 dark:text-red-400">
            Connection failed. Check Ngrok status.
          </div>
        ) : (
          <div className="space-y-2">
            {/* Quick Stats */}
            <div className="grid grid-cols-3 gap-2 text-xs">
              <div className="text-center">
                <div className="flex items-center justify-center gap-1 text-blue-600 dark:text-blue-400">
                  <MapPin className="w-3 h-3" />
                  <span>{status?.cities?.length || 0}</span>
                </div>
                <div className="text-gray-600 dark:text-gray-400">Cities</div>
              </div>
              <div className="text-center">
                <div className="flex items-center justify-center gap-1 text-green-600 dark:text-green-400">
                  <TrendingUp className="w-3 h-3" />
                  <span>{status?.leadsToday || 0}</span>
                </div>
                <div className="text-gray-600 dark:text-gray-400">Today</div>
              </div>
              <div className="text-center">
                <div className="flex items-center justify-center gap-1 text-purple-600 dark:text-purple-400">
                  <Calendar className="w-3 h-3" />
                  <span>{formatLastRun(status?.lastRunTime || null)}</span>
                </div>
                <div className="text-gray-600 dark:text-gray-400">Last Run</div>
              </div>
            </div>

            {/* Error Message */}
            {status?.errorMessage && (
              <div className="text-xs text-red-600 dark:text-red-400 p-2 bg-red-50 dark:bg-red-950/30 rounded">
                {status.errorMessage}
              </div>
            )}

            {/* Quick Action */}
            <Button 
              variant="outline" 
              size="sm" 
              className="w-full text-xs h-7"
              onClick={() => {
                // Navigate to Bots tab - you could add routing logic here
                const botsTab = document.querySelector('[data-value="bots"]') as HTMLElement
                if (botsTab) botsTab.click()
              }}
            >
              <ExternalLink className="w-3 h-3 mr-1" />
              Manage Bot
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  )
}