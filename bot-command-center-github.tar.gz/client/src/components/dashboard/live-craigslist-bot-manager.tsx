import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Play, Square, RotateCcw, Camera, RefreshCw, Server, Zap, AlertTriangle } from 'lucide-react';
import { useToast } from "@/hooks/use-toast";

interface BotStatus {
  isRunning: boolean;
  status: 'online' | 'stopped' | 'error' | 'connecting';
  memory?: string;
  cpu?: string;
  uptime?: string;
  leadsToday: number;
  totalLeads: number;
  lastRun?: string;
  errorMessage?: string;
}

interface ConnectionInfo {
  url: string;
  online: boolean;
  responseTime?: number;
  error?: string;
}

export function LiveCraigslistBotManager() {
  const [botStatus, setBotStatus] = useState<BotStatus>({
    isRunning: false,
    status: 'connecting',
    leadsToday: 0,
    totalLeads: 0
  });
  
  const [connectionInfo, setConnectionInfo] = useState<ConnectionInfo>({
    url: import.meta.env.VITE_NGROK_URL || 'Not configured',
    online: false
  });
  
  const [isLoading, setIsLoading] = useState(false);
  const [autoRefresh, setAutoRefresh] = useState(true);
  const { toast } = useToast();

  // Send bot command with authentication
  const sendBotCommand = async (command: string) => {
    try {
      setIsLoading(true);
      
      const ngrokUrl = import.meta.env.VITE_NGROK_URL;
      if (!ngrokUrl) {
        throw new Error('Ngrok URL not configured');
      }

      const response = await fetch(`${ngrokUrl}/api/ngrok/bot-command`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(import.meta.env.VITE_BOT_TOKEN && {
            'Authorization': `Bearer ${import.meta.env.VITE_BOT_TOKEN}`
          })
        },
        body: JSON.stringify({
          command: command,
          botName: 'craigslist-scraper'
        })
      });

      if (!response.ok) {
        throw new Error(`Server error: ${response.status}`);
      }

      const data = await response.json();
      
      if (data.success) {
        toast({
          title: "Command Sent",
          description: `Successfully executed: ${command}`
        });
        await checkBotStatus(); // Refresh status after command
        return data;
      } else {
        throw new Error(data.message || 'Command failed');
      }
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      
      // Update connection status
      setConnectionInfo(prev => ({
        ...prev,
        online: false,
        error: errorMessage
      }));

      toast({
        title: "Command Failed",
        description: errorMessage.includes('fetch') ? 
          'Bot offline. Check Ngrok connection or restart tunnel.' : 
          errorMessage,
        variant: "destructive"
      });
      
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  // Check bot status via PM2
  const checkBotStatus = async () => {
    try {
      const result = await sendBotCommand('pm2 list --no-color');
      
      if (result?.output) {
        const pm2Output = result.output;
        const isCraigslistRunning = pm2Output.includes('craigslist-scraper') && 
                                   pm2Output.includes('online');
        
        // Extract memory and CPU if available
        const memoryMatch = pm2Output.match(/(\d+\.?\d*\s*[MG]B)/);
        const memory = memoryMatch ? memoryMatch[1] : undefined;

        setBotStatus(prev => ({
          ...prev,
          isRunning: isCraigslistRunning,
          status: isCraigslistRunning ? 'online' : 'stopped',
          memory,
          lastRun: isCraigslistRunning ? new Date().toLocaleTimeString() : prev.lastRun,
          errorMessage: undefined
        }));

        setConnectionInfo(prev => ({
          ...prev,
          online: true,
          error: undefined
        }));

      }
    } catch (error) {
      setBotStatus(prev => ({
        ...prev,
        status: 'error',
        errorMessage: 'Failed to connect to bot server'
      }));
    }
  };

  // Bot control actions
  const startBot = () => sendBotCommand('pm2 start scraper.mjs --name craigslist-scraper');
  const stopBot = () => sendBotCommand('pm2 stop craigslist-scraper');
  const restartBot = () => sendBotCommand('pm2 restart craigslist-scraper');
  const rollbackBot = () => sendBotCommand('pm2 stop craigslist-scraper && git checkout HEAD~1 scraper.mjs && pm2 start scraper.mjs --name craigslist-scraper');
  const snapshotBot = () => sendBotCommand('git add scraper.mjs && git commit -m "Snapshot: $(date)"');

  // Auto-refresh effect
  useEffect(() => {
    if (autoRefresh) {
      checkBotStatus(); // Initial check
      const interval = setInterval(checkBotStatus, 10000); // Every 10 seconds
      return () => clearInterval(interval);
    }
  }, [autoRefresh]);

  // Status badge component
  const StatusBadge = () => {
    const statusConfig = {
      online: { variant: 'default' as const, icon: '🟢', text: 'Online' },
      stopped: { variant: 'secondary' as const, icon: '🔴', text: 'Stopped' },
      error: { variant: 'destructive' as const, icon: '🔴', text: 'Error' },
      connecting: { variant: 'outline' as const, icon: '🟡', text: 'Connecting' }
    };

    const config = statusConfig[botStatus.status];
    return (
      <Badge variant={config.variant} className="flex items-center gap-1">
        <span>{config.icon}</span>
        {config.text}
      </Badge>
    );
  };

  return (
    <div className="space-y-6">
      {/* Connection Status Alert */}
      {!connectionInfo.online && (
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            Bot offline. Check Ngrok connection or restart tunnel.
            <br />
            <span className="text-sm text-muted-foreground">
              Endpoint: {connectionInfo.url}
            </span>
          </AlertDescription>
        </Alert>
      )}

      {/* Bot Status Card */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Server className="h-5 w-5" />
              Craigslist Scraper Bot
            </CardTitle>
            <CardDescription>
              PM2 Process: craigslist-scraper | Script: scraper.mjs
            </CardDescription>
          </div>
          <div className="flex items-center gap-2">
            <StatusBadge />
            <Button
              variant="outline"
              size="sm"
              onClick={checkBotStatus}
              disabled={isLoading}
            >
              <RefreshCw className={`h-4 w-4 ${isLoading ? 'animate-spin' : ''}`} />
            </Button>
          </div>
        </CardHeader>
        
        <CardContent className="space-y-4">
          {/* Bot Metrics */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center p-3 bg-muted rounded-lg">
              <div className="text-2xl font-bold text-green-600">{botStatus.leadsToday}</div>
              <div className="text-sm text-muted-foreground">Today's Leads</div>
            </div>
            <div className="text-center p-3 bg-muted rounded-lg">
              <div className="text-2xl font-bold">{botStatus.totalLeads}</div>
              <div className="text-sm text-muted-foreground">Total Leads</div>
            </div>
            <div className="text-center p-3 bg-muted rounded-lg">
              <div className="text-2xl font-bold">{botStatus.memory || 'N/A'}</div>
              <div className="text-sm text-muted-foreground">Memory</div>
            </div>
            <div className="text-center p-3 bg-muted rounded-lg">
              <div className="text-2xl font-bold">{botStatus.lastRun || 'Never'}</div>
              <div className="text-sm text-muted-foreground">Last Run</div>
            </div>
          </div>

          {/* Bot Controls */}
          <div className="flex flex-wrap gap-2">
            <Button
              onClick={startBot}
              disabled={isLoading || botStatus.isRunning}
              className="flex items-center gap-2"
            >
              <Play className="h-4 w-4" />
              Start
            </Button>
            
            <Button
              onClick={stopBot}
              disabled={isLoading || !botStatus.isRunning}
              variant="destructive"
              className="flex items-center gap-2"
            >
              <Square className="h-4 w-4" />
              Stop
            </Button>
            
            <Button
              onClick={restartBot}
              disabled={isLoading}
              variant="outline"
              className="flex items-center gap-2"
            >
              <RotateCcw className="h-4 w-4" />
              Restart
            </Button>
            
            <Button
              onClick={rollbackBot}
              disabled={isLoading}
              variant="outline"
              className="flex items-center gap-2"
            >
              <RotateCcw className="h-4 w-4" />
              Rollback
            </Button>
            
            <Button
              onClick={snapshotBot}
              disabled={isLoading}
              variant="outline"
              className="flex items-center gap-2"
            >
              <Camera className="h-4 w-4" />
              Snapshot
            </Button>
          </div>

          {/* Auto-refresh toggle */}
          <div className="flex items-center justify-between pt-4 border-t">
            <div className="flex items-center gap-2">
              <Button
                onClick={() => setAutoRefresh(!autoRefresh)}
                variant="outline"
                size="sm"
                className="flex items-center gap-2"
              >
                <Zap className={`h-4 w-4 ${autoRefresh ? 'text-green-500' : 'text-gray-400'}`} />
                Auto-refresh {autoRefresh ? 'On' : 'Off'}
              </Button>
            </div>
            
            <div className="text-sm text-muted-foreground">
              Connected to: {connectionInfo.url}
            </div>
          </div>

          {/* Error message */}
          {botStatus.errorMessage && (
            <Alert variant="destructive">
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>{botStatus.errorMessage}</AlertDescription>
            </Alert>
          )}
        </CardContent>
      </Card>
    </div>
  );
}