import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { useToast } from '@/hooks/use-toast'
import { 
  FileCode, 
  Save, 
  Plus, 
  Download, 
  Terminal, 
  Code2,
  CheckCircle,
  XCircle,
  AlertTriangle 
} from 'lucide-react'

export default function SimpleBotEditor() {
  const [botName, setBotName] = useState('')
  const [fileName, setFileName] = useState('scraper.js')
  const [fileContent, setFileContent] = useState('')
  const [status, setStatus] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false)

  const { toast } = useToast()

  const fetchBotFile = async () => {
    setIsLoading(true)
    try {
      const res = await fetch(`/api/bot/read?file=${fileName}`, {
        credentials: 'include'
      })
      const data = await res.json()
      if (data.success) {
        setFileContent(data.content)
        setStatus('success')
        setHasUnsavedChanges(false)
        toast({
          title: "File Loaded",
          description: `Successfully loaded ${fileName}`,
        })
      } else {
        setStatus('error')
        toast({
          title: "Load Failed",
          description: data.message || "Failed to load bot file",
          variant: "destructive"
        })
      }
    } catch (e) {
      setStatus('error')
      toast({
        title: "Load Failed",
        description: "Network error while loading file",
        variant: "destructive"
      })
    } finally {
      setIsLoading(false)
    }
  }

  const saveBotFile = async () => {
    setIsLoading(true)
    try {
      const res = await fetch(`/api/bot/save`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ file: fileName, content: fileContent })
      })
      const data = await res.json()
      if (data.success) {
        setStatus('success')
        setHasUnsavedChanges(false)
        toast({
          title: "File Saved",
          description: `Successfully saved ${fileName}`,
        })
      } else {
        setStatus('error')
        toast({
          title: "Save Failed", 
          description: data.message || "Failed to save bot file",
          variant: "destructive"
        })
      }
    } catch (e) {
      setStatus('error')
      toast({
        title: "Save Failed",
        description: "Network error while saving file",
        variant: "destructive"
      })
    } finally {
      setIsLoading(false)
    }
  }

  const createNewBot = async () => {
    if (!botName.trim()) {
      toast({
        title: "Invalid Name",
        description: "Please enter a bot name",
        variant: "destructive"
      })
      return
    }

    setIsLoading(true)
    try {
      const res = await fetch(`/api/bot/create`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ name: botName })
      })
      const data = await res.json()
      if (data.success) {
        setFileName(`${botName}.js`)
        setFileContent(`// ${botName} - Auto-generated bot template
export default async function runBot() {
  console.log('Starting ${botName}...');
  
  // Add your bot logic here
  
  return { success: true, message: '${botName} completed successfully' };
}`)
        setStatus('success')
        setHasUnsavedChanges(false)
        toast({
          title: "Bot Created",
          description: `Successfully created ${botName}.js`,
        })
      } else {
        setStatus('error')
        toast({
          title: "Creation Failed",
          description: data.message || "Failed to create bot file",
          variant: "destructive"
        })
      }
    } catch (e) {
      setStatus('error')
      toast({
        title: "Creation Failed",
        description: "Network error while creating file",
        variant: "destructive"
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleContentChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setFileContent(e.target.value)
    setHasUnsavedChanges(true)
  }

  const getStatusIcon = () => {
    switch (status) {
      case 'success':
        return <CheckCircle className="w-4 h-4 text-green-400" />
      case 'error':
        return <XCircle className="w-4 h-4 text-red-400" />
      default:
        return <Terminal className="w-4 h-4 text-blue-400" />
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 text-white p-8">
      <div className="max-w-6xl mx-auto space-y-8">
        {/* Enhanced Header */}
        <div className="text-center mb-10">
          <div className="flex items-center justify-center gap-4 mb-6">
            <div className="p-3 bg-gradient-to-r from-blue-500 to-purple-500 rounded-xl shadow-lg">
              <Code2 className="w-8 h-8 text-white" />
            </div>
            <div>
              <h1 className="text-4xl font-bold bg-gradient-to-r from-white to-blue-100 bg-clip-text text-transparent">
                Simple Bot Editor
              </h1>
              <p className="text-blue-200 mt-2 text-lg">Lightweight bot development environment</p>
            </div>
          </div>
          <Badge variant="secondary" className="bg-blue-500/20 text-blue-200 border-blue-400 px-4 py-2">
            <Terminal className="h-4 w-4 mr-2" />
            File-based Editor
          </Badge>
        </div>

        {/* Main Editor Card */}
        <Card className="bg-gradient-to-br from-slate-800/50 to-blue-800/20 border-blue-500/30 shadow-2xl backdrop-blur-sm">
          <CardHeader className="pb-6 border-b border-blue-500/20">
            <CardTitle className="text-white flex items-center gap-3 text-2xl">
              <div className="p-2 bg-blue-500/20 rounded-lg">
                <FileCode className="w-6 h-6 text-blue-400" />
              </div>
              Bot File Editor
              {hasUnsavedChanges && (
                <Badge variant="outline" className="bg-orange-500/20 text-orange-300 border-orange-400/50 px-3 py-1">
                  • Unsaved Changes
                </Badge>
              )}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6 p-8">
            {/* File Controls */}
            <div className="flex gap-4">
              <div className="flex-1">
                <Input 
                  value={fileName} 
                  onChange={(e) => setFileName(e.target.value)} 
                  placeholder="Enter file name (e.g. scraper.js)" 
                  className="bg-slate-700/50 border-blue-400/50 text-white h-12 text-lg"
                />
              </div>
              <Button 
                onClick={fetchBotFile} 
                disabled={isLoading}
                className="bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white px-6 h-12"
              >
                <Download className="w-4 h-4 mr-2" />
                {isLoading ? 'Loading...' : 'Load File'}
              </Button>
            </div>

            {/* Code Editor */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  {getStatusIcon()}
                  <span className="text-sm text-blue-200">
                    {fileName && `Editing: ${fileName}`}
                  </span>
                </div>
                <div className="text-xs text-slate-400">
                  Lines: {fileContent.split('\n').length} | Characters: {fileContent.length}
                </div>
              </div>
              
              <Textarea 
                value={fileContent} 
                onChange={handleContentChange}
                rows={25}
                className="bg-slate-900/50 border-2 border-blue-500/30 text-white font-mono text-base resize-none rounded-xl shadow-xl"
                style={{
                  fontFamily: 'Fira Code, Monaco, "Cascadia Code", "Roboto Mono", Consolas, "Courier New", monospace'
                }}
                placeholder="// Load a file or create a new bot to start editing..."
              />
            </div>

            {/* Save Button */}
            <Button 
              className="w-full bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white h-14 text-lg shadow-lg" 
              onClick={saveBotFile}
              disabled={!hasUnsavedChanges || isLoading}
            >
              <Save className="w-5 h-5 mr-3" />
              {isLoading ? 'Saving...' : 'Save Changes'}
            </Button>
          </CardContent>
        </Card>

        {/* Create New Bot Card */}
        <Card className="bg-gradient-to-br from-slate-800/50 to-purple-800/20 border-purple-500/30 shadow-xl backdrop-blur-sm">
          <CardHeader className="pb-4">
            <CardTitle className="text-white flex items-center gap-3 text-xl">
              <div className="p-2 bg-purple-500/20 rounded-lg">
                <Plus className="w-5 h-5 text-purple-400" />
              </div>
              Create New Bot
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 p-6">
            <div className="flex gap-4">
              <div className="flex-1">
                <Input 
                  value={botName} 
                  onChange={(e) => setBotName(e.target.value)} 
                  placeholder="Enter new bot name (no extension)" 
                  className="bg-slate-700/50 border-purple-400/50 text-white h-12"
                />
              </div>
              <Button 
                onClick={createNewBot}
                disabled={isLoading || !botName.trim()}
                className="bg-gradient-to-r from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700 text-white px-6 h-12"
              >
                <Plus className="w-4 h-4 mr-2" />
                {isLoading ? 'Creating...' : 'Create Bot'}
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}