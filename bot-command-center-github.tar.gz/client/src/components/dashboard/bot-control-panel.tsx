import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { AlertTriangle, Play, Pause, Square, Plus, RotateCcw, ExternalLink, Github, Facebook, MessageSquare } from "lucide-react";
import { useMutation, useQueryClient, useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";
import type { BotInstance, ErrorLog, ScraperVersion } from "@shared/schema";
import type { BotStatus, Platform, ProcessResult } from "@/lib/types";

interface BotControlPanelProps {
  bots: BotInstance[];
  onRefresh: () => void;
  onLogRefresh: () => void;
}

export default function BotControlPanel({ bots, onRefresh, onLogRefresh }: BotControlPanelProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedPlatform, setSelectedPlatform] = useState<Platform | "all">("all");
  const [selectedBot, setSelectedBot] = useState<BotInstance | null>(null);

  // Get platform icon
  const getPlatformIcon = (platform: string) => {
    const icons = {
      craigslist: ExternalLink,
      facebook: Facebook,
      offerup: Github, // Using Github as a placeholder
      reddit: MessageSquare
    };
    return icons[platform as keyof typeof icons] || ExternalLink;
  };

  // Filter bots by platform
  const filteredBots = selectedPlatform === "all" 
    ? bots 
    : bots.filter(bot => bot.platform === selectedPlatform);

  // Group bots by city and platform for better organization
  const botsByCity = filteredBots.reduce((acc, bot) => {
    if (!acc[bot.city]) {
      acc[bot.city] = [];
    }
    acc[bot.city].push(bot);
    return acc;
  }, {} as Record<string, BotInstance[]>);

  const updateBotMutation = useMutation({
    mutationFn: async ({ id, status }: { id: number; status: BotStatus }) => {
      return apiRequest("PATCH", `/api/bots/${id}`, { 
        status, 
        lastRun: status === "running" ? new Date() : undefined 
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bots"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      queryClient.invalidateQueries({ queryKey: ["/api/logs"] });
      onRefresh();
      onLogRefresh();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update bot status",
        variant: "destructive",
      });
    },
  });

  const createBotMutation = useMutation({
    mutationFn: async (city: string) => {
      return apiRequest("POST", "/api/bots", {
        city,
        status: "stopped",
        dailyCount: 0,
        totalScraped: 0,
        successRate: 0,
        progress: 0,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bots"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      queryClient.invalidateQueries({ queryKey: ["/api/logs"] });
      onRefresh();
      onLogRefresh();
      toast({
        title: "Success",
        description: "New bot instance created",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create bot instance",
        variant: "destructive",
      });
    },
  });

  const handleStatusChange = (id: number, status: BotStatus) => {
    updateBotMutation.mutate({ id, status });
  };

  const handleCreateBot = () => {
    const city = prompt("Enter city name for new bot:");
    if (city && city.trim()) {
      createBotMutation.mutate(city.trim());
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "running":
        return "bg-emerald-500/10 text-emerald-500";
      case "paused":
        return "bg-amber-500/10 text-amber-500";
      case "error":
        return "bg-red-500/10 text-red-500";
      default:
        return "bg-red-500/10 text-red-500";
    }
  };

  const getStatusDot = (status: string) => {
    switch (status) {
      case "running":
        return "bg-emerald-500 animate-pulse-slow";
      case "paused":
        return "bg-amber-500";
      case "error":
        return "bg-red-500";
      default:
        return "bg-red-500";
    }
  };

  const formatLastRun = (lastRun: Date | null) => {
    if (!lastRun) return "Never";
    const now = new Date();
    const diff = now.getTime() - new Date(lastRun).getTime();
    const minutes = Math.floor(diff / 60000);
    if (minutes < 60) return `${minutes} min ago`;
    const hours = Math.floor(minutes / 60);
    return `${hours} hour${hours > 1 ? 's' : ''} ago`;
  };

  return (
    <Card className="bg-slate-900 border-slate-700">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-xl font-semibold text-white">Bot Instances</CardTitle>
          <Button 
            onClick={handleCreateBot}
            disabled={createBotMutation.isPending}
            className="bg-blue-600 hover:bg-blue-700"
          >
            <Plus className="w-4 h-4 mr-2" />
            New Bot
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {bots.map((bot) => (
            <Card key={bot.id} className="bg-slate-800 border-slate-600">
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center space-x-3">
                    <div className={`w-3 h-3 rounded-full ${getStatusDot(bot.status)}`}></div>
                    <h3 className="font-semibold text-white">{bot.city} Scraper</h3>
                    <Badge className={getStatusColor(bot.status)}>
                      {bot.status.charAt(0).toUpperCase() + bot.status.slice(1)}
                    </Badge>
                  </div>
                  <div className="flex items-center space-x-2">
                    {bot.status === "stopped" ? (
                      <Button
                        size="sm"
                        onClick={() => handleStatusChange(bot.id, "running")}
                        disabled={updateBotMutation.isPending}
                        className="bg-emerald-600 hover:bg-emerald-700 p-2"
                      >
                        <Play className="w-4 h-4" />
                      </Button>
                    ) : (
                      <>
                        <Button
                          size="sm"
                          onClick={() => handleStatusChange(bot.id, "paused")}
                          disabled={updateBotMutation.isPending}
                          className="bg-amber-600 hover:bg-amber-700 p-2"
                        >
                          <Pause className="w-4 h-4" />
                        </Button>
                        <Button
                          size="sm"
                          onClick={() => handleStatusChange(bot.id, "stopped")}
                          disabled={updateBotMutation.isPending}
                          className="bg-red-600 hover:bg-red-700 p-2"
                        >
                          <Square className="w-4 h-4" />
                        </Button>
                      </>
                    )}
                  </div>
                </div>
                
                <div className="grid grid-cols-3 gap-4 text-sm mb-3">
                  <div>
                    <p className="text-slate-400">Scraped Today</p>
                    <p className="text-white font-medium">{bot.dailyCount.toLocaleString()}</p>
                  </div>
                  <div>
                    <p className="text-slate-400">Last Run</p>
                    <p className="text-white font-medium">{formatLastRun(bot.lastRun)}</p>
                  </div>
                  <div>
                    <p className="text-slate-400">Success Rate</p>
                    <p className="text-white font-medium">{bot.successRate}%</p>
                  </div>
                </div>
                
                <div>
                  <div className="flex justify-between text-xs text-slate-400 mb-1">
                    <span>Progress</span>
                    <span>{bot.progress}%</span>
                  </div>
                  <Progress 
                    value={bot.progress} 
                    className="h-2 bg-slate-700"
                  />
                </div>
              </CardContent>
            </Card>
          ))}
          
          {bots.length === 0 && (
            <div className="text-center py-8">
              <p className="text-slate-400 mb-4">No bot instances found</p>
              <Button onClick={handleCreateBot} className="bg-blue-600 hover:bg-blue-700">
                <Plus className="w-4 h-4 mr-2" />
                Create Your First Bot
              </Button>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
