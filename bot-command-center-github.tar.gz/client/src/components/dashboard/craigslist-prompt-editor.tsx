import { useState, useEffect } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { useToast } from '@/hooks/use-toast'
import {
  Save,
  RefreshCw,
  FileText,
  Zap,
  CheckCircle,
  AlertTriangle,
  Eye,
  Edit3,
  RotateCcw
} from 'lucide-react'

interface BotConfig {
  name: string
  enrichmentPrompt: string
  cities: string[]
  searchTerms: string[]
}

export default function CraigslistPromptEditor() {
  const [prompt, setPrompt] = useState('')
  const [hasChanges, setHasChanges] = useState(false)
  const [isPreviewMode, setIsPreviewMode] = useState(true)
  const { toast } = useToast()
  const queryClient = useQueryClient()

  // Fetch current bot configuration
  const { data: configData, isLoading: configLoading } = useQuery({
    queryKey: ['/api/craigslist-bot/config'],
    retry: 2
  })

  // Load config data into state
  useEffect(() => {
    if (configData && (configData as any).success) {
      const config: BotConfig = (configData as any).data
      setPrompt(config.enrichmentPrompt)
      setHasChanges(false)
    }
  }, [configData])

  // Update prompt mutation
  const updatePromptMutation = useMutation({
    mutationFn: async (newPrompt: string) => {
      const response = await fetch('/api/craigslist-bot/update-prompt', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify({ prompt: newPrompt })
      })
      return response.json()
    },
    onSuccess: (data) => {
      if (data.success) {
        setHasChanges(false)
        queryClient.invalidateQueries({ queryKey: ['/api/craigslist-bot/config'] })
        toast({
          title: "Prompt Updated",
          description: "Enrichment prompt has been updated successfully and will apply to new leads",
        })
      } else {
        throw new Error(data.message || 'Failed to update prompt')
      }
    },
    onError: (error) => {
      toast({
        title: "Update Failed",
        description: error instanceof Error ? error.message : "Failed to update enrichment prompt",
        variant: "destructive"
      })
    }
  })

  const config: BotConfig | null = (configData as any)?.success ? (configData as any).data : null

  const handlePromptChange = (newPrompt: string) => {
    setPrompt(newPrompt)
    setHasChanges(newPrompt !== config?.enrichmentPrompt)
  }

  const handleSave = () => {
    if (prompt.trim()) {
      updatePromptMutation.mutate(prompt)
    }
  }

  const handleReset = () => {
    if (config) {
      setPrompt(config.enrichmentPrompt)
      setHasChanges(false)
      toast({
        title: "Prompt Reset",
        description: "Prompt has been reset to the current saved version",
      })
    }
  }

  const getWordCount = () => prompt.split(/\s+/).filter(word => word.length > 0).length
  const getCharCount = () => prompt.length

  if (configLoading) {
    return (
      <Card>
        <CardContent className="p-4 sm:p-6">
          <div className="animate-pulse space-y-4">
            <div className="h-4 bg-slate-200 dark:bg-slate-700 rounded w-3/4"></div>
            <div className="h-32 bg-slate-200 dark:bg-slate-700 rounded"></div>
            <div className="h-4 bg-slate-200 dark:bg-slate-700 rounded w-1/2"></div>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-4 sm:space-y-6">
      {/* Header */}
      <Card className="bg-gradient-to-r from-purple-50 to-indigo-50 dark:from-purple-950 dark:to-indigo-950 border-purple-200 dark:border-purple-800">
        <CardHeader className="pb-3 p-3 sm:p-6">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 sm:gap-0">
            <CardTitle className="flex items-center gap-2 text-base sm:text-lg text-purple-900 dark:text-purple-100">
              <Zap className="w-4 h-4 sm:w-5 sm:h-5" />
              GPT Enrichment Prompt Editor
              {hasChanges && <Badge variant="destructive" className="text-xs">Unsaved Changes</Badge>}
            </CardTitle>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setIsPreviewMode(!isPreviewMode)}
                className="text-xs sm:text-sm"
              >
                {isPreviewMode ? <Edit3 className="w-3 h-3 mr-1" /> : <Eye className="w-3 h-3 mr-1" />}
                {isPreviewMode ? 'Edit' : 'Preview'}
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-3 sm:p-6 pt-0">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs sm:text-sm">
            <div className="text-center p-2 bg-white/50 dark:bg-gray-800/50 rounded">
              <div className="font-medium text-purple-700 dark:text-purple-300">Words</div>
              <div className="text-lg font-bold">{getWordCount()}</div>
            </div>
            <div className="text-center p-2 bg-white/50 dark:bg-gray-800/50 rounded">
              <div className="font-medium text-purple-700 dark:text-purple-300">Characters</div>
              <div className="text-lg font-bold">{getCharCount()}</div>
            </div>
            <div className="text-center p-2 bg-white/50 dark:bg-gray-800/50 rounded">
              <div className="font-medium text-purple-700 dark:text-purple-300">Status</div>
              <div className="flex items-center justify-center gap-1">
                {hasChanges ? (
                  <AlertTriangle className="w-4 h-4 text-orange-500" />
                ) : (
                  <CheckCircle className="w-4 h-4 text-green-500" />
                )}
                <span className="text-sm font-medium">
                  {hasChanges ? 'Modified' : 'Saved'}
                </span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Prompt Editor */}
      <Card>
        <CardHeader className="pb-3 p-3 sm:p-6">
          <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
            <FileText className="w-4 h-4 sm:w-5 sm:h-5 text-blue-500" />
            Lead Enrichment Prompt
          </CardTitle>
        </CardHeader>
        <CardContent className="p-3 sm:p-6 pt-0">
          {isPreviewMode ? (
            <div className="space-y-4">
              <div className="p-4 bg-slate-50 dark:bg-slate-800/50 rounded-lg border">
                <div className="whitespace-pre-wrap text-sm text-slate-700 dark:text-slate-300 font-mono">
                  {prompt || 'No prompt configured'}
                </div>
              </div>
              <div className="text-xs text-slate-600 dark:text-slate-400">
                This prompt is used by the Craigslist bot to enrich scraped leads with structured data extraction and analysis.
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <Textarea
                value={prompt}
                onChange={(e) => handlePromptChange(e.target.value)}
                placeholder="Enter your GPT enrichment prompt here..."
                className="min-h-[300px] font-mono text-sm"
                disabled={updatePromptMutation.isPending}
              />
              
              <Alert>
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription className="text-xs sm:text-sm">
                  Changes to this prompt will affect how the Craigslist bot processes new leads. 
                  Test thoroughly before deploying to production.
                </AlertDescription>
              </Alert>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Actions and Bot Info */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6">
        {/* Action Buttons */}
        <Card>
          <CardHeader className="pb-3 p-3 sm:p-6">
            <CardTitle className="text-base sm:text-lg">Actions</CardTitle>
          </CardHeader>
          <CardContent className="p-3 sm:p-6 pt-0">
            <div className="space-y-2 sm:space-y-3">
              <Button
                onClick={handleSave}
                disabled={!hasChanges || updatePromptMutation.isPending || !prompt.trim()}
                className="w-full bg-green-600 hover:bg-green-700"
              >
                {updatePromptMutation.isPending ? (
                  <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <Save className="w-4 h-4 mr-2" />
                )}
                {updatePromptMutation.isPending ? 'Updating...' : 'Save Prompt'}
              </Button>
              
              <Button
                onClick={handleReset}
                disabled={!hasChanges || updatePromptMutation.isPending}
                variant="outline"
                className="w-full"
              >
                <RotateCcw className="w-4 h-4 mr-2" />
                Reset Changes
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Bot Configuration Info */}
        <Card>
          <CardHeader className="pb-3 p-3 sm:p-6">
            <CardTitle className="text-base sm:text-lg">Bot Configuration</CardTitle>
          </CardHeader>
          <CardContent className="p-3 sm:p-6 pt-0">
            {config ? (
              <div className="space-y-3 text-sm">
                <div>
                  <span className="font-medium text-slate-600 dark:text-slate-400">Bot Name:</span>
                  <div className="text-slate-900 dark:text-slate-100">{config.name}</div>
                </div>
                
                <div>
                  <span className="font-medium text-slate-600 dark:text-slate-400">Active Cities:</span>
                  <div className="text-slate-900 dark:text-slate-100">{config.cities.length} Florida cities</div>
                </div>
                
                <div>
                  <span className="font-medium text-slate-600 dark:text-slate-400">Search Terms:</span>
                  <div className="flex flex-wrap gap-1 mt-1">
                    {config.searchTerms.map((term, index) => (
                      <Badge key={index} variant="secondary" className="text-xs">
                        {term}
                      </Badge>
                    ))}
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-slate-600 dark:text-slate-400 text-sm">
                Unable to load bot configuration
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}