import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Trash2 } from "lucide-react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { ActivityLog } from "@shared/schema";

interface ActivityFeedProps {
  logs: ActivityLog[];
  onRefresh: () => void;
}

export default function ActivityFeed({ logs, onRefresh }: ActivityFeedProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const clearLogsMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("DELETE", "/api/logs", {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/logs"] });
      onRefresh();
      toast({
        title: "Success",
        description: "Activity logs cleared",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to clear activity logs",
        variant: "destructive",
      });
    },
  });

  const getLogColor = (type: string) => {
    switch (type) {
      case "success":
        return "bg-emerald-500";
      case "warning":
        return "bg-amber-500";
      case "error":
        return "bg-red-500";
      default:
        return "bg-blue-500";
    }
  };

  const formatTime = (timestamp: Date | null) => {
    if (!timestamp) return "Unknown time";
    const now = new Date();
    const time = new Date(timestamp);
    const diff = now.getTime() - time.getTime();
    const minutes = Math.floor(diff / 60000);
    
    if (minutes < 1) return "Just now";
    if (minutes < 60) return `${minutes} minute${minutes > 1 ? 's' : ''} ago`;
    const hours = Math.floor(minutes / 60);
    return `${hours} hour${hours > 1 ? 's' : ''} ago`;
  };

  return (
    <Card className="bg-slate-900 border-slate-700">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold text-white">Activity Feed</CardTitle>
          <Button
            size="sm"
            variant="ghost"
            onClick={() => clearLogsMutation.mutate()}
            disabled={clearLogsMutation.isPending}
            className="text-slate-400 hover:text-white hover:bg-slate-800"
          >
            <Trash2 className="w-4 h-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-96">
          <div className="space-y-3">
            {logs.map((log) => (
              <div key={log.id} className="flex items-start space-x-3 p-3 bg-slate-800 rounded-lg">
                <div className={`w-2 h-2 rounded-full mt-2 flex-shrink-0 ${getLogColor(log.type)}`}></div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-white">{log.message}</p>
                  <p className="text-xs text-slate-400 mt-1">{formatTime(log.timestamp)}</p>
                </div>
              </div>
            ))}
            
            {logs.length === 0 && (
              <div className="text-center py-8">
                <p className="text-slate-400">No activity logs yet</p>
              </div>
            )}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
