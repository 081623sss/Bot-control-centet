import { useQuery } from '@tanstack/react-query'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import {
  TrendingUp,
  Users,
  DollarSign,
  Activity,
  Bot,
  Zap,
  Database,
  Clock,
  BarChart3,
  PieChart
} from 'lucide-react'

interface CraigslistBotAnalytics {
  weeklyLeads: number
  monthlyLeads: number
  gptTokensUsed: number
  estimatedCost: number
  costBreakdown: {
    openai: number
    airtable: number
    total: number
  }
}

export default function CraigslistBotAnalytics() {
  // Fetch bot analytics
  const { data: analyticsData, isLoading: analyticsLoading, error: analyticsError } = useQuery({
    queryKey: ['/api/craigslist-bot/analytics'],
    refetchInterval: 30000, // Refresh every 30 seconds
    retry: 2
  })

  // Fetch bot status for additional context
  const { data: statusData } = useQuery({
    queryKey: ['/api/craigslist-bot/status'],
    refetchInterval: 10000,
    retry: 2
  })

  const analytics: CraigslistBotAnalytics | null = (analyticsData as any)?.success ? (analyticsData as any).data : null
  const status = (statusData as any)?.success ? (statusData as any).data : null

  if (analyticsLoading) {
    return (
      <div className="space-y-4 sm:space-y-6">
        {/* Loading skeletons */}
        {Array.from({ length: 4 }).map((_, i) => (
          <Card key={i} className="animate-pulse">
            <CardContent className="p-4 sm:p-6">
              <div className="h-4 bg-slate-200 dark:bg-slate-700 rounded mb-2"></div>
              <div className="h-8 bg-slate-200 dark:bg-slate-700 rounded mb-4"></div>
              <div className="h-3 bg-slate-200 dark:bg-slate-700 rounded"></div>
            </CardContent>
          </Card>
        ))}
      </div>
    )
  }

  if (analyticsError || !analytics) {
    return (
      <Card>
        <CardContent className="p-4 sm:p-6">
          <div className="text-center">
            <Bot className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100 mb-2">Analytics Unavailable</h3>
            <p className="text-gray-600 dark:text-gray-400 mb-4">
              Unable to fetch bot analytics. Please check the Ngrok connection and try again.
            </p>
            <Badge variant="destructive">Connection Failed</Badge>
          </div>
        </CardContent>
      </Card>
    )
  }

  const avgLeadsPerDay = Math.round(analytics.weeklyLeads / 7)
  const monthlyGrowth = analytics.monthlyLeads > analytics.weeklyLeads * 4 ? 
    Math.round(((analytics.monthlyLeads - (analytics.weeklyLeads * 4)) / (analytics.weeklyLeads * 4)) * 100) : 0

  return (
    <div className="space-y-4 sm:space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 sm:gap-0">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">Bot Analytics Dashboard</h2>
          <p className="text-sm sm:text-base text-slate-600 dark:text-slate-400">
            Performance metrics and cost analysis for Craigslist Scraper Bot
          </p>
        </div>
        <Badge className="bg-blue-500/20 text-blue-700 dark:text-blue-300 border-blue-400/50 self-start sm:self-auto">
          <Activity className="w-3 h-3 mr-1" />
          Live Data
        </Badge>
      </div>

      {/* Key Metrics Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        {/* Weekly Leads */}
        <Card className="bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-950 dark:to-blue-900 border-blue-200 dark:border-blue-800">
          <CardContent className="p-4 sm:p-6">
            <div className="flex items-center justify-between">
              <div className="min-w-0 flex-1">
                <p className="text-xs sm:text-sm font-medium text-blue-700 dark:text-blue-300">Weekly Leads</p>
                <p className="text-2xl sm:text-3xl font-bold text-blue-900 dark:text-white">
                  {analytics.weeklyLeads.toLocaleString()}
                </p>
                <p className="text-xs text-blue-600 dark:text-blue-400">
                  ~{avgLeadsPerDay}/day avg
                </p>
              </div>
              <div className="w-10 h-10 sm:w-12 sm:h-12 bg-blue-500 rounded-xl flex items-center justify-center flex-shrink-0">
                <TrendingUp className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Monthly Leads */}
        <Card className="bg-gradient-to-br from-green-50 to-green-100 dark:from-green-950 dark:to-green-900 border-green-200 dark:border-green-800">
          <CardContent className="p-4 sm:p-6">
            <div className="flex items-center justify-between">
              <div className="min-w-0 flex-1">
                <p className="text-xs sm:text-sm font-medium text-green-700 dark:text-green-300">Monthly Leads</p>
                <p className="text-2xl sm:text-3xl font-bold text-green-900 dark:text-white">
                  {analytics.monthlyLeads.toLocaleString()}
                </p>
                <p className="text-xs text-green-600 dark:text-green-400">
                  {monthlyGrowth > 0 ? `+${monthlyGrowth}%` : 'Steady'} growth
                </p>
              </div>
              <div className="w-10 h-10 sm:w-12 sm:h-12 bg-green-500 rounded-xl flex items-center justify-center flex-shrink-0">
                <Users className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* GPT Tokens */}
        <Card className="bg-gradient-to-br from-purple-50 to-purple-100 dark:from-purple-950 dark:to-purple-900 border-purple-200 dark:border-purple-800">
          <CardContent className="p-4 sm:p-6">
            <div className="flex items-center justify-between">
              <div className="min-w-0 flex-1">
                <p className="text-xs sm:text-sm font-medium text-purple-700 dark:text-purple-300">GPT Tokens</p>
                <p className="text-2xl sm:text-3xl font-bold text-purple-900 dark:text-white">
                  {(analytics.gptTokensUsed / 1000).toFixed(1)}K
                </p>
                <p className="text-xs text-purple-600 dark:text-purple-400">
                  {analytics.gptTokensUsed.toLocaleString()} total
                </p>
              </div>
              <div className="w-10 h-10 sm:w-12 sm:h-12 bg-purple-500 rounded-xl flex items-center justify-center flex-shrink-0">
                <Zap className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Estimated Cost */}
        <Card className="bg-gradient-to-br from-orange-50 to-orange-100 dark:from-orange-950 dark:to-orange-900 border-orange-200 dark:border-orange-800">
          <CardContent className="p-4 sm:p-6">
            <div className="flex items-center justify-between">
              <div className="min-w-0 flex-1">
                <p className="text-xs sm:text-sm font-medium text-orange-700 dark:text-orange-300">Total Cost</p>
                <p className="text-2xl sm:text-3xl font-bold text-orange-900 dark:text-white">
                  ${analytics.estimatedCost.toFixed(2)}
                </p>
                <p className="text-xs text-orange-600 dark:text-orange-400">
                  This month
                </p>
              </div>
              <div className="w-10 h-10 sm:w-12 sm:h-12 bg-orange-500 rounded-xl flex items-center justify-center flex-shrink-0">
                <DollarSign className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Detailed Analytics */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6">
        {/* Cost Breakdown */}
        <Card>
          <CardHeader className="pb-3 p-3 sm:p-6">
            <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
              <PieChart className="w-4 h-4 sm:w-5 sm:h-5 text-blue-500" />
              Cost Breakdown
            </CardTitle>
          </CardHeader>
          <CardContent className="p-3 sm:p-6 pt-0">
            <div className="space-y-3">
              <div className="flex justify-between items-center p-3 bg-blue-50 dark:bg-blue-950/30 rounded-lg">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                  <span className="text-sm font-medium">OpenAI API</span>
                </div>
                <span className="text-sm font-bold">${analytics.costBreakdown.openai.toFixed(2)}</span>
              </div>
              
              <div className="flex justify-between items-center p-3 bg-green-50 dark:bg-green-950/30 rounded-lg">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                  <span className="text-sm font-medium">Airtable</span>
                </div>
                <span className="text-sm font-bold">${analytics.costBreakdown.airtable.toFixed(2)}</span>
              </div>
              
              <div className="flex justify-between items-center p-3 bg-gray-50 dark:bg-gray-800/50 rounded-lg border-t">
                <span className="text-sm font-medium">Total</span>
                <span className="text-lg font-bold">${analytics.costBreakdown.total.toFixed(2)}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Performance Metrics */}
        <Card>
          <CardHeader className="pb-3 p-3 sm:p-6">
            <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
              <BarChart3 className="w-4 h-4 sm:w-5 sm:h-5 text-green-500" />
              Performance Metrics
            </CardTitle>
          </CardHeader>
          <CardContent className="p-3 sm:p-6 pt-0">
            <div className="space-y-4">
              {/* Bot Status */}
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600 dark:text-gray-400">Bot Status</span>
                <Badge className={
                  status?.status === 'running' 
                    ? "bg-green-500/20 text-green-700 dark:text-green-300 border-green-400/50"
                    : "bg-red-500/20 text-red-700 dark:text-red-300 border-red-400/50"
                }>
                  {status?.status || 'Unknown'}
                </Badge>
              </div>

              {/* Active Cities */}
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600 dark:text-gray-400">Active Cities</span>
                <span className="text-sm font-medium">{status?.cities?.length || 0}</span>
              </div>

              {/* Leads per Token */}
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600 dark:text-gray-400">Leads per 1K Tokens</span>
                <span className="text-sm font-medium">
                  {analytics.gptTokensUsed > 0 
                    ? ((analytics.monthlyLeads / analytics.gptTokensUsed) * 1000).toFixed(1)
                    : '0'
                  }
                </span>
              </div>

              {/* Cost per Lead */}
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600 dark:text-gray-400">Cost per Lead</span>
                <span className="text-sm font-medium">
                  ${analytics.monthlyLeads > 0 
                    ? (analytics.estimatedCost / analytics.monthlyLeads).toFixed(2)
                    : '0.00'
                  }
                </span>
              </div>

              {/* Today's Activity */}
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600 dark:text-gray-400">Today's Leads</span>
                <span className="text-sm font-medium">{status?.leadsToday || 0}</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Efficiency Insights */}
      <Card>
        <CardHeader className="pb-3 p-3 sm:p-6">
          <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
            <Activity className="w-4 h-4 sm:w-5 sm:h-5 text-purple-500" />
            Efficiency Insights
          </CardTitle>
        </CardHeader>
        <CardContent className="p-3 sm:p-6 pt-0">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="text-center p-4 bg-blue-50 dark:bg-blue-950/30 rounded-lg">
              <Clock className="w-8 h-8 text-blue-500 mx-auto mb-2" />
              <div className="text-2xl font-bold text-blue-900 dark:text-blue-100">
                {avgLeadsPerDay}
              </div>
              <div className="text-xs text-blue-600 dark:text-blue-400">Average Daily Leads</div>
            </div>

            <div className="text-center p-4 bg-green-50 dark:bg-green-950/30 rounded-lg">
              <Database className="w-8 h-8 text-green-500 mx-auto mb-2" />
              <div className="text-2xl font-bold text-green-900 dark:text-green-100">
                {analytics.monthlyLeads > 0 
                  ? Math.round((analytics.gptTokensUsed / analytics.monthlyLeads) * 100) / 100
                  : '0'
                }
              </div>
              <div className="text-xs text-green-600 dark:text-green-400">Tokens per Lead</div>
            </div>

            <div className="text-center p-4 bg-purple-50 dark:bg-purple-950/30 rounded-lg">
              <Bot className="w-8 h-8 text-purple-500 mx-auto mb-2" />
              <div className="text-2xl font-bold text-purple-900 dark:text-purple-100">
                {status?.cities?.length || 0}
              </div>
              <div className="text-xs text-purple-600 dark:text-purple-400">Cities Monitored</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}