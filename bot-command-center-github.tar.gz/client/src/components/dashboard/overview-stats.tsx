import { Card, CardContent } from "@/components/ui/card";
import { Play, Database, TrendingUp, Clock, DollarSign, Brain } from "lucide-react";
import type { DashboardStats } from "@/lib/types";

interface OverviewStatsProps {
  stats?: DashboardStats;
}

export default function OverviewStats({ stats }: OverviewStatsProps) {
  const defaultStats = {
    activeBots: 0,
    totalScraped: 0,
    successRate: "0%",
    avgResponse: "0s",
    dailyGptCost: 0,
    dailyGptTokens: 0,
    dailyGptRequests: 0,
  };

  const displayStats = stats || defaultStats;

  const statCards = [
    {
      title: "Active Bots",
      value: displayStats.activeBots.toString(),
      icon: Play,
      bgColor: "bg-emerald-500/10",
      iconColor: "text-emerald-500",
    },
    {
      title: "Total Scraped",
      value: displayStats.totalScraped.toLocaleString(),
      icon: Database,
      bgColor: "bg-blue-500/10",
      iconColor: "text-blue-500",
    },
    {
      title: "Success Rate",
      value: displayStats.successRate,
      icon: TrendingUp,
      bgColor: "bg-emerald-500/10",
      iconColor: "text-emerald-500",
    },
    {
      title: "GPT Cost Today",
      value: `$${(displayStats.dailyGptCost || 0).toFixed(4)}`,
      icon: DollarSign,
      bgColor: "bg-purple-500/10",
      iconColor: "text-purple-500",
    },
    {
      title: "GPT Tokens",
      value: (displayStats.dailyGptTokens || 0).toLocaleString(),
      icon: Brain,
      bgColor: "bg-indigo-500/10",
      iconColor: "text-indigo-500",
    },
    {
      title: "Avg Response",
      value: displayStats.avgResponse,
      icon: Clock,
      bgColor: "bg-amber-500/10",
      iconColor: "text-amber-500",
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-6 mb-8">
      {statCards.map((stat, index) => (
        <Card key={index} className="bg-slate-900 border-slate-700">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-400 text-sm font-medium">{stat.title}</p>
                <p className="text-xl font-bold text-white mt-1">{stat.value}</p>
              </div>
              <div className={`${stat.bgColor} p-3 rounded-lg`}>
                <stat.icon className={`${stat.iconColor} w-5 h-5`} />
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
