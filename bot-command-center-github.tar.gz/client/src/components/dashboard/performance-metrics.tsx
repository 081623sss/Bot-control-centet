import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import type { SystemMetrics } from "@shared/schema";

interface PerformanceMetricsProps {
  metrics?: SystemMetrics;
}

export default function PerformanceMetrics({ metrics }: PerformanceMetricsProps) {
  const defaultMetrics = {
    cpuUsage: 0,
    memoryUsage: 0,
    networkIo: 0,
  };

  const displayMetrics = metrics || defaultMetrics;

  const getProgressColor = (value: number) => {
    if (value >= 80) return "bg-red-500";
    if (value >= 60) return "bg-amber-500";
    return "bg-emerald-500";
  };

  const performanceItems = [
    {
      label: "CPU Usage",
      value: displayMetrics.cpuUsage,
      color: "bg-blue-500",
    },
    {
      label: "Memory",
      value: displayMetrics.memoryUsage,
      color: "bg-emerald-500",
    },
    {
      label: "Network I/O",
      value: displayMetrics.networkIo,
      color: "bg-amber-500",
    },
  ];

  return (
    <Card className="bg-slate-900 border-slate-700">
      <CardHeader>
        <CardTitle className="text-lg font-semibold text-white">Performance</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {performanceItems.map((item, index) => (
            <div key={index}>
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm text-slate-400">{item.label}</span>
                <span className="text-sm text-white font-medium">{item.value}%</span>
              </div>
              <div className="w-full bg-slate-700 rounded-full h-2">
                <div 
                  className={`${item.color} h-2 rounded-full transition-all duration-500`}
                  style={{ width: `${item.value}%` }}
                ></div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
