import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Terminal, 
  RefreshCw, 
  Download, 
  AlertTriangle, 
  Info, 
  CheckCircle, 
  XCircle,
  Clock,
  Filter
} from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { getQueryFn } from "@/lib/queryClient";
import { useState, useEffect } from "react";
import type { ActivityLog, ErrorLog, BotInstance } from "@shared/schema";
import type { LogType } from "@/lib/types";

interface LogsConsoleProps {
  bots: BotInstance[];
  onRefresh: () => void;
  className?: string;
}

interface LogEntry {
  id: number;
  timestamp: Date;
  level: LogType;
  message: string;
  botId?: number;
  botName?: string;
  source: string;
  details?: string;
}

export default function LogsConsole({ bots, onRefresh, className }: LogsConsoleProps) {
  const [selectedBot, setSelectedBot] = useState<number | "all">("all");
  const [autoRefresh, setAutoRefresh] = useState(true);

  // Get activity logs
  const { data: activityLogs, refetch: refetchLogs } = useQuery({
    queryKey: ['/api/logs'],
    queryFn: getQueryFn({ on401: "returnNull" }),
    refetchInterval: autoRefresh ? 5000 : false, // Auto-refresh every 5 seconds
  });

  // Get error logs
  const { data: errorLogs } = useQuery({
    queryKey: ['/api/error-logs'],
    queryFn: getQueryFn({ on401: "returnNull" }),
    refetchInterval: autoRefresh ? 5000 : false,
  });

  // Combine and format logs
  const combinedLogs: LogEntry[] = [
    // Activity logs
    ...(activityLogs || []).map((log: ActivityLog) => {
      const bot = bots.find(b => b.id === log.botId);
      return {
        id: log.id,
        timestamp: new Date(log.timestamp || Date.now()),
        level: (log.type as LogType) || 'info',
        message: log.message,
        botId: log.botId || undefined,
        botName: bot?.name || 'System',
        source: 'activity',
        details: undefined
      };
    }),
    // Error logs
    ...(errorLogs || []).map((log: ErrorLog) => {
      const bot = bots.find(b => b.id === log.botId);
      return {
        id: log.id + 10000, // Offset to avoid ID conflicts
        timestamp: new Date(log.timestamp || Date.now()),
        level: 'error' as LogType,
        message: log.error,
        botId: log.botId,
        botName: bot?.name || 'Unknown Bot',
        source: 'error',
        details: log.stackTrace || undefined
      };
    })
  ].sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());

  // Filter logs by selected bot
  const filteredLogs = selectedBot === "all" 
    ? combinedLogs 
    : combinedLogs.filter(log => log.botId === selectedBot);

  // Get recent logs (last 10)
  const recentLogs = filteredLogs.slice(0, 10);

  // Group logs by bot for bot-specific view
  const logsByBot = bots.reduce((acc, bot) => {
    acc[bot.id] = combinedLogs
      .filter(log => log.botId === bot.id)
      .slice(0, 10); // Last 10 logs per bot
    return acc;
  }, {} as Record<number, LogEntry[]>);

  const getLogIcon = (level: LogType) => {
    switch (level) {
      case 'error':
        return <XCircle className="w-4 h-4 text-red-400" />;
      case 'warning':
        return <AlertTriangle className="w-4 h-4 text-amber-400" />;
      case 'success':
        return <CheckCircle className="w-4 h-4 text-emerald-400" />;
      default:
        return <Info className="w-4 h-4 text-blue-400" />;
    }
  };

  const getLogColor = (level: LogType) => {
    switch (level) {
      case 'error':
        return 'text-red-300 bg-red-500/10 border-red-500/20';
      case 'warning':
        return 'text-amber-300 bg-amber-500/10 border-amber-500/20';
      case 'success':
        return 'text-emerald-300 bg-emerald-500/10 border-emerald-500/20';
      default:
        return 'text-blue-300 bg-blue-500/10 border-blue-500/20';
    }
  };

  const formatTimestamp = (timestamp: Date) => {
    const now = new Date();
    const diff = now.getTime() - timestamp.getTime();
    const seconds = Math.floor(diff / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);

    if (seconds < 60) return `${seconds}s ago`;
    if (minutes < 60) return `${minutes}m ago`;
    if (hours < 24) return `${hours}h ago`;
    return timestamp.toLocaleDateString();
  };

  const downloadLogs = () => {
    const logData = filteredLogs.map(log => ({
      timestamp: log.timestamp.toISOString(),
      level: log.level,
      bot: log.botName,
      message: log.message,
      details: log.details
    }));

    const blob = new Blob([JSON.stringify(logData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `bot-logs-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleRefresh = () => {
    refetchLogs();
    onRefresh();
  };

  return (
    <div className={`space-y-6 ${className}`}>
      <Card className="bg-slate-900 border-slate-700">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-white flex items-center gap-2">
              <Terminal className="w-5 h-5 text-green-400" />
              Debug Console & Logs
            </CardTitle>
            
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setAutoRefresh(!autoRefresh)}
                className={`border-slate-600 ${autoRefresh ? 'bg-emerald-600/20 text-emerald-400' : ''}`}
              >
                <RefreshCw className={`w-4 h-4 mr-2 ${autoRefresh ? 'animate-spin' : ''}`} />
                Auto-refresh
              </Button>
              
              <Button
                variant="outline"
                size="sm"
                onClick={handleRefresh}
                className="border-slate-600"
              >
                <RefreshCw className="w-4 h-4" />
              </Button>
              
              <Button
                variant="outline"
                size="sm"
                onClick={downloadLogs}
                className="border-slate-600"
              >
                <Download className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </CardHeader>
        
        <CardContent>
          <Tabs defaultValue="combined" className="space-y-4">
            <TabsList className="bg-slate-800">
              <TabsTrigger value="combined" className="data-[state=active]:bg-slate-700">
                All Logs
              </TabsTrigger>
              <TabsTrigger value="by-bot" className="data-[state=active]:bg-slate-700">
                By Bot
              </TabsTrigger>
              <TabsTrigger value="errors" className="data-[state=active]:bg-slate-700">
                Errors Only
              </TabsTrigger>
            </TabsList>

            {/* Bot Filter */}
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <Filter className="w-4 h-4 text-slate-400" />
                <span className="text-slate-400 text-sm">Filter by bot:</span>
              </div>
              
              <div className="flex flex-wrap gap-2">
                <Button
                  variant={selectedBot === "all" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedBot("all")}
                  className={selectedBot === "all" ? "" : "border-slate-600"}
                >
                  All Bots
                </Button>
                
                {bots.map(bot => (
                  <Button
                    key={bot.id}
                    variant={selectedBot === bot.id ? "default" : "outline"}
                    size="sm"
                    onClick={() => setSelectedBot(bot.id)}
                    className={selectedBot === bot.id ? "" : "border-slate-600"}
                  >
                    {bot.name}
                  </Button>
                ))}
              </div>
            </div>

            {/* Combined Logs View */}
            <TabsContent value="combined" className="space-y-4">
              <div className="bg-slate-800 rounded-lg p-4">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-white font-medium">Recent Activity</h3>
                  <Badge variant="outline" className="text-slate-400 border-slate-600">
                    {recentLogs.length} entries
                  </Badge>
                </div>
                
                <ScrollArea className="h-[400px]">
                  <div className="space-y-2">
                    {recentLogs.length > 0 ? (
                      recentLogs.map((log) => (
                        <div
                          key={`${log.source}-${log.id}`}
                          className={`p-3 rounded-lg border ${getLogColor(log.level)}`}
                        >
                          <div className="flex items-start gap-3">
                            {getLogIcon(log.level)}
                            
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2 mb-1">
                                <span className="font-medium text-white text-sm">
                                  {log.botName}
                                </span>
                                <Badge variant="outline" className="text-xs border-current">
                                  {log.level}
                                </Badge>
                                <span className="text-slate-400 text-xs flex items-center gap-1">
                                  <Clock className="w-3 h-3" />
                                  {formatTimestamp(log.timestamp)}
                                </span>
                              </div>
                              
                              <p className="text-sm leading-relaxed">
                                {log.message}
                              </p>
                              
                              {log.details && (
                                <details className="mt-2">
                                  <summary className="text-xs text-slate-400 cursor-pointer hover:text-slate-300">
                                    Stack trace
                                  </summary>
                                  <pre className="mt-2 text-xs bg-slate-900 p-2 rounded overflow-x-auto">
                                    {log.details}
                                  </pre>
                                </details>
                              )}
                            </div>
                          </div>
                        </div>
                      ))
                    ) : (
                      <div className="text-center py-8">
                        <Terminal className="w-12 h-12 text-slate-600 mx-auto mb-4" />
                        <p className="text-slate-400">No logs available</p>
                        <p className="text-slate-500 text-sm">Logs will appear here when bots are active</p>
                      </div>
                    )}
                  </div>
                </ScrollArea>
              </div>
            </TabsContent>

            {/* By Bot View */}
            <TabsContent value="by-bot" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {bots.map(bot => (
                  <Card key={bot.id} className="bg-slate-800 border-slate-600">
                    <CardHeader className="pb-3">
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-white text-lg">{bot.name}</CardTitle>
                        <Badge variant="outline" className="text-slate-400 border-slate-600">
                          {logsByBot[bot.id]?.length || 0} logs
                        </Badge>
                      </div>
                    </CardHeader>
                    
                    <CardContent>
                      <ScrollArea className="h-[200px]">
                        <div className="space-y-2">
                          {logsByBot[bot.id]?.length > 0 ? (
                            logsByBot[bot.id].map((log) => (
                              <div
                                key={`bot-${bot.id}-${log.source}-${log.id}`}
                                className="p-2 rounded border border-slate-700 bg-slate-900"
                              >
                                <div className="flex items-center gap-2 mb-1">
                                  {getLogIcon(log.level)}
                                  <Badge variant="outline" className="text-xs border-current">
                                    {log.level}
                                  </Badge>
                                  <span className="text-slate-400 text-xs">
                                    {formatTimestamp(log.timestamp)}
                                  </span>
                                </div>
                                <p className="text-sm text-slate-300">{log.message}</p>
                              </div>
                            ))
                          ) : (
                            <p className="text-slate-500 text-sm text-center py-4">
                              No logs for this bot
                            </p>
                          )}
                        </div>
                      </ScrollArea>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            {/* Errors Only View */}
            <TabsContent value="errors" className="space-y-4">
              <div className="bg-slate-800 rounded-lg p-4">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-white font-medium">Error Logs</h3>
                  <Badge variant="outline" className="text-red-400 border-red-500/50">
                    {filteredLogs.filter(log => log.level === 'error').length} errors
                  </Badge>
                </div>
                
                <ScrollArea className="h-[400px]">
                  <div className="space-y-2">
                    {filteredLogs.filter(log => log.level === 'error').length > 0 ? (
                      filteredLogs
                        .filter(log => log.level === 'error')
                        .slice(0, 20)
                        .map((log) => (
                          <div
                            key={`error-${log.source}-${log.id}`}
                            className="p-3 rounded-lg border border-red-500/20 bg-red-500/10"
                          >
                            <div className="flex items-start gap-3">
                              <XCircle className="w-4 h-4 text-red-400 mt-0.5" />
                              
                              <div className="flex-1">
                                <div className="flex items-center gap-2 mb-1">
                                  <span className="font-medium text-white text-sm">
                                    {log.botName}
                                  </span>
                                  <span className="text-red-400 text-xs">
                                    {formatTimestamp(log.timestamp)}
                                  </span>
                                </div>
                                
                                <p className="text-sm text-red-300 leading-relaxed">
                                  {log.message}
                                </p>
                                
                                {log.details && (
                                  <details className="mt-2">
                                    <summary className="text-xs text-red-400 cursor-pointer hover:text-red-300">
                                      Stack trace
                                    </summary>
                                    <pre className="mt-2 text-xs bg-slate-900 p-2 rounded overflow-x-auto text-red-300">
                                      {log.details}
                                    </pre>
                                  </details>
                                )}
                              </div>
                            </div>
                          </div>
                        ))
                    ) : (
                      <div className="text-center py-8">
                        <CheckCircle className="w-12 h-12 text-emerald-500 mx-auto mb-4" />
                        <p className="text-emerald-400">No errors found</p>
                        <p className="text-slate-500 text-sm">All bots are running smoothly</p>
                      </div>
                    )}
                  </div>
                </ScrollArea>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}