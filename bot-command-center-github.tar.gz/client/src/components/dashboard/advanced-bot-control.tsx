import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { 
  Play, 
  Square, 
  RotateCcw, 
  Camera, 
  Plus, 
  ExternalLink, 
  Facebook, 
  MessageSquare,
  Github,
  AlertTriangle,
  DollarSign,
  Brain,
  Clock,
  Target,
  Zap
} from "lucide-react";
import { useMutation, useQueryClient, useQuery } from "@tanstack/react-query";
import { apiRequest, botCommand, checkBotConnection } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useState, useEffect } from "react";
import type { BotInstance, ErrorLog } from "@shared/schema";
import type { BotStatus, Platform, ProcessResult } from "@/lib/types";

interface AdvancedBotControlProps {
  bots: BotInstance[];
  onRefresh: () => void;
  onLogRefresh: () => void;
}

interface BotPrompt {
  botType: string;
  prompt: string;
}

const FLORIDA_CITIES = [
  "Miami", "Orlando", "Tampa", "Jacksonville", "Fort Lauderdale",
  "St. Petersburg", "Hialeah", "Tallahassee", "Cape Coral", "Port St. Lucie",
  "Pembroke Pines", "Hollywood", "Gainesville", "Coral Springs", "Brandon"
];

const BOT_TYPES = [
  { id: "scraper", name: "City Scraper", icon: ExternalLink, platforms: ["craigslist", "facebook", "offerup", "reddit"] },
  { id: "enrichment", name: "Enrichment Bot", icon: Brain, platforms: ["api"] },
  { id: "outreach", name: "Outreach Bot", icon: Target, platforms: ["email"] },
  { id: "matching", name: "Matching Bot", icon: Zap, platforms: ["api"] }
];

const DEFAULT_PROMPTS = {
  enrichment: `You are an expert lead enrichment specialist. For each lead provided:

1. Research the person's professional background
2. Identify their company and role
3. Find relevant contact information
4. Assess their potential interest level
5. Suggest personalized talking points

Return structured data with confidence scores for each field.`,
  
  outreach: `You are a professional outreach specialist for real estate lead generation.

Create personalized, compelling messages that:
1. Reference specific details about their property search
2. Highlight relevant market insights
3. Offer genuine value (market reports, listings, etc.)
4. Include a soft call-to-action
5. Maintain a conversational, helpful tone

Keep messages under 150 words and avoid being pushy.`,
  
  matching: `You are an intelligent matching system for real estate leads.

For each lead, analyze:
1. Budget range and financing capability
2. Location preferences and commute needs
3. Property type and feature requirements
4. Timeline urgency
5. Lifestyle factors

Score potential property matches (1-10) and explain reasoning.
Prioritize high-probability matches with detailed justification.`
};

export default function AdvancedBotControl({ bots, onRefresh, onLogRefresh }: AdvancedBotControlProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedCity, setSelectedCity] = useState<string>("");
  const [customCity, setCustomCity] = useState<string>("");
  const [selectedPlatform, setSelectedPlatform] = useState<Platform>("craigslist");
  const [selectedBot, setSelectedBot] = useState<BotInstance | null>(null);
  const [prompts, setPrompts] = useState<Record<string, string>>({});
  const [activePromptTab, setActivePromptTab] = useState("enrichment");
  
  // New configuration states
  const [leadAmount, setLeadAmount] = useState<number>(50);
  const [startTime, setStartTime] = useState<string>("09:00");
  const [endTime, setEndTime] = useState<string>("17:00");
  const [scheduleEnabled, setScheduleEnabled] = useState<boolean>(false);

  // Load prompts from localStorage on mount
  useEffect(() => {
    const savedPrompts = localStorage.getItem('bot-prompts');
    if (savedPrompts) {
      setPrompts(JSON.parse(savedPrompts));
    } else {
      setPrompts(DEFAULT_PROMPTS);
    }
  }, []);

  // Save prompts to localStorage whenever they change
  useEffect(() => {
    if (Object.keys(prompts).length > 0) {
      localStorage.setItem('bot-prompts', JSON.stringify(prompts));
    }
  }, [prompts]);

  // Connection status for each bot
  const [connectionStatus, setConnectionStatus] = useState<Record<string, boolean>>({});

  // Check connection status for all bots
  useEffect(() => {
    const checkConnections = async () => {
      const statuses: Record<string, boolean> = {};
      for (const bot of bots) {
        try {
          statuses[bot.name] = await checkBotConnection(bot.name);
        } catch {
          statuses[bot.name] = false;
        }
      }
      setConnectionStatus(statuses);
    };

    checkConnections();
    const interval = setInterval(checkConnections, 10000); // Check every 10 seconds
    return () => clearInterval(interval);
  }, [bots]);

  // Get platform icon
  const getPlatformIcon = (platform: string) => {
    const icons = {
      craigslist: ExternalLink,
      facebook: Facebook,
      offerup: Github,
      reddit: MessageSquare
    };
    return icons[platform as keyof typeof icons] || ExternalLink;
  };

  // Bot control mutations - Connected to Termius server via Ngrok
  const startBotMutation = useMutation({
    mutationFn: async (bot: BotInstance) => {
      return await botCommand(bot.name, "start", {
        city: bot.city,
        platform: bot.platform,
        config: {
          dailyLeadTarget: bot.dailyLeadTarget,
          scheduleStartTime: bot.scheduleStartTime,
          scheduleEndTime: bot.scheduleEndTime,
          timezone: bot.timezone
        }
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/bots'] });
      queryClient.invalidateQueries({ queryKey: ['/api/stats'] });
      onRefresh();
      onLogRefresh();
      toast({
        title: "Bot Started",
        description: "Bot has been started successfully on Termius server.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Start Failed",
        description: error?.message || "Failed to start bot on Termius server.",
        variant: "destructive",
      });
    },
  });

  const stopBotMutation = useMutation({
    mutationFn: async (bot: BotInstance) => {
      return await botCommand(bot.name, "stop");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/bots'] });
      queryClient.invalidateQueries({ queryKey: ['/api/stats'] });
      onRefresh();
      onLogRefresh();
      toast({
        title: "Bot Stopped",
        description: "Bot has been stopped successfully on Termius server.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Stop Failed",
        description: error?.message || "Failed to stop bot on Termius server.",
        variant: "destructive",
      });
    },
  });

  const rollbackBotMutation = useMutation({
    mutationFn: async ({ bot, version }: { bot: BotInstance; version: string }) => {
      return await botCommand(bot.name, "rollback", { version });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/bots'] });
      onRefresh();
      onLogRefresh();
      setSelectedBot(null);
      toast({
        title: "Rollback Complete",
        description: "Bot has been rolled back successfully on Termius server.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Rollback Failed",
        description: error?.message || "Failed to rollback bot on Termius server.",
        variant: "destructive",
      });
    },
  });

  const createBotMutation = useMutation({
    mutationFn: async ({ city, platform }: { city: string; platform: Platform }) => {
      const config = {
        leadTarget: leadAmount,
        schedule: scheduleEnabled ? {
          enabled: true,
          startTime,
          endTime,
          timezone: Intl.DateTimeFormat().resolvedOptions().timeZone
        } : {
          enabled: false
        }
      };

      return await apiRequest("/api/bots", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: `${city} ${platform.charAt(0).toUpperCase() + platform.slice(1)} Bot`,
          city,
          platform,
          status: "stopped",
          dailyCount: 0,
          totalScraped: 0,
          successRate: 0,
          progress: 0,
          version: "1.0.0",
          config
        }),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/bots'] });
      queryClient.invalidateQueries({ queryKey: ['/api/stats'] });
      onRefresh();
      onLogRefresh();
      setSelectedCity("");
      setCustomCity("");
      toast({
        title: "Bot Created",
        description: "New bot instance created successfully.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Creation Failed",
        description: error?.message || "Failed to create bot.",
        variant: "destructive",
      });
    },
  });

  // Get snapshots for rollback
  const { data: snapshots } = useQuery({
    queryKey: ['/api/bots', selectedBot?.id, 'snapshots'],
    enabled: !!selectedBot,
  });

  // Get error logs for selected bot
  const { data: errorLogs } = useQuery({
    queryKey: ['/api/error-logs', selectedBot?.id],
    enabled: !!selectedBot,
  });

  const handleCreateBot = () => {
    const city = customCity.trim() || selectedCity;
    if (city && selectedPlatform) {
      createBotMutation.mutate({ city, platform: selectedPlatform });
    } else {
      toast({
        title: "Missing Information",
        description: "Please select a city and platform.",
        variant: "destructive",
      });
    }
  };

  const handleRollback = (version: string) => {
    if (selectedBot) {
      rollbackBotMutation.mutate({ bot: selectedBot, version });
    }
  };

  const handleSnapshotBot = async (bot: BotInstance) => {
    try {
      await botCommand(bot.name, "snapshot");
      toast({
        title: "Snapshot Created",
        description: "Bot snapshot created successfully on Termius server.",
      });
    } catch (error) {
      toast({
        title: "Snapshot Failed",
        description: "Failed to create bot snapshot on Termius server.",
        variant: "destructive",
      });
    }
  };

  const updatePrompt = (botType: string, newPrompt: string) => {
    setPrompts(prev => ({
      ...prev,
      [botType]: newPrompt
    }));
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "running":
        return "bg-emerald-500/10 text-emerald-500 border-emerald-500/20";
      case "paused":
        return "bg-amber-500/10 text-amber-500 border-amber-500/20";
      case "stopped":
        return "bg-slate-500/10 text-slate-400 border-slate-500/20";
      case "crashed":
      case "error":
        return "bg-red-500/10 text-red-500 border-red-500/20";
      default:
        return "bg-slate-500/10 text-slate-400 border-slate-500/20";
    }
  };

  const getStatusDot = (status: string) => {
    switch (status) {
      case "running":
        return "bg-emerald-500 animate-pulse";
      case "paused":
        return "bg-amber-500";
      case "stopped":
        return "bg-slate-500";
      case "crashed":
      case "error":
        return "bg-red-500";
      default:
        return "bg-slate-500";
    }
  };

  const formatLastRun = (lastRun: Date | null) => {
    if (!lastRun) return "Never";
    const now = new Date();
    const diff = now.getTime() - new Date(lastRun).getTime();
    const minutes = Math.floor(diff / 60000);
    if (minutes < 1) return "Just now";
    if (minutes < 60) return `${minutes} min ago`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `${hours} hour${hours > 1 ? 's' : ''} ago`;
    const days = Math.floor(hours / 24);
    return `${days} day${days > 1 ? 's' : ''} ago`;
  };

  // Group bots by type and platform
  const groupedBots = bots.reduce((acc, bot) => {
    const key = `${bot.platform}-${bot.city}`;
    if (!acc[key]) {
      acc[key] = [];
    }
    acc[key].push(bot);
    return acc;
  }, {} as Record<string, BotInstance[]>);

  return (
    <div className="space-y-6">
      {/* Bot Creation Section */}
      <Card className="bg-slate-900 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Plus className="w-5 h-5" />
            Launch New Bot
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <Label className="text-slate-300">Platform</Label>
              <Select value={selectedPlatform} onValueChange={(value: Platform) => setSelectedPlatform(value)}>
                <SelectTrigger className="bg-slate-800 border-slate-600 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-slate-800 border-slate-600">
                  <SelectItem value="craigslist">Craigslist</SelectItem>
                  <SelectItem value="facebook">Facebook Marketplace</SelectItem>
                  <SelectItem value="offerup">OfferUp</SelectItem>
                  <SelectItem value="reddit">Reddit</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label className="text-slate-300">Select City</Label>
              <Select value={selectedCity} onValueChange={setSelectedCity}>
                <SelectTrigger className="bg-slate-800 border-slate-600 text-white">
                  <SelectValue placeholder="Choose city..." />
                </SelectTrigger>
                <SelectContent className="bg-slate-800 border-slate-600">
                  {FLORIDA_CITIES.map(city => (
                    <SelectItem key={city} value={city}>{city}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label className="text-slate-300">Or Type City</Label>
              <Input
                value={customCity}
                onChange={(e) => setCustomCity(e.target.value)}
                placeholder="Enter custom city..."
                className="bg-slate-800 border-slate-600 text-white placeholder:text-slate-400"
              />
            </div>

            {/* Lead Amount Configuration */}
            <div>
              <Label className="text-slate-300">Daily Lead Target</Label>
              <div className="flex items-center gap-2">
                <Input
                  type="number"
                  value={leadAmount}
                  onChange={(e) => setLeadAmount(parseInt(e.target.value) || 50)}
                  min="10"
                  max="500"
                  className="bg-slate-800 border-slate-600 text-white"
                />
                <span className="text-slate-400 text-sm">leads/day</span>
              </div>
            </div>

            {/* Schedule Configuration */}
            <div>
              <div className="flex items-center gap-2 mb-3">
                <input
                  type="checkbox"
                  checked={scheduleEnabled}
                  onChange={(e) => setScheduleEnabled(e.target.checked)}
                  className="rounded border-slate-600 bg-slate-800"
                />
                <Label className="text-slate-300">Schedule Bot Hours</Label>
              </div>
              
              {scheduleEnabled && (
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label className="text-slate-400 text-xs">Start Time</Label>
                    <Input
                      type="time"
                      value={startTime}
                      onChange={(e) => setStartTime(e.target.value)}
                      className="bg-slate-800 border-slate-600 text-white"
                    />
                  </div>
                  <div>
                    <Label className="text-slate-400 text-xs">End Time</Label>
                    <Input
                      type="time"
                      value={endTime}
                      onChange={(e) => setEndTime(e.target.value)}
                      className="bg-slate-800 border-slate-600 text-white"
                    />
                  </div>
                </div>
              )}
            </div>
            
            <div className="flex items-end">
              <Button 
                onClick={handleCreateBot}
                className="w-full bg-blue-600 hover:bg-blue-700"
                disabled={createBotMutation.isPending}
              >
                {createBotMutation.isPending ? "Creating..." : "Launch Bot"}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Bot Control Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {Object.entries(groupedBots).map(([key, cityBots]) => {
          const bot = cityBots[0]; // Use first bot for display
          const PlatformIcon = getPlatformIcon(bot.platform);
          
          return (
            <Card key={key} className="bg-slate-900 border-slate-700 hover:border-slate-600 transition-colors">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-slate-800 rounded-lg">
                      <PlatformIcon className="w-5 h-5 text-blue-400" />
                    </div>
                    <div>
                      <CardTitle className="text-white text-lg">{bot.name}</CardTitle>
                      <p className="text-slate-400 text-sm">{bot.city} • {bot.platform}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <div className={`w-3 h-3 rounded-full ${getStatusDot(bot.status)}`} />
                    <Badge className={getStatusColor(bot.status)} variant="outline">
                      {bot.status}
                    </Badge>
                    {/* Termius Server Connection Status */}
                    <div className="flex items-center gap-1">
                      <div className={`w-2 h-2 rounded-full ${
                        connectionStatus[bot.name] 
                          ? 'bg-emerald-500 animate-pulse' 
                          : 'bg-red-500'
                      }`} />
                      <span className={`text-xs ${
                        connectionStatus[bot.name] 
                          ? 'text-emerald-400' 
                          : 'text-red-400'
                      }`}>
                        {connectionStatus[bot.name] ? 'Connected' : 'Disconnected'}
                      </span>
                    </div>
                  </div>
                </div>
              </CardHeader>
              
              <CardContent className="space-y-4">
                {/* Stats Grid */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-slate-800 p-3 rounded-lg">
                    <p className="text-slate-400 text-xs">Scraped Today</p>
                    <p className="text-white text-xl font-bold">{bot.dailyCount}</p>
                  </div>
                  <div className="bg-slate-800 p-3 rounded-lg">
                    <p className="text-slate-400 text-xs">Success Rate</p>
                    <p className="text-white text-xl font-bold">{bot.successRate}%</p>
                  </div>
                </div>
                
                {/* Progress */}
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span className="text-slate-400">Progress</span>
                    <span className="text-white">{bot.progress}%</span>
                  </div>
                  <Progress value={bot.progress} className="h-2" />
                </div>
                
                {/* Last Run */}
                <div className="flex items-center gap-2 text-sm">
                  <Clock className="w-4 h-4 text-slate-400" />
                  <span className="text-slate-400">Last run:</span>
                  <span className="text-white">{formatLastRun(bot.lastRun)}</span>
                </div>
                
                {/* Action Buttons */}
                <div className="flex gap-2">
                  {bot.status === "running" ? (
                    <Button
                      onClick={() => stopBotMutation.mutate(bot)}
                      variant="destructive"
                      size="sm"
                      className="flex-1"
                      disabled={stopBotMutation.isPending}
                    >
                      <Square className="w-4 h-4 mr-2" />
                      Stop
                    </Button>
                  ) : (
                    <Button
                      onClick={() => startBotMutation.mutate(bot)}
                      variant="default"
                      size="sm"
                      className="flex-1 bg-emerald-600 hover:bg-emerald-700"
                      disabled={startBotMutation.isPending}
                    >
                      <Play className="w-4 h-4 mr-2" />
                      Start
                    </Button>
                  )}
                  
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button
                        variant="outline"
                        size="sm"
                        className="border-slate-600"
                        onClick={() => setSelectedBot(bot)}
                      >
                        <RotateCcw className="w-4 h-4" />
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="bg-slate-900 border-slate-700">
                      <DialogHeader>
                        <DialogTitle className="text-white">Rollback {bot.name}</DialogTitle>
                      </DialogHeader>
                      <div className="space-y-4">
                        {snapshots && snapshots.length > 0 ? (
                          <div className="space-y-2">
                            {snapshots.slice(0, 5).map((snapshot: any) => (
                              <Button
                                key={snapshot.filename}
                                variant="outline"
                                className="w-full justify-between border-slate-600"
                                onClick={() => handleRollback(snapshot.version)}
                              >
                                <span>{snapshot.version}</span>
                                <span className="text-slate-400 text-sm">
                                  {new Date(snapshot.created).toLocaleString()}
                                </span>
                              </Button>
                            ))}
                          </div>
                        ) : (
                          <p className="text-slate-400 text-center py-4">No snapshots available</p>
                        )}
                      </div>
                    </DialogContent>
                  </Dialog>
                  
                  <Button
                    onClick={() => handleSnapshotBot(bot)}
                    variant="outline"
                    size="sm"
                    className="border-slate-600"
                  >
                    <Camera className="w-4 h-4" />
                  </Button>
                </div>
                
                {/* Error Display */}
                {bot.lastError && (
                  <div className="flex items-start gap-2 p-3 bg-red-500/10 border border-red-500/20 rounded-lg">
                    <AlertTriangle className="w-4 h-4 text-red-400 mt-0.5 flex-shrink-0" />
                    <div className="text-sm">
                      <p className="text-red-400 font-medium">Last Error:</p>
                      <p className="text-red-300">{bot.lastError}</p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* GPT Prompt Editor */}
      <Card className="bg-slate-900 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Brain className="w-5 h-5" />
            Bot Prompt Editor
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs value={activePromptTab} onValueChange={setActivePromptTab}>
            <TabsList className="bg-slate-800">
              <TabsTrigger value="enrichment" className="data-[state=active]:bg-slate-700">
                Enrichment Bot
              </TabsTrigger>
              <TabsTrigger value="outreach" className="data-[state=active]:bg-slate-700">
                Outreach Bot
              </TabsTrigger>
              <TabsTrigger value="matching" className="data-[state=active]:bg-slate-700">
                Matching Bot
              </TabsTrigger>
            </TabsList>
            
            {Object.keys(DEFAULT_PROMPTS).map(botType => (
              <TabsContent key={botType} value={botType} className="space-y-4">
                <div>
                  <Label className="text-slate-300">
                    {botType.charAt(0).toUpperCase() + botType.slice(1)} Bot Instructions
                  </Label>
                  <Textarea
                    value={prompts[botType] || DEFAULT_PROMPTS[botType as keyof typeof DEFAULT_PROMPTS]}
                    onChange={(e) => updatePrompt(botType, e.target.value)}
                    className="mt-2 bg-slate-800 border-slate-600 text-white min-h-[200px]"
                    placeholder="Enter bot instructions..."
                  />
                </div>
                <Button
                  onClick={() => {
                    toast({
                      title: "Prompt Saved",
                      description: `${botType} bot prompt updated successfully.`,
                    });
                  }}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  Save Prompt
                </Button>
              </TabsContent>
            ))}
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}