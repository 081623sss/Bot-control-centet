import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { 
  Tabs, TabsContent, TabsList, TabsTrigger 
} from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';

// Icons
import { 
  Code2, FolderTree, Users, Database, MessageSquare, AlertTriangle, 
  Brain, Settings, Play, Pause, RotateCcw, Download, RefreshCw,
  Edit, Save, X, Plus, Trash2, Eye, Copy, Zap, Terminal,
  Bot, Smartphone, Monitor, Clock, Target, MapPin, MessageCircle,
  CheckCircle, XCircle, AlertCircle, Info, Cpu, Activity,
  FileCode, FileJson, FileText, Folder, ChevronRight, ChevronDown
} from 'lucide-react';

import type { BotInstance, GptPrompt, BotFile, Alert as AlertType, User, Subscription } from '@shared/schema';
import { GPTFeatures } from './gpt-features';

interface AdvancedFeaturesDashboardProps {
  onClose?: () => void;
}

export function AdvancedFeaturesDashboard({ onClose }: AdvancedFeaturesDashboardProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedBot, setSelectedBot] = useState<BotInstance | null>(null);
  const [activeTab, setActiveTab] = useState('gpt-editor');

  // Fetch data
  const { data: bots = [], isLoading: botsLoading } = useQuery({
    queryKey: ['/api/bots'],
  });

  const { data: alerts = [], isLoading: alertsLoading } = useQuery({
    queryKey: ['/api/alerts'],
  });

  const { data: prompts = [], isLoading: promptsLoading } = useQuery({
    queryKey: ['/api/gpt-prompts'],
  });

  const { data: subscriptions = [], isLoading: subscriptionsLoading } = useQuery({
    queryKey: ['/api/subscriptions'],
  });

  return (
    <div className="min-h-screen bg-slate-950 text-white p-4">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <Bot className="w-8 h-8 text-blue-400" />
          <div>
            <h1 className="text-2xl font-bold text-white">Advanced Bot Command Center</h1>
            <p className="text-slate-400">GPT-4 Editor • File Management • AI Assistant • Health Monitoring</p>
          </div>
        </div>
        {onClose && (
          <Button onClick={onClose} variant="outline" size="sm" className="border-slate-600">
            <X className="w-4 h-4" />
          </Button>
        )}
      </div>

      {/* Alert Banner */}
      <AlertBanner alerts={alerts} />

      {/* Main Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-4 lg:grid-cols-8 bg-slate-800 border-slate-700">
          <TabsTrigger value="gpt-editor" className="flex items-center gap-2">
            <Code2 className="w-4 h-4" />
            <span className="hidden sm:inline">GPT Editor</span>
          </TabsTrigger>
          <TabsTrigger value="file-tree" className="flex items-center gap-2">
            <FolderTree className="w-4 h-4" />
            <span className="hidden sm:inline">Files</span>
          </TabsTrigger>
          <TabsTrigger value="subscriptions" className="flex items-center gap-2">
            <Users className="w-4 h-4" />
            <span className="hidden sm:inline">Clients</span>
          </TabsTrigger>
          <TabsTrigger value="supabase" className="flex items-center gap-2">
            <Database className="w-4 h-4" />
            <span className="hidden sm:inline">Database</span>
          </TabsTrigger>
          <TabsTrigger value="ai-assistant" className="flex items-center gap-2">
            <MessageSquare className="w-4 h-4" />
            <span className="hidden sm:inline">AI Assistant</span>
          </TabsTrigger>
          <TabsTrigger value="health" className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4" />
            <span className="hidden sm:inline">Health</span>
          </TabsTrigger>
          <TabsTrigger value="prompts" className="flex items-center gap-2">
            <Brain className="w-4 h-4" />
            <span className="hidden sm:inline">Prompts</span>
          </TabsTrigger>
          <TabsTrigger value="dev-tools" className="flex items-center gap-2">
            <Settings className="w-4 h-4" />
            <span className="hidden sm:inline">Dev Tools</span>
          </TabsTrigger>
        </TabsList>

        {/* 1. GPT-4 Features */}
        <TabsContent value="gpt-editor">
          <GPTFeatures />
        </TabsContent>

        {/* 2. Bot File Tree Viewer */}
        <TabsContent value="file-tree">
          <BotFileTreeViewer bots={bots} selectedBot={selectedBot} setSelectedBot={setSelectedBot} />
        </TabsContent>

        {/* 3. Subscription Bot Manager */}
        <TabsContent value="subscriptions">
          <SubscriptionBotManager subscriptions={subscriptions} bots={bots} />
        </TabsContent>

        {/* 4. Supabase Sync */}
        <TabsContent value="supabase">
          <SupabaseSync />
        </TabsContent>

        {/* 5. Copilot AI Assistant */}
        <TabsContent value="ai-assistant">
          <CopilotAIAssistant bots={bots} />
        </TabsContent>

        {/* 6. Alerts & Health */}
        <TabsContent value="health">
          <AlertsHealthMonitoring alerts={alerts} bots={bots} />
        </TabsContent>

        {/* 7. GPT Prompt Manager */}
        <TabsContent value="prompts">
          <GPTPromptManager prompts={prompts} />
        </TabsContent>

        {/* 8. Dev Tools */}
        <TabsContent value="dev-tools">
          <DevTools bots={bots} />
        </TabsContent>
      </Tabs>
    </div>
  );
}

// Alert Banner Component
function AlertBanner({ alerts }: { alerts: AlertType[] }) {
  const criticalAlerts = alerts.filter(alert => alert.severity === 'critical' && !alert.isResolved);
  
  if (criticalAlerts.length === 0) return null;

  return (
    <Alert className="mb-6 border-red-500/50 bg-red-500/10">
      <AlertTriangle className="h-4 w-4 text-red-400" />
      <AlertDescription className="text-red-300">
        <strong>{criticalAlerts.length} Critical Alert{criticalAlerts.length > 1 ? 's' : ''}</strong>
        {criticalAlerts.slice(0, 2).map(alert => (
          <div key={alert.id} className="mt-1 text-sm">
            • {alert.title}: {alert.message}
          </div>
        ))}
        {criticalAlerts.length > 2 && (
          <div className="text-sm mt-1">• +{criticalAlerts.length - 2} more alerts</div>
        )}
      </AlertDescription>
    </Alert>
  );
}

// Feature 1: GPT-4 Bot Editor
function GPTBotEditor({ bots, selectedBot, setSelectedBot }: {
  bots: BotInstance[];
  selectedBot: BotInstance | null;
  setSelectedBot: (bot: BotInstance | null) => void;
}) {
  const [editingScript, setEditingScript] = useState('');
  const [gptPrompt, setGptPrompt] = useState('');
  const [showDiff, setShowDiff] = useState(false);
  const [generatedCode, setGeneratedCode] = useState('');
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // GPT-4 code generation mutation
  const generateCodeMutation = useMutation({
    mutationFn: async (prompt: string) => {
      const response = await apiRequest(`${import.meta.env.VITE_API_BASE}/gpt-generate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          bot: selectedBot?.name,
          prompt,
          currentCode: editingScript,
          type: 'script_generation'
        })
      });
      return response;
    },
    onSuccess: (data) => {
      setGeneratedCode(data.generatedCode);
      setShowDiff(true);
      toast({
        title: "GPT-4 Code Generated",
        description: "Review the changes and approve to update the bot script."
      });
    },
    onError: (error) => {
      toast({
        title: "GPT Generation Failed",
        description: error.message,
        variant: "destructive"
      });
    }
  });

  // Apply changes mutation
  const applyChangesMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest(`${import.meta.env.VITE_API_BASE}/bot-update-script`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          bot: selectedBot?.name,
          newScript: generatedCode,
          backup: true
        })
      });
      return response;
    },
    onSuccess: () => {
      setEditingScript(generatedCode);
      setShowDiff(false);
      setGeneratedCode('');
      queryClient.invalidateQueries({ queryKey: ['/api/bots'] });
      toast({
        title: "Script Updated",
        description: "Bot script has been successfully updated with GPT-4 generated code."
      });
    },
    onError: (error) => {
      toast({
        title: "Update Failed",
        description: error.message,
        variant: "destructive"
      });
    }
  });

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Bot Selection */}
      <Card className="bg-slate-900 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Code2 className="w-5 h-5 text-blue-400" />
            Select Bot to Edit
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          {bots.map((bot) => (
            <Button
              key={bot.id}
              variant={selectedBot?.id === bot.id ? "default" : "outline"}
              className={`w-full justify-start ${
                selectedBot?.id === bot.id 
                  ? 'bg-blue-600 border-blue-500' 
                  : 'border-slate-600 hover:border-slate-500'
              }`}
              onClick={() => {
                setSelectedBot(bot);
                setEditingScript('// Loading bot script...');
              }}
            >
              <div className="flex items-center gap-2">
                <div className={`w-2 h-2 rounded-full ${
                  bot.status === 'running' ? 'bg-green-400' : 'bg-red-400'
                }`} />
                <div className="text-left">
                  <div className="font-medium">{bot.name}</div>
                  <div className="text-sm text-slate-400">{bot.city} • {bot.platform}</div>
                </div>
              </div>
            </Button>
          ))}
        </CardContent>
      </Card>

      {/* GPT-4 Prompt Interface */}
      <Card className="bg-slate-900 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Brain className="w-5 h-5 text-purple-400" />
            GPT-4 Code Assistant
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Textarea
            placeholder="Describe what you want to modify in the bot script..."
            value={gptPrompt}
            onChange={(e) => setGptPrompt(e.target.value)}
            className="bg-slate-800 border-slate-600 text-white min-h-[120px]"
          />
          <Button
            onClick={() => generateCodeMutation.mutate(gptPrompt)}
            disabled={!selectedBot || !gptPrompt.trim() || generateCodeMutation.isPending}
            className="w-full bg-purple-600 hover:bg-purple-700"
          >
            {generateCodeMutation.isPending ? (
              <>
                <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                Generating...
              </>
            ) : (
              <>
                <Zap className="w-4 h-4 mr-2" />
                Generate with GPT-4
              </>
            )}
          </Button>

          {/* Quick Prompts */}
          <div className="space-y-2">
            <p className="text-sm text-slate-400">Quick Actions:</p>
            {[
              "Add error handling for network timeouts",
              "Optimize scraping performance",
              "Add more detailed logging",
              "Improve data validation"
            ].map((quickPrompt) => (
              <Button
                key={quickPrompt}
                variant="outline"
                size="sm"
                className="w-full justify-start text-left border-slate-600 text-slate-300"
                onClick={() => setGptPrompt(quickPrompt)}
              >
                {quickPrompt}
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Code Editor & Diff Viewer */}
      <Card className="bg-slate-900 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center justify-between">
            <div className="flex items-center gap-2">
              <FileCode className="w-5 h-5 text-green-400" />
              {showDiff ? 'Code Diff Preview' : 'Current Script'}
            </div>
            {showDiff && (
              <div className="flex gap-2">
                <Button
                  onClick={() => applyChangesMutation.mutate()}
                  disabled={applyChangesMutation.isPending}
                  size="sm"
                  className="bg-green-600 hover:bg-green-700"
                >
                  <CheckCircle className="w-4 h-4 mr-1" />
                  Apply
                </Button>
                <Button
                  onClick={() => setShowDiff(false)}
                  size="sm"
                  variant="outline"
                  className="border-slate-600"
                >
                  <X className="w-4 h-4 mr-1" />
                  Cancel
                </Button>
              </div>
            )}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-96 w-full">
            <pre className="text-sm text-slate-300 bg-slate-800 p-4 rounded border border-slate-600 overflow-x-auto">
              {showDiff ? generatedCode : editingScript}
            </pre>
          </ScrollArea>
          {selectedBot && (
            <div className="mt-4 flex gap-2">
              <Button
                variant="outline"
                size="sm"
                className="border-slate-600"
                onClick={() => {
                  // Rollback functionality
                }}
              >
                <RotateCcw className="w-4 h-4 mr-1" />
                Rollback
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="border-slate-600"
                onClick={() => {
                  navigator.clipboard.writeText(editingScript);
                  toast({ title: "Copied to clipboard" });
                }}
              >
                <Copy className="w-4 h-4 mr-1" />
                Copy
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

// Feature 2: Bot File Tree Viewer (simplified for length)
function BotFileTreeViewer({ bots, selectedBot, setSelectedBot }: {
  bots: BotInstance[];
  selectedBot: BotInstance | null;
  setSelectedBot: (bot: BotInstance | null) => void;
}) {
  const [selectedFile, setSelectedFile] = useState<BotFile | null>(null);
  const [fileContent, setFileContent] = useState('');

  const { data: files = [] } = useQuery({
    queryKey: ['/api/bot-files', selectedBot?.id],
    enabled: !!selectedBot
  });

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Bot & File Tree */}
      <Card className="bg-slate-900 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <FolderTree className="w-5 h-5 text-orange-400" />
            Bot Files
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Select value={selectedBot?.id?.toString() || ''} onValueChange={(value) => {
            const bot = bots.find(b => b.id === parseInt(value));
            setSelectedBot(bot || null);
          }}>
            <SelectTrigger className="bg-slate-800 border-slate-600">
              <SelectValue placeholder="Select a bot..." />
            </SelectTrigger>
            <SelectContent>
              {bots.map((bot) => (
                <SelectItem key={bot.id} value={bot.id.toString()}>
                  {bot.name} ({bot.city})
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          {selectedBot && (
            <div className="mt-4 space-y-1">
              {files.map((file: BotFile) => (
                <Button
                  key={file.id}
                  variant="ghost"
                  className="w-full justify-start p-2 h-auto"
                  onClick={() => {
                    setSelectedFile(file);
                    setFileContent(file.content || '');
                  }}
                >
                  <div className="flex items-center gap-2">
                    {file.fileType === 'js' && <FileCode className="w-4 h-4 text-yellow-400" />}
                    {file.fileType === 'json' && <FileJson className="w-4 h-4 text-blue-400" />}
                    {file.fileType === 'env' && <FileText className="w-4 h-4 text-green-400" />}
                    <span className="text-sm">{file.fileName}</span>
                  </div>
                </Button>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* File Editor */}
      <Card className="bg-slate-900 border-slate-700 lg:col-span-2">
        <CardHeader>
          <CardTitle className="text-white flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Edit className="w-5 h-5 text-blue-400" />
              {selectedFile ? selectedFile.fileName : 'Select a file to edit'}
            </div>
            {selectedFile && (
              <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
                <Save className="w-4 h-4 mr-1" />
                Save
              </Button>
            )}
          </CardTitle>
        </CardHeader>
        <CardContent>
          {selectedFile ? (
            <Textarea
              value={fileContent}
              onChange={(e) => setFileContent(e.target.value)}
              className="bg-slate-800 border-slate-600 text-white font-mono text-sm min-h-[400px]"
              placeholder="File content will appear here..."
            />
          ) : (
            <div className="h-[400px] flex items-center justify-center text-slate-400">
              Select a bot and file to start editing
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

// Feature 3: Subscription Bot Manager (simplified)
function SubscriptionBotManager({ subscriptions, bots }: {
  subscriptions: Subscription[];
  bots: BotInstance[];
}) {
  return (
    <div className="space-y-6">
      <Card className="bg-slate-900 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Users className="w-5 h-5 text-green-400" />
            Client Subscriptions
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4">
            {subscriptions.map((sub) => (
              <div key={sub.id} className="p-4 bg-slate-800 rounded-lg border border-slate-600">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-medium text-white">{sub.vertical.toUpperCase()} - {sub.city}</h3>
                    <p className="text-sm text-slate-400">Max leads: {sub.maxLeadsPerDay}/day • ${sub.pricePerLead}/lead</p>
                  </div>
                  <Badge variant={sub.isActive ? 'default' : 'secondary'}>
                    {sub.isActive ? 'Active' : 'Inactive'}
                  </Badge>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// Feature 4: Supabase Sync (simplified)
function SupabaseSync() {
  return (
    <div className="space-y-6">
      <Card className="bg-slate-900 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Database className="w-5 h-5 text-purple-400" />
            Database Management
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-slate-400">Database sync and lead management features coming soon...</p>
        </CardContent>
      </Card>
    </div>
  );
}

// Feature 5: Copilot AI Assistant (simplified)
function CopilotAIAssistant({ bots }: { bots: BotInstance[] }) {
  const [command, setCommand] = useState('');
  const [chatHistory, setChatHistory] = useState<Array<{role: string, message: string}>>([]);

  return (
    <div className="space-y-6">
      <Card className="bg-slate-900 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <MessageSquare className="w-5 h-5 text-blue-400" />
            AI Command Assistant
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="bg-slate-800 rounded-lg p-4 min-h-[200px]">
            {chatHistory.length === 0 ? (
              <p className="text-slate-400">Ask me anything about your bots...</p>
            ) : (
              <div className="space-y-2">
                {chatHistory.map((chat, index) => (
                  <div key={index} className={`p-2 rounded ${
                    chat.role === 'user' ? 'bg-blue-600/20 ml-8' : 'bg-slate-700 mr-8'
                  }`}>
                    <span className="text-sm text-slate-300">{chat.message}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
          <div className="flex gap-2">
            <Input
              placeholder="Try: 'launch Miami scraper every 3 hours' or 'show me error logs'"
              value={command}
              onChange={(e) => setCommand(e.target.value)}
              className="bg-slate-800 border-slate-600 text-white"
            />
            <Button className="bg-blue-600 hover:bg-blue-700">
              <MessageCircle className="w-4 h-4" />
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// Feature 6: Alerts & Health Monitoring (simplified)
function AlertsHealthMonitoring({ alerts, bots }: {
  alerts: AlertType[];
  bots: BotInstance[];
}) {
  return (
    <div className="space-y-6">
      <Card className="bg-slate-900 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-red-400" />
            System Health & Alerts
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4">
            {alerts.map((alert) => (
              <div key={alert.id} className={`p-4 rounded-lg border ${
                alert.severity === 'critical' ? 'bg-red-500/10 border-red-500/50' :
                alert.severity === 'high' ? 'bg-orange-500/10 border-orange-500/50' :
                'bg-yellow-500/10 border-yellow-500/50'
              }`}>
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="font-medium text-white">{alert.title}</h3>
                    <p className="text-sm text-slate-400 mt-1">{alert.message}</p>
                  </div>
                  <Badge variant={alert.isResolved ? 'default' : 'destructive'}>
                    {alert.isResolved ? 'Resolved' : alert.severity}
                  </Badge>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// Feature 7: GPT Prompt Manager (simplified)
function GPTPromptManager({ prompts }: { prompts: GptPrompt[] }) {
  return (
    <div className="space-y-6">
      <Card className="bg-slate-900 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Brain className="w-5 h-5 text-purple-400" />
            GPT Prompt Templates
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4">
            {['enrichment', 'outreach', 'matching'].map((type) => (
              <div key={type} className="p-4 bg-slate-800 rounded-lg border border-slate-600">
                <h3 className="font-medium text-white capitalize">{type} Prompts</h3>
                <p className="text-sm text-slate-400 mt-1">Manage {type} prompt templates</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// Feature 8: Dev Tools (simplified)
function DevTools({ bots }: { bots: BotInstance[] }) {
  return (
    <div className="space-y-6">
      <Card className="bg-slate-900 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Settings className="w-5 h-5 text-gray-400" />
            Developer Tools
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Button variant="outline" className="border-slate-600 flex items-center gap-2">
              <RefreshCw className="w-4 h-4" />
              Restart All
            </Button>
            <Button variant="outline" className="border-slate-600 flex items-center gap-2">
              <Download className="w-4 h-4" />
              Download Logs
            </Button>
            <Button variant="outline" className="border-slate-600 flex items-center gap-2">
              <Terminal className="w-4 h-4" />
              Debug Mode
            </Button>
            <Button variant="outline" className="border-slate-600 flex items-center gap-2">
              <Activity className="w-4 h-4" />
              System Stats
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export default AdvancedFeaturesDashboard;