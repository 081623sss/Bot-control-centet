import { useEffect, useState } from 'react'
import { createClient } from '@supabase/supabase-js'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Select, SelectTrigger, SelectContent, SelectItem, SelectValue } from '@/components/ui/select'
import { Input } from '@/components/ui/input'
import { toast } from 'sonner'

// Hardcoded Supabase credentials (for testing)
const SUPABASE_URL = 'https://hnadbcydcgqisoflvkcc.supabase.co'
const SUPABASE_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImhuYWRiY3lkY2dxaXNvZmx2a2NjIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTEyMzMzMjgsImV4cCI6MjA2NjgwOTMyOH0.8Arp67oBXgvKCP3Rf39w3YDKmrzjw0jL1FgyihB_Fg'

// Create Supabase client
const supabase = createClient(SUPABASE_URL, SUPABASE_KEY)

const TABLES = [
  'raw_leads',
  'auto_leads', 
  'real_estate_leads',
  'goods_leads',
  'pets_leads',
  'hot_leads'
]

export default function LeadTableManager() {
  const [selectedTable, setSelectedTable] = useState('raw_leads')
  const [rows, setRows] = useState<any[]>([])
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    fetchTable()
  }, [selectedTable])

  async function fetchTable() {
    setLoading(true)
    try {
      const { data, error } = await supabase.from(selectedTable).select('*')
      if (error) {
        console.error('Supabase error:', error)
        toast.error(`Error loading ${selectedTable}: ${error.message}`)
      } else {
        setRows(data || [])
      }
    } catch (error) {
      console.error('Fetch error:', error)
      toast.error('Failed to connect to database')
    }
    setLoading(false)
  }

  async function updateContact(id: number, field: string, value: string) {
    try {
      const { error } = await supabase.from(selectedTable).update({ [field]: value }).eq('id', id)
      if (error) {
        console.error('Update error:', error)
        toast.error(`Failed to update contact: ${error.message}`)
      } else {
        toast.success('Contact updated')
      }
    } catch (error) {
      console.error('Update error:', error)
      toast.error('Failed to update contact')
    }
  }

  return (
    <div className="p-4">
      <div className="flex justify-between mb-4 items-center">
        <h1 className="text-xl font-bold">Lead Tables Management</h1>
        <Select onValueChange={setSelectedTable} defaultValue={selectedTable}>
          <SelectTrigger className="w-64">
            <SelectValue placeholder="Choose a table" />
          </SelectTrigger>
          <SelectContent>
            {TABLES.map(table => (
              <SelectItem key={table} value={table}>{table}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {loading ? <p>Loading...</p> : (
        <div className="overflow-auto border rounded-lg">
          <table className="min-w-full text-sm">
            <thead>
              <tr className="bg-muted text-xs">
                <th className="p-2 text-left">Title</th>
                <th className="p-2">City</th>
                <th className="p-2">State</th>
                <th className="p-2">Date Posted</th>
                <th className="p-2">Contact Name</th>
                <th className="p-2">Contact Method</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((row: any) => (
                <tr key={row.id} className="border-b">
                  <td className="p-2">{row.title}</td>
                  <td className="p-2">{row.city}</td>
                  <td className="p-2">{row.state}</td>
                  <td className="p-2">{row.date_posted?.slice(0, 10)}</td>
                  <td className="p-2">
                    <Input 
                      defaultValue={row.contact_name || ''} 
                      onBlur={(e) => updateContact(row.id, 'contact_name', e.target.value)} 
                    />
                  </td>
                  <td className="p-2">
                    <Input 
                      defaultValue={row.contact_method || ''} 
                      onBlur={(e) => updateContact(row.id, 'contact_method', e.target.value)} 
                    />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}