import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import type { SystemMetrics } from "@shared/schema";

interface SystemStatusProps {
  metrics?: SystemMetrics;
}

export default function SystemStatus({ metrics }: SystemStatusProps) {
  const getStatusColor = (status: string) => {
    if (status.toLowerCase().includes("online") || status.toLowerCase().includes("connected") || status.toLowerCase().includes("running")) {
      return "bg-emerald-500";
    }
    if (status.toLowerCase().includes("warning") || status.includes("%")) {
      return "bg-amber-500";
    }
    return "bg-red-500";
  };

  const getStatusTextColor = (status: string) => {
    if (status.toLowerCase().includes("online") || status.toLowerCase().includes("connected") || status.toLowerCase().includes("running")) {
      return "text-emerald-500";
    }
    if (status.toLowerCase().includes("warning") || status.includes("%")) {
      return "text-amber-500";
    }
    return "text-red-500";
  };

  const statusItems = [
    { label: "API Server", status: metrics?.apiServerStatus || "offline" },
    { label: "Database", status: metrics?.databaseStatus || "disconnected" },
    { label: "Proxy Pool", status: metrics?.proxyPoolStatus || "unavailable" },
    { label: "Queue Service", status: metrics?.queueServiceStatus || "stopped" },
  ];

  return (
    <Card className="bg-slate-900 border-slate-700">
      <CardHeader>
        <CardTitle className="text-lg font-semibold text-white">System Status</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {statusItems.map((item, index) => (
            <div key={index} className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className={`w-3 h-3 rounded-full ${getStatusColor(item.status)}`}></div>
                <span className="text-sm text-white">{item.label}</span>
              </div>
              <span className={`text-xs font-medium ${getStatusTextColor(item.status)}`}>
                {item.status.charAt(0).toUpperCase() + item.status.slice(1)}
              </span>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
