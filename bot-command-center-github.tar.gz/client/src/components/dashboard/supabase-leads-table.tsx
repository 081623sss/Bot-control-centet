import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow 
} from '@/components/ui/table';
import { 
  Search, Database, Edit, Save, X, ChevronLeft, ChevronRight,
  Car, Home, Heart, Zap, MapPin, DollarSign, User, Phone
} from 'lucide-react';
import { AutoLead, RealEstateLead, PetLead } from '@shared/schema';

interface LeadsTableProps {
  tableName: 'auto' | 'real_estate' | 'pets';
  title: string;
  icon: React.ComponentType<any>;
}

export function SupabaseLeadsTable({ tableName, title, icon: Icon }: LeadsTableProps) {
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [editingLead, setEditingLead] = useState<number | null>(null);
  const [editData, setEditData] = useState<any>({});
  const queryClient = useQueryClient();

  const limit = 25;

  // Fetch leads with pagination and search
  const { data: leadsResponse, isLoading } = useQuery({
    queryKey: ['/api/advanced/leads', tableName, { page, search, limit }],
    queryFn: async () => {
      const params = new URLSearchParams({
        page: page.toString(),
        limit: limit.toString(),
        ...(search && { search })
      });
      const response = await fetch(`/api/advanced/leads/${tableName}?${params}`);
      if (!response.ok) throw new Error('Failed to fetch leads');
      return response.json();
    },
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  // Update lead mutation
  const updateLeadMutation = useMutation({
    mutationFn: async ({ leadId, updates }: { leadId: number; updates: any }) => {
      const response = await fetch(`/api/advanced/leads/${tableName}/${leadId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updates),
      });
      if (!response.ok) throw new Error('Failed to update lead');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/advanced/leads', tableName] });
      setEditingLead(null);
      setEditData({});
    },
  });

  const leads = leadsResponse?.data || [];
  const pagination = leadsResponse?.pagination || { page: 1, total: 0 };

  const handleEdit = (lead: any) => {
    setEditingLead(lead.id);
    setEditData({
      status: lead.status,
      ...(lead.contactInfo && { contactInfo: lead.contactInfo })
    });
  };

  const handleSave = () => {
    if (editingLead) {
      updateLeadMutation.mutate({ leadId: editingLead, updates: editData });
    }
  };

  const handleCancel = () => {
    setEditingLead(null);
    setEditData({});
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'new': return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200';
      case 'assigned': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200';
      case 'contacted': return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200';
      case 'closed': return 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-200';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-200';
    }
  };

  const formatPrice = (price: string | null) => {
    if (!price) return 'N/A';
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(parseFloat(price));
  };

  const formatDate = (date: Date | string) => {
    return new Date(date).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <Card className="bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-700">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Icon className="w-5 h-5" />
            {title}
          </CardTitle>
          <div className="flex items-center gap-2">
            <div className="relative">
              <Search className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400" />
              <Input
                placeholder={`Search ${title.toLowerCase()}...`}
                value={search}
                onChange={(e) => {
                  setSearch(e.target.value);
                  setPage(1); // Reset to first page on search
                }}
                className="pl-9 w-64"
              />
            </div>
          </div>
        </div>
      </CardHeader>

      <CardContent>
        {isLoading ? (
          <div className="text-center py-8">
            <Database className="w-8 h-8 animate-pulse mx-auto mb-2 text-slate-400" />
            <p className="text-slate-600 dark:text-slate-400">Loading {title.toLowerCase()}...</p>
          </div>
        ) : leads.length > 0 ? (
          <>
            <div className="rounded-md border overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-8">ID</TableHead>
                    <TableHead>Title</TableHead>
                    <TableHead>Price</TableHead>
                    <TableHead>Location</TableHead>
                    <TableHead>Contact</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Created</TableHead>
                    <TableHead className="w-24">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {leads.map((lead: any) => (
                    <TableRow key={lead.id} className="hover:bg-slate-50 dark:hover:bg-slate-800">
                      <TableCell className="font-medium">{lead.id}</TableCell>
                      
                      <TableCell className="max-w-xs">
                        <div className="truncate font-medium">{lead.title}</div>
                        {lead.description && (
                          <div className="text-xs text-slate-500 truncate mt-1">
                            {lead.description.slice(0, 60)}...
                          </div>
                        )}
                      </TableCell>
                      
                      <TableCell>
                        <span className="font-semibold text-green-600 dark:text-green-400">
                          {formatPrice(lead.price)}
                        </span>
                      </TableCell>
                      
                      <TableCell>
                        <div className="flex items-center gap-1">
                          <MapPin className="w-3 h-3 text-slate-400" />
                          <span className="text-sm">{lead.location || 'Unknown'}</span>
                        </div>
                      </TableCell>
                      
                      <TableCell>
                        {editingLead === lead.id ? (
                          <div className="space-y-2">
                            <Input
                              placeholder="Phone"
                              value={editData.contactInfo?.phone || ''}
                              onChange={(e) => setEditData({
                                ...editData,
                                contactInfo: {
                                  ...editData.contactInfo,
                                  phone: e.target.value
                                }
                              })}
                              className="h-8 text-xs"
                            />
                            <Input
                              placeholder="Email"
                              value={editData.contactInfo?.email || ''}
                              onChange={(e) => setEditData({
                                ...editData,
                                contactInfo: {
                                  ...editData.contactInfo,
                                  email: e.target.value
                                }
                              })}
                              className="h-8 text-xs"
                            />
                          </div>
                        ) : (
                          <div className="text-sm">
                            {lead.contactInfo?.phone && (
                              <div className="flex items-center gap-1">
                                <Phone className="w-3 h-3 text-slate-400" />
                                <span>{lead.contactInfo.phone}</span>
                              </div>
                            )}
                            {lead.contactInfo?.email && (
                              <div className="flex items-center gap-1">
                                <User className="w-3 h-3 text-slate-400" />
                                <span className="truncate">{lead.contactInfo.email}</span>
                              </div>
                            )}
                            {!lead.contactInfo?.phone && !lead.contactInfo?.email && (
                              <span className="text-slate-400">No contact info</span>
                            )}
                          </div>
                        )}
                      </TableCell>
                      
                      <TableCell>
                        {editingLead === lead.id ? (
                          <select
                            value={editData.status || lead.status}
                            onChange={(e) => setEditData({
                              ...editData,
                              status: e.target.value
                            })}
                            className="rounded border px-2 py-1 text-xs bg-white dark:bg-slate-800"
                          >
                            <option value="new">New</option>
                            <option value="assigned">Assigned</option>
                            <option value="contacted">Contacted</option>
                            <option value="closed">Closed</option>
                          </select>
                        ) : (
                          <Badge className={getStatusColor(lead.status)}>
                            {lead.status}
                          </Badge>
                        )}
                      </TableCell>
                      
                      <TableCell className="text-sm text-slate-500">
                        {formatDate(lead.createdAt)}
                      </TableCell>
                      
                      <TableCell>
                        {editingLead === lead.id ? (
                          <div className="flex gap-1">
                            <Button
                              size="sm"
                              variant="default"
                              onClick={handleSave}
                              disabled={updateLeadMutation.isPending}
                              className="h-7 w-7 p-0"
                            >
                              <Save className="w-3 h-3" />
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={handleCancel}
                              className="h-7 w-7 p-0"
                            >
                              <X className="w-3 h-3" />
                            </Button>
                          </div>
                        ) : (
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => handleEdit(lead)}
                            className="h-7 w-7 p-0"
                          >
                            <Edit className="w-3 h-3" />
                          </Button>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>

            {/* Pagination */}
            <div className="flex items-center justify-between mt-4">
              <div className="text-sm text-slate-600 dark:text-slate-400">
                Showing {Math.min((page - 1) * limit + 1, pagination.total)} to{' '}
                {Math.min(page * limit, pagination.total)} of {pagination.total} leads
              </div>
              
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setPage(page - 1)}
                  disabled={page <= 1}
                >
                  <ChevronLeft className="w-4 h-4" />
                  Previous
                </Button>
                
                <span className="text-sm font-medium">
                  Page {page} of {Math.ceil(pagination.total / limit)}
                </span>
                
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setPage(page + 1)}
                  disabled={page >= Math.ceil(pagination.total / limit)}
                >
                  Next
                  <ChevronRight className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </>
        ) : (
          <div className="text-center py-12">
            <Database className="w-12 h-12 mx-auto mb-3 text-slate-400" />
            <h3 className="text-lg font-medium text-slate-900 dark:text-white mb-2">No {title} Found</h3>
            <p className="text-slate-600 dark:text-slate-400">
              {search ? `No leads match "${search}"` : `No ${title.toLowerCase()} leads in the database yet.`}
            </p>
          </div>
        )}

        {updateLeadMutation.isError && (
          <div className="mt-4 p-3 bg-red-50 dark:bg-red-950 border border-red-200 dark:border-red-800 rounded-lg">
            <p className="text-sm text-red-800 dark:text-red-200">
              Failed to update lead. Please try again.
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

export function SupabaseLeadsManager() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-900 dark:text-white">Leads & Tables</h2>
          <p className="text-slate-600 dark:text-slate-400">
            Manage and edit leads from your Supabase database with real-time updates
          </p>
        </div>
      </div>

      <Tabs defaultValue="auto" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="auto" className="flex items-center gap-2">
            <Car className="w-4 h-4" />
            Auto Leads
          </TabsTrigger>
          <TabsTrigger value="real_estate" className="flex items-center gap-2">
            <Home className="w-4 h-4" />
            Real Estate
          </TabsTrigger>
          <TabsTrigger value="pets" className="flex items-center gap-2">
            <Heart className="w-4 h-4" />
            Pet Leads
          </TabsTrigger>
        </TabsList>

        <TabsContent value="auto">
          <SupabaseLeadsTable tableName="auto" title="Auto Leads" icon={Car} />
        </TabsContent>

        <TabsContent value="real_estate">
          <SupabaseLeadsTable tableName="real_estate" title="Real Estate Leads" icon={Home} />
        </TabsContent>

        <TabsContent value="pets">
          <SupabaseLeadsTable tableName="pets" title="Pet Leads" icon={Heart} />
        </TabsContent>
      </Tabs>
    </div>
  );
}