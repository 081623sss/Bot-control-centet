import { useState, useEffect } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { useToast } from '@/hooks/use-toast'
import {
  Play,
  Square,
  RotateCcw,
  Camera,
  Activity,
  MapPin,
  Calendar,
  TrendingUp,
  DollarSign,
  Users,
  Bot,
  AlertTriangle,
  CheckCircle,
  XCircle,
  Clock,
  RefreshCw
} from 'lucide-react'

interface CraigslistBotStatus {
  isRunning: boolean
  cities: string[]
  leadsToday: number
  totalLeads: number
  lastRunTime: Date | null
  status: 'running' | 'stopped' | 'error' | 'idle'
  errorMessage?: string
  processId?: number
  uptime?: string
}

interface CraigslistBotAnalytics {
  weeklyLeads: number
  monthlyLeads: number
  gptTokensUsed: number
  estimatedCost: number
  costBreakdown: {
    openai: number
    airtable: number
    total: number
  }
}

export default function CraigslistBotManager() {
  const [autoRefresh, setAutoRefresh] = useState(true)
  const { toast } = useToast()
  const queryClient = useQueryClient()

  // Fetch bot status
  const { data: statusData, isLoading: statusLoading, error: statusError } = useQuery({
    queryKey: ['/api/craigslist-bot/status'],
    refetchInterval: autoRefresh ? 10000 : false, // Auto-refresh every 10 seconds
    retry: 2
  })

  // Fetch bot analytics
  const { data: analyticsData, isLoading: analyticsLoading } = useQuery({
    queryKey: ['/api/craigslist-bot/analytics'],
    refetchInterval: autoRefresh ? 30000 : false, // Refresh every 30 seconds
    retry: 2
  })

  // Bot command mutations
  const startMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch('/api/craigslist-bot/start', {
        method: 'POST',
        credentials: 'include'
      })
      return response.json()
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/craigslist-bot/status'] })
      toast({
        title: "Bot Started",
        description: "Craigslist scraper bot has been started successfully",
      })
    },
    onError: (error) => {
      toast({
        title: "Failed to Start Bot",
        description: error instanceof Error ? error.message : "Unknown error occurred",
        variant: "destructive"
      })
    }
  })

  const stopMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch('/api/craigslist-bot/stop', {
        method: 'POST',
        credentials: 'include'
      })
      return response.json()
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/craigslist-bot/status'] })
      toast({
        title: "Bot Stopped",
        description: "Craigslist scraper bot has been stopped successfully",
      })
    },
    onError: (error) => {
      toast({
        title: "Failed to Stop Bot",
        description: error instanceof Error ? error.message : "Unknown error occurred",
        variant: "destructive"
      })
    }
  })

  const rollbackMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch('/api/craigslist-bot/rollback', {
        method: 'POST',
        credentials: 'include'
      })
      return response.json()
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/craigslist-bot/status'] })
      toast({
        title: "Bot Rolled Back",
        description: "Craigslist scraper bot has been rolled back to previous version",
      })
    },
    onError: (error) => {
      toast({
        title: "Failed to Rollback Bot",
        description: error instanceof Error ? error.message : "Unknown error occurred",
        variant: "destructive"
      })
    }
  })

  const snapshotMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch('/api/craigslist-bot/snapshot', {
        method: 'POST',
        credentials: 'include'
      })
      return response.json()
    },
    onSuccess: () => {
      toast({
        title: "Snapshot Created",
        description: "Craigslist scraper bot snapshot created successfully",
      })
    },
    onError: (error) => {
      toast({
        title: "Failed to Create Snapshot",
        description: error instanceof Error ? error.message : "Unknown error occurred",
        variant: "destructive"
      })
    }
  })

  const status: CraigslistBotStatus | null = (statusData as any)?.success ? (statusData as any).data : null
  const analytics: CraigslistBotAnalytics | null = (analyticsData as any)?.success ? (analyticsData as any).data : null

  const getStatusIcon = () => {
    if (statusLoading) return <RefreshCw className="w-4 h-4 text-gray-500 animate-spin" />
    if (!status) return <XCircle className="w-4 h-4 text-red-500" />
    
    switch (status.status) {
      case 'running': return <CheckCircle className="w-4 h-4 text-green-500" />
      case 'stopped': return <XCircle className="w-4 h-4 text-red-500" />
      case 'error': return <AlertTriangle className="w-4 h-4 text-red-500" />
      case 'idle': return <Clock className="w-4 h-4 text-yellow-500" />
      default: return <XCircle className="w-4 h-4 text-gray-500" />
    }
  }

  const getStatusBadge = () => {
    if (!status) return <Badge variant="destructive">Offline</Badge>
    
    switch (status.status) {
      case 'running': return <Badge className="bg-green-500/20 text-green-300 border-green-400/50">Running</Badge>
      case 'stopped': return <Badge variant="destructive">Stopped</Badge>
      case 'error': return <Badge variant="destructive">Error</Badge>
      case 'idle': return <Badge className="bg-yellow-500/20 text-yellow-300 border-yellow-400/50">Idle</Badge>
      default: return <Badge variant="secondary">Unknown</Badge>
    }
  }

  const formatLastRun = (date: Date | null) => {
    if (!date) return 'Never'
    const now = new Date()
    const diff = now.getTime() - new Date(date).getTime()
    const minutes = Math.floor(diff / 60000)
    const hours = Math.floor(minutes / 60)
    const days = Math.floor(hours / 24)
    
    if (days > 0) return `${days} day${days > 1 ? 's' : ''} ago`
    if (hours > 0) return `${hours} hour${hours > 1 ? 's' : ''} ago`
    if (minutes > 0) return `${minutes} minute${minutes > 1 ? 's' : ''} ago`
    return 'Just now'
  }

  return (
    <div className="space-y-4 sm:space-y-6">
      {/* Bot Status Header */}
      <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-950 dark:to-indigo-950 border-blue-200 dark:border-blue-800">
        <CardHeader className="pb-3 p-3 sm:p-6">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 sm:gap-0">
            <CardTitle className="flex items-center gap-2 text-base sm:text-lg text-blue-900 dark:text-blue-100">
              <Bot className="w-4 h-4 sm:w-5 sm:h-5" />
              Craigslist Scraper Bot
              {getStatusBadge()}
            </CardTitle>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setAutoRefresh(!autoRefresh)}
                className="text-xs sm:text-sm"
              >
                <RefreshCw className={`w-3 h-3 mr-1 ${autoRefresh ? 'animate-spin' : ''}`} />
                Auto-refresh {autoRefresh ? 'On' : 'Off'}
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-3 sm:p-6 pt-0">
          {statusError && (
            <Alert className="mb-4">
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                Failed to connect to bot server. Check Ngrok connection status.
              </AlertDescription>
            </Alert>
          )}
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
            {/* Status */}
            <div className="flex items-center gap-2 p-3 bg-white/50 dark:bg-gray-800/50 rounded-lg">
              {getStatusIcon()}
              <div className="min-w-0">
                <div className="text-xs text-gray-600 dark:text-gray-400">Status</div>
                <div className="text-sm font-medium truncate">
                  {status?.status ? status.status.charAt(0).toUpperCase() + status.status.slice(1) : 'Unknown'}
                </div>
              </div>
            </div>

            {/* Cities */}
            <div className="flex items-center gap-2 p-3 bg-white/50 dark:bg-gray-800/50 rounded-lg">
              <MapPin className="w-4 h-4 text-blue-500" />
              <div className="min-w-0">
                <div className="text-xs text-gray-600 dark:text-gray-400">Cities</div>
                <div className="text-sm font-medium">{status?.cities?.length || 0} active</div>
              </div>
            </div>

            {/* Today's Leads */}
            <div className="flex items-center gap-2 p-3 bg-white/50 dark:bg-gray-800/50 rounded-lg">
              <TrendingUp className="w-4 h-4 text-green-500" />
              <div className="min-w-0">
                <div className="text-xs text-gray-600 dark:text-gray-400">Today's Leads</div>
                <div className="text-sm font-medium">{status?.leadsToday || 0}</div>
              </div>
            </div>

            {/* Last Run */}
            <div className="flex items-center gap-2 p-3 bg-white/50 dark:bg-gray-800/50 rounded-lg">
              <Calendar className="w-4 h-4 text-purple-500" />
              <div className="min-w-0">
                <div className="text-xs text-gray-600 dark:text-gray-400">Last Run</div>
                <div className="text-sm font-medium truncate">{formatLastRun(status?.lastRunTime || null)}</div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Control Panel */}
      <Card>
        <CardHeader className="pb-3 p-3 sm:p-6">
          <CardTitle className="text-base sm:text-lg">Bot Control Panel</CardTitle>
        </CardHeader>
        <CardContent className="p-3 sm:p-6 pt-0">
          <div className="flex flex-wrap gap-2 sm:gap-3">
            <Button
              onClick={() => startMutation.mutate()}
              disabled={startMutation.isPending || status?.isRunning}
              className="flex-1 sm:flex-none bg-green-600 hover:bg-green-700"
            >
              <Play className="w-4 h-4 mr-2" />
              Start
            </Button>
            
            <Button
              onClick={() => stopMutation.mutate()}
              disabled={stopMutation.isPending || !status?.isRunning}
              variant="destructive"
              className="flex-1 sm:flex-none"
            >
              <Square className="w-4 h-4 mr-2" />
              Stop
            </Button>
            
            <Button
              onClick={() => rollbackMutation.mutate()}
              disabled={rollbackMutation.isPending}
              variant="outline"
              className="flex-1 sm:flex-none"
            >
              <RotateCcw className="w-4 h-4 mr-2" />
              Rollback
            </Button>
            
            <Button
              onClick={() => snapshotMutation.mutate()}
              disabled={snapshotMutation.isPending}
              variant="outline"
              className="flex-1 sm:flex-none"
            >
              <Camera className="w-4 h-4 mr-2" />
              Snapshot
            </Button>
          </div>

          {/* Error Display */}
          {status?.errorMessage && (
            <Alert className="mt-4" variant="destructive">
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                {status.errorMessage}
              </AlertDescription>
            </Alert>
          )}
        </CardContent>
      </Card>

      {/* Analytics */}
      {analytics && (
        <Card>
          <CardHeader className="pb-3 p-3 sm:p-6">
            <CardTitle className="text-base sm:text-lg">Performance Analytics</CardTitle>
          </CardHeader>
          <CardContent className="p-3 sm:p-6 pt-0">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
              <div className="p-3 bg-blue-50 dark:bg-blue-950/30 rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <Users className="w-4 h-4 text-blue-500" />
                  <span className="text-xs text-blue-600 dark:text-blue-400">Weekly Leads</span>
                </div>
                <div className="text-lg font-semibold text-blue-900 dark:text-blue-100">
                  {analytics.weeklyLeads}
                </div>
              </div>

              <div className="p-3 bg-green-50 dark:bg-green-950/30 rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <TrendingUp className="w-4 h-4 text-green-500" />
                  <span className="text-xs text-green-600 dark:text-green-400">Monthly Leads</span>
                </div>
                <div className="text-lg font-semibold text-green-900 dark:text-green-100">
                  {analytics.monthlyLeads}
                </div>
              </div>

              <div className="p-3 bg-purple-50 dark:bg-purple-950/30 rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <Activity className="w-4 h-4 text-purple-500" />
                  <span className="text-xs text-purple-600 dark:text-purple-400">GPT Tokens</span>
                </div>
                <div className="text-lg font-semibold text-purple-900 dark:text-purple-100">
                  {analytics.gptTokensUsed.toLocaleString()}
                </div>
              </div>

              <div className="p-3 bg-orange-50 dark:bg-orange-950/30 rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <DollarSign className="w-4 h-4 text-orange-500" />
                  <span className="text-xs text-orange-600 dark:text-orange-400">Estimated Cost</span>
                </div>
                <div className="text-lg font-semibold text-orange-900 dark:text-orange-100">
                  ${analytics.estimatedCost.toFixed(2)}
                </div>
              </div>
            </div>

            {/* Cost Breakdown */}
            <div className="mt-4 p-3 bg-gray-50 dark:bg-gray-800/50 rounded-lg">
              <div className="text-sm font-medium mb-2">Cost Breakdown</div>
              <div className="space-y-1 text-xs">
                <div className="flex justify-between">
                  <span>OpenAI:</span>
                  <span>${analytics.costBreakdown.openai.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Airtable:</span>
                  <span>${analytics.costBreakdown.airtable.toFixed(2)}</span>
                </div>
                <div className="flex justify-between font-medium border-t pt-1">
                  <span>Total:</span>
                  <span>${analytics.costBreakdown.total.toFixed(2)}</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Cities Being Scraped */}
      {status?.cities && status.cities.length > 0 && (
        <Card>
          <CardHeader className="pb-3 p-3 sm:p-6">
            <CardTitle className="text-base sm:text-lg">Active Cities ({status.cities.length})</CardTitle>
          </CardHeader>
          <CardContent className="p-3 sm:p-6 pt-0">
            <ScrollArea className="h-32">
              <div className="flex flex-wrap gap-2">
                {status.cities.map((city) => (
                  <Badge key={city} variant="secondary" className="text-xs">
                    {city.charAt(0).toUpperCase() + city.slice(1)}
                  </Badge>
                ))}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      )}
    </div>
  )
}