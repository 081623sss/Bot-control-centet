import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useToast } from '@/hooks/use-toast';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { FunctionalBotManagement } from './functional-bot-management';
import { SupabaseLeadsManager } from './supabase-leads-table';
import { LeadTables } from './lead-tables';
import LeadTableManager from './lead-table-manager';
import { LiveBotEditor } from './live-bot-editor';
import SimpleBotEditor from './simple-bot-editor';
import NgrokStatus from './ngrok-status';
import CraigslistBotManager from './craigslist-bot-manager';
import CraigslistBotStatusWidget from './craigslist-bot-status-widget';
import CraigslistBotAnalytics from './craigslist-bot-analytics';
import { LiveCraigslistBotManager } from './live-craigslist-bot-manager';
import { LiveBotStatusWidget } from './live-bot-status-widget';

// Icons
import { 
  Bot, TrendingUp, Users, DollarSign, Activity, Settings,
  Play, Pause, RotateCcw, Code2, FolderTree, MessageSquare,
  AlertTriangle, Brain, Database, Terminal, Zap, RefreshCw,
  CheckCircle, Save, Edit, Download, FileCode
} from 'lucide-react';

export function CleanDashboard() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [showLiveBotEditor, setShowLiveBotEditor] = useState(false);
  const [showSimpleBotEditor, setShowSimpleBotEditor] = useState(false);

  // Seed database mutation
  const seedDatabaseMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch('/api/dev-seed', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      });
      if (!response.ok) throw new Error('Failed to seed database');
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: 'Database Seeded Successfully',
        description: `Created ${data.botsCreated} bots and sample leads across all tables`,
      });
      // Invalidate all queries to refresh the data
      queryClient.invalidateQueries();
    },
    onError: (error: any) => {
      toast({
        title: 'Seed Failed',
        description: error.message || 'Failed to seed database',
        variant: 'destructive',
      });
    },
  });

  // Seed Database Button Component
  const SeedDatabaseButton = () => (
    <Button
      onClick={() => seedDatabaseMutation.mutate()}
      disabled={seedDatabaseMutation.isPending}
      variant="outline"
      className="flex items-center gap-2"
    >
      <Database className="w-4 h-4" />
      {seedDatabaseMutation.isPending ? 'Seeding...' : 'Seed Database'}
    </Button>
  );
  const [activeTab, setActiveTab] = useState('overview');
  const [connectionStatus, setConnectionStatus] = useState<'connected' | 'disconnected' | 'checking'>('checking');

  // Check connection to Termius server
  const checkConnection = async () => {
    try {
      setConnectionStatus('checking');
      const response = await fetch('https://f1e9-2600-3c0a-00-f03c-95ff.ngrok.io/api/health');
      if (response.ok) {
        setConnectionStatus('connected');
      } else {
        setConnectionStatus('disconnected');
      }
    } catch (error) {
      setConnectionStatus('disconnected');
    }
  };

  useEffect(() => {
    checkConnection();
    const interval = setInterval(checkConnection, 30000); // Check every 30 seconds
    return () => clearInterval(interval);
  }, []);

  // Fetch real data from your APIs
  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ['/api/stats'],
    refetchInterval: 10000, // Refresh every 10 seconds
  });

  const { data: bots, isLoading: botsLoading } = useQuery({
    queryKey: ['/api/bots'],
    refetchInterval: 5000, // Refresh every 5 seconds
  });

  const { data: logs, isLoading: logsLoading } = useQuery({
    queryKey: ['/api/logs'],
    refetchInterval: 15000, // Refresh every 15 seconds
  });

  // Fetch data from Termius server (your Craigslist scraper)
  const { data: termiusData, isLoading: termiusLoading } = useQuery({
    queryKey: ['termius-data'],
    queryFn: async () => {
      try {
        const response = await fetch('https://f1e9-2600-3c0a-00-f03c-95ff.ngrok.io/api/scrapers/status');
        if (!response.ok) throw new Error('Failed to fetch Termius data');
        return response.json();
      } catch (error) {
        console.error('Termius fetch error:', error);
        return null;
      }
    },
    refetchInterval: 10000,
    retry: 1,
  });

  // Safely combine local and Termius data with proper fallbacks
  const combinedStats = {
    totalBots: ((stats as any)?.totalBots || 0) + (termiusData?.activeBots || 0),
    runningBots: ((stats as any)?.runningBots || 0) + (termiusData?.runningBots || 0),
    totalLeads: ((stats as any)?.totalLeads || 0) + (termiusData?.totalLeads || 0),
    dailyLeads: ((stats as any)?.dailyLeads || 0) + (termiusData?.todayLeads || 0),
    activeSubscriptions: (stats as any)?.activeSubscriptions || 0,
    totalCost: ((stats as any)?.apiCost || 0) + (termiusData?.monthlyApiCost || 0)
  };

  const combinedBots = [
    ...((Array.isArray(bots) ? bots : []) as any[]),
    ...((termiusData?.scrapers && Array.isArray(termiusData.scrapers) ? termiusData.scrapers : []).map((scraper: any) => ({
      id: `termius-${scraper.id || Math.random()}`,
      name: scraper.name || `${scraper.city || 'Unknown'} Craigslist Scraper`,
      city: scraper.city || 'Unknown',
      platform: 'Craigslist',
      status: scraper.status || 'unknown',
      leads: scraper.todayCount || 0,
      source: 'termius'
    })))
  ];

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950">
      {/* Mobile-First Enhanced Header */}
      <header className="bg-gradient-to-r from-blue-600 to-blue-700 text-white sticky top-0 z-50 shadow-lg">
        <div className="px-3 sm:px-4 py-3 sm:py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2 sm:space-x-4 min-w-0">
              <div className="flex items-center space-x-2 sm:space-x-3">
                <div className="w-8 h-8 sm:w-12 sm:h-12 bg-white/20 rounded-lg sm:rounded-xl flex items-center justify-center backdrop-blur-sm">
                  <Bot className="w-5 h-5 sm:w-7 sm:h-7 text-white" />
                </div>
                <div className="min-w-0">
                  <h1 className="text-base sm:text-xl font-bold truncate">
                    <span className="hidden sm:inline">Super Smart Stealz</span>
                    <span className="sm:hidden">SSS</span>
                  </h1>
                  <p className="text-blue-100 text-xs sm:text-sm hidden sm:block">AI Bot Command Center</p>
                  <p className="text-blue-100 text-xs sm:hidden">Command Center</p>
                </div>
              </div>
              
              {/* Live Connection Status - Mobile Optimized */}
              <div className="flex items-center space-x-1 sm:space-x-2 bg-white/10 rounded-md sm:rounded-lg px-2 sm:px-3 py-1 sm:py-2">
                <div className={`w-2 h-2 rounded-full ${
                  connectionStatus === 'connected' ? 'bg-green-400 animate-pulse' : 
                  connectionStatus === 'disconnected' ? 'bg-red-400' : 
                  'bg-yellow-400 animate-pulse'
                }`} />
                <span className="text-xs sm:text-sm text-white/90 hidden sm:inline">
                  {connectionStatus === 'connected' ? 'Live Connected' : 
                   connectionStatus === 'disconnected' ? 'Offline' : 
                   'Connecting...'}
                </span>
                <span className="text-xs text-white/90 sm:hidden">
                  {connectionStatus === 'connected' ? 'Live' : 
                   connectionStatus === 'disconnected' ? 'Off' : 
                   '...'}
                </span>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={checkConnection}
                  disabled={connectionStatus === 'checking'}
                  className="h-5 w-5 sm:h-6 sm:w-6 p-0 text-white/70 hover:text-white hover:bg-white/10"
                >
                  <RefreshCw className={`w-2 h-2 sm:w-3 sm:h-3 ${connectionStatus === 'checking' ? 'animate-spin' : ''}`} />
                </Button>
              </div>
            </div>

            <Button variant="secondary" size="sm" className="bg-white/10 text-white border-white/20 hover:bg-white/20 text-xs sm:text-sm px-2 sm:px-3">
              <Settings className="w-3 h-3 sm:w-4 sm:h-4 sm:mr-2" />
              <span className="hidden sm:inline">Settings</span>
            </Button>
          </div>
        </div>
      </header>

      <div className="p-2 sm:p-4 space-y-4 sm:space-y-6">
        {/* Mobile-First Navigation Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <div className="overflow-x-auto">
            <TabsList className="flex w-max sm:grid sm:w-full sm:grid-cols-2 md:grid-cols-4 lg:grid-cols-7 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 min-w-full">
              <TabsTrigger value="overview" className="text-xs sm:text-sm px-2 sm:px-3 whitespace-nowrap">Overview</TabsTrigger>
              <TabsTrigger value="bots" className="text-xs sm:text-sm px-2 sm:px-3 whitespace-nowrap">Bots</TabsTrigger>
              <TabsTrigger value="tables" className="text-xs sm:text-sm px-2 sm:px-3 whitespace-nowrap">Tables</TabsTrigger>
              <TabsTrigger value="advanced" className="text-xs sm:text-sm px-2 sm:px-3 whitespace-nowrap">Advanced</TabsTrigger>
              <TabsTrigger value="analytics" className="text-xs sm:text-sm px-2 sm:px-3 whitespace-nowrap">Analytics</TabsTrigger>
              <TabsTrigger value="clients" className="text-xs sm:text-sm px-2 sm:px-3 whitespace-nowrap">Clients</TabsTrigger>
              <TabsTrigger value="settings" className="text-xs sm:text-sm px-2 sm:px-3 whitespace-nowrap">Settings</TabsTrigger>
            </TabsList>
          </div>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-4 sm:space-y-6 mt-4 sm:mt-6">
            {/* Mobile-First Enhanced Stats Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
              <Card className="bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-950 dark:to-blue-900 border-blue-200 dark:border-blue-800 shadow-lg">
                <CardContent className="p-4 sm:p-6">
                  <div className="flex items-center justify-between">
                    <div className="min-w-0 flex-1">
                      <p className="text-xs sm:text-sm font-medium text-blue-700 dark:text-blue-300">Total Bots</p>
                      <p className="text-2xl sm:text-3xl font-bold text-blue-900 dark:text-white">
                        {statsLoading ? (
                          <div className="w-6 h-6 sm:w-8 sm:h-8 bg-blue-200 dark:bg-blue-800 rounded animate-pulse"></div>
                        ) : (
                          combinedStats.totalBots
                        )}
                      </p>
                      <p className="text-xs text-blue-600 dark:text-blue-400 truncate">
                        {combinedStats.runningBots} running now
                      </p>
                    </div>
                    <div className="w-10 h-10 sm:w-12 sm:h-12 bg-blue-500 rounded-xl flex items-center justify-center flex-shrink-0">
                      <Bot className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-green-50 to-green-100 dark:from-green-950 dark:to-green-900 border-green-200 dark:border-green-800 shadow-lg">
                <CardContent className="p-4 sm:p-6">
                  <div className="flex items-center justify-between">
                    <div className="min-w-0 flex-1">
                      <p className="text-xs sm:text-sm font-medium text-green-700 dark:text-green-300">Total Leads</p>
                      <p className="text-2xl sm:text-3xl font-bold text-green-900 dark:text-white">
                        {statsLoading ? (
                          <div className="w-6 h-6 sm:w-8 sm:h-8 bg-green-200 dark:bg-green-800 rounded animate-pulse"></div>
                        ) : (
                          combinedStats.totalLeads.toLocaleString()
                        )}
                      </p>
                      <p className="text-xs text-green-600 dark:text-green-400 truncate">
                        +{combinedStats.dailyLeads} today
                      </p>
                    </div>
                    <div className="w-10 h-10 sm:w-12 sm:h-12 bg-green-500 rounded-xl flex items-center justify-center flex-shrink-0">
                      <TrendingUp className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-purple-50 to-purple-100 dark:from-purple-950 dark:to-purple-900 border-purple-200 dark:border-purple-800 shadow-lg">
                <CardContent className="p-4 sm:p-6">
                  <div className="flex items-center justify-between">
                    <div className="min-w-0 flex-1">
                      <p className="text-xs sm:text-sm font-medium text-purple-700 dark:text-purple-300">Active Clients</p>
                      <p className="text-2xl sm:text-3xl font-bold text-purple-900 dark:text-white">
                        {statsLoading ? (
                          <div className="w-6 h-6 sm:w-8 sm:h-8 bg-purple-200 dark:bg-purple-800 rounded animate-pulse"></div>
                        ) : (
                          combinedStats.activeSubscriptions
                        )}
                      </p>
                      <p className="text-xs text-purple-600 dark:text-purple-400 truncate">
                        Premium subscriptions
                      </p>
                    </div>
                    <div className="w-10 h-10 sm:w-12 sm:h-12 bg-purple-500 rounded-xl flex items-center justify-center flex-shrink-0">
                      <Users className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-orange-50 to-orange-100 dark:from-orange-950 dark:to-orange-900 border-orange-200 dark:border-orange-800 shadow-lg">
                <CardContent className="p-4 sm:p-6">
                  <div className="flex items-center justify-between">
                    <div className="min-w-0 flex-1">
                      <p className="text-xs sm:text-sm font-medium text-orange-700 dark:text-orange-300">API Costs</p>
                      <p className="text-2xl sm:text-3xl font-bold text-orange-900 dark:text-white">
                        {statsLoading ? (
                          <div className="w-6 h-6 sm:w-8 sm:h-8 bg-orange-200 dark:bg-orange-800 rounded animate-pulse"></div>
                        ) : (
                          `$${combinedStats.totalCost.toFixed(2)}`
                        )}
                      </p>
                      <p className="text-xs text-orange-600 dark:text-orange-400 truncate">
                        This month
                      </p>
                    </div>
                    <div className="w-10 h-10 sm:w-12 sm:h-12 bg-orange-500 rounded-xl flex items-center justify-center flex-shrink-0">
                      <DollarSign className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Ngrok Status */}
            <NgrokStatus />

            {/* Live Craigslist Bot Status Widget */}
            <LiveBotStatusWidget />

            {/* Functional Bot Management */}
            <FunctionalBotManagement />
          </TabsContent>

          {/* Tables Tab - Mobile-First Lead Tables Management */}
          <TabsContent value="tables" className="space-y-4 sm:space-y-6 mt-4 sm:mt-6">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 sm:gap-0 mb-4 sm:mb-6">
              <div>
                <h2 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">Lead Tables Management</h2>
                <p className="text-sm sm:text-base text-slate-600 dark:text-slate-400">
                  View and manage live Supabase data with role-based access control
                </p>
              </div>
              <SeedDatabaseButton />
            </div>
            <LeadTableManager />
          </TabsContent>

          {/* Advanced Features Tab - Mobile-First */}
          <TabsContent value="advanced" className="space-y-4 sm:space-y-6 mt-4 sm:mt-6">
            <div className="grid gap-3 sm:gap-4 md:gap-6 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3">
              {/* GPT-4 Editor */}
              <Card className="bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-700">
                <CardHeader className="pb-2 sm:pb-3 p-3 sm:p-6">
                  <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
                    <Code2 className="w-4 h-4 sm:w-5 sm:h-5 text-blue-500" />
                    GPT-4 Editor
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-2 sm:space-y-3 p-3 sm:p-6 pt-0">
                  <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400">
                    Edit bot scripts with AI assistance
                  </p>
                  <Input placeholder="Describe your changes..." className="text-xs sm:text-sm" />
                  <Button className="w-full bg-blue-600 hover:bg-blue-700 text-xs sm:text-sm py-2">
                    <Zap className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
                    Generate Code
                  </Button>
                </CardContent>
              </Card>

              {/* File Manager */}
              <Card className="bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-700">
                <CardHeader className="pb-2 sm:pb-3 p-3 sm:p-6">
                  <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
                    <FolderTree className="w-4 h-4 sm:w-5 sm:h-5 text-orange-500" />
                    File Manager
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-2 sm:space-y-3 p-3 sm:p-6 pt-0">
                  <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400">
                    Browse and edit bot files
                  </p>
                  <div className="space-y-1 sm:space-y-2">
                    <div className="flex items-center gap-2 text-xs sm:text-sm">
                      <FileCode className="w-3 h-3 sm:w-4 sm:h-4 text-blue-500" />
                      <span>scraper.js</span>
                    </div>
                    <div className="flex items-center gap-2 text-xs sm:text-sm">
                      <FileCode className="w-3 h-3 sm:w-4 sm:h-4 text-green-500" />
                      <span>config.json</span>
                    </div>
                  </div>
                  <Button 
                    variant="outline" 
                    className="w-full text-xs sm:text-sm py-2"
                    onClick={() => setShowLiveBotEditor(true)}
                  >
                    <Edit className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
                    Open Editor
                  </Button>
                </CardContent>
              </Card>

              {/* Simple Bot Editor */}
              <Card className="bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-700">
                <CardHeader className="pb-2 sm:pb-3 p-3 sm:p-6">
                  <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
                    <Edit className="w-4 h-4 sm:w-5 sm:h-5 text-indigo-500" />
                    Simple Bot Editor
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-2 sm:space-y-3 p-3 sm:p-6 pt-0">
                  <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400">
                    Lightweight file editor for bot scripts
                  </p>
                  <div className="text-xs text-slate-500 dark:text-slate-400">
                    Load, edit, and save bot files with a simple interface
                  </div>
                  <Button 
                    variant="outline" 
                    className="w-full text-xs sm:text-sm py-2"
                    onClick={() => setShowSimpleBotEditor(true)}
                  >
                    <FileCode className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
                    Open Simple Editor
                  </Button>
                </CardContent>
              </Card>

              {/* AI Assistant */}
              <Card className="bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-700">
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <MessageSquare className="w-5 h-5 text-purple-500" />
                    AI Assistant
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <p className="text-sm text-slate-600 dark:text-slate-400">
                    Control bots with natural language
                  </p>
                  <Input placeholder="Try: 'start Miami scraper'" className="text-sm" />
                  <Button variant="outline" className="w-full">
                    <MessageSquare className="w-4 h-4 mr-2" />
                    Send Command
                  </Button>
                </CardContent>
              </Card>

              {/* Health Monitor */}
              <Card className="bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-700">
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <AlertTriangle className="w-5 h-5 text-red-500" />
                    Health Monitor
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <p className="text-sm text-slate-600 dark:text-slate-400">
                    System alerts and monitoring
                  </p>
                  <Alert className="border-orange-200 bg-orange-50 dark:border-orange-800 dark:bg-orange-950">
                    <AlertDescription className="text-sm">
                      2 warnings detected
                    </AlertDescription>
                  </Alert>
                  <Button variant="outline" className="w-full">
                    <Activity className="w-4 h-4 mr-2" />
                    View Details
                  </Button>
                </CardContent>
              </Card>

              {/* Database Sync */}
              <Card className="bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-700">
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <Database className="w-5 h-5 text-green-500" />
                    Database Sync
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <p className="text-sm text-slate-600 dark:text-slate-400">
                    Manage leads and data
                  </p>
                  <div className="text-sm text-slate-600 dark:text-slate-400">
                    Last sync: 2 minutes ago
                  </div>
                  <Button variant="outline" className="w-full">
                    <RefreshCw className="w-4 h-4 mr-2" />
                    Sync Now
                  </Button>
                </CardContent>
              </Card>

              {/* Dev Tools */}
              <Card className="bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-700">
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <Terminal className="w-5 h-5 text-gray-500" />
                    Dev Tools
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <p className="text-sm text-slate-600 dark:text-slate-400">
                    Development utilities
                  </p>
                  <div className="grid grid-cols-2 gap-2">
                    <Button variant="outline" size="sm">
                      <RefreshCw className="w-3 h-3 mr-1" />
                      Restart
                    </Button>
                    <Button variant="outline" size="sm">
                      <Download className="w-3 h-3 mr-1" />
                      Logs
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Other tabs with placeholder content */}
          <TabsContent value="bots" className="space-y-6 mt-6">
            <LiveCraigslistBotManager />
          </TabsContent>

          <TabsContent value="analytics" className="space-y-6 mt-6">
            <CraigslistBotAnalytics />
          </TabsContent>

          <TabsContent value="clients" className="space-y-6 mt-6">
            <Card className="bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-700">
              <CardHeader>
                <CardTitle>Client Management</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-slate-600 dark:text-slate-400">Client subscription management coming soon...</p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="settings" className="space-y-6 mt-6">
            <Card className="bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-700">
              <CardHeader>
                <CardTitle>Settings</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-slate-600 dark:text-slate-400">System settings and configuration coming soon...</p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      {/* Live Bot Editor Modal */}
      {showLiveBotEditor && (
        <div className="fixed inset-0 z-50 bg-black/80">
          <LiveBotEditor onClose={() => setShowLiveBotEditor(false)} />
        </div>
      )}

      {/* Simple Bot Editor Modal */}
      {showSimpleBotEditor && (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-lg shadow-xl max-w-4xl w-full max-h-[90vh] overflow-hidden">
            <div className="flex items-center justify-between p-4 border-b border-slate-200 dark:border-slate-700">
              <h2 className="text-lg font-semibold">Simple Bot Editor</h2>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowSimpleBotEditor(false)}
              >
                ✕
              </Button>
            </div>
            <div className="overflow-y-auto max-h-[calc(90vh-4rem)]">
              <SimpleBotEditor />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default CleanDashboard;