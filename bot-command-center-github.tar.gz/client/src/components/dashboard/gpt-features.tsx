import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Bot, Brain, Code, MessageSquare, TrendingUp, Sparkles, Copy, Check } from "lucide-react";

interface EnrichmentResult {
  category: string;
  urgency: 'low' | 'medium' | 'high' | 'urgent';
  location: string;
  contactGuess: string;
  estimatedBudget: number;
  buyerIntent: 'browsing' | 'serious' | 'ready_to_buy';
  extractedInfo: Record<string, any>;
}

interface OutreachMessage {
  subject: string;
  message: string;
  tone: 'professional' | 'friendly' | 'urgent';
  platform: 'sms' | 'email' | 'internal';
}

interface AuctionOpportunityReport {
  financialBreakdown: {
    estimatedValue: number;
    maxBidThreshold: number;
    profitMargin: number;
  };
  resaleVelocity: {
    averageDaysToSell: number;
    marketDemand: 'low' | 'medium' | 'high';
    seasonalFactors: string[];
  };
  leadMatchSummary: {
    matchScore: number;
    keyMatchingFactors: string[];
    riskFactors: string[];
  };
  recommendation: 'pursue' | 'caution' | 'pass';
  reasoning: string;
}

export function GPTFeatures() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // States for different GPT features
  const [rawLeadData, setRawLeadData] = useState('');
  const [selectedVertical, setSelectedVertical] = useState('auto');
  const [leadData, setLeadData] = useState('');
  const [inventoryData, setInventoryData] = useState('');
  const [codeDescription, setCodeDescription] = useState('');
  const [currentCode, setCurrentCode] = useState('');
  const [generatedCode, setGeneratedCode] = useState('');
  const [enrichmentResult, setEnrichmentResult] = useState<EnrichmentResult | null>(null);
  const [outreachResult, setOutreachResult] = useState<OutreachMessage | null>(null);
  const [aorResult, setAorResult] = useState<AuctionOpportunityReport | null>(null);
  const [copiedStates, setCopiedStates] = useState<{[key: string]: boolean}>({});

  // Lead Enrichment Mutation
  const enrichLeadMutation = useMutation({
    mutationFn: async ({ rawLeadData, vertical }: { rawLeadData: string; vertical: string }) => {
      const response = await fetch('/api/advanced/enrich-lead', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ rawLeadData, vertical })
      });
      if (!response.ok) throw new Error('Failed to enrich lead');
      return response.json();
    },
    onSuccess: (data) => {
      setEnrichmentResult(data.enrichment);
      toast({
        title: "Lead Enriched Successfully",
        description: `Category: ${data.enrichment.category}, Urgency: ${data.enrichment.urgency}`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Enrichment Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Outreach Generation Mutation
  const generateOutreachMutation = useMutation({
    mutationFn: async ({ leadData, vertical }: { leadData: string; vertical: string }) => {
      const response = await fetch('/api/advanced/generate-outreach', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ leadData: JSON.parse(leadData), vertical })
      });
      if (!response.ok) throw new Error('Failed to generate outreach');
      return response.json();
    },
    onSuccess: (data) => {
      setOutreachResult(data.outreach);
      toast({
        title: "Outreach Generated",
        description: `Created ${data.outreach.tone} ${data.outreach.platform} message`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Outreach Generation Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // AOR Generation Mutation
  const generateAORMutation = useMutation({
    mutationFn: async ({ leadData, inventoryData, vertical }: { leadData: string; inventoryData: string; vertical: string }) => {
      const response = await fetch('/api/advanced/generate-aor', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          leadData: JSON.parse(leadData), 
          inventoryData: JSON.parse(inventoryData), 
          vertical 
        })
      });
      if (!response.ok) throw new Error('Failed to generate AOR');
      return response.json();
    },
    onSuccess: (data) => {
      setAorResult(data.aor);
      toast({
        title: "AOR Generated",
        description: `Recommendation: ${data.aor.recommendation}, Match Score: ${data.aor.leadMatchSummary.matchScore}%`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "AOR Generation Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Code Generation Mutation
  const generateCodeMutation = useMutation({
    mutationFn: async ({ description, currentCode }: { description: string; currentCode?: string }) => {
      const response = await fetch('/api/advanced/generate-code', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ description, currentCode })
      });
      if (!response.ok) throw new Error('Failed to generate code');
      return response.json();
    },
    onSuccess: (data) => {
      setGeneratedCode(data.code);
      toast({
        title: "Code Generated Successfully",
        description: "GPT-4 has generated your code",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Code Generation Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const copyToClipboard = async (text: string, key: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedStates(prev => ({ ...prev, [key]: true }));
      setTimeout(() => {
        setCopiedStates(prev => ({ ...prev, [key]: false }));
      }, 2000);
    } catch (err) {
      console.error('Failed to copy:', err);
    }
  };

  const getUrgencyColor = (urgency: string) => {
    switch (urgency) {
      case 'urgent': return 'bg-red-500';
      case 'high': return 'bg-orange-500';
      case 'medium': return 'bg-yellow-500';
      case 'low': return 'bg-green-500';
      default: return 'bg-gray-500';
    }
  };

  const getRecommendationColor = (recommendation: string) => {
    switch (recommendation) {
      case 'pursue': return 'bg-green-500';
      case 'caution': return 'bg-yellow-500';
      case 'pass': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-2">
        <Sparkles className="h-6 w-6 text-purple-500" />
        <h2 className="text-2xl font-bold">GPT-Powered Features</h2>
        <Badge variant="secondary">OpenAI Integration</Badge>
      </div>

      <Tabs defaultValue="enrichment" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="enrichment" className="flex items-center space-x-2">
            <Brain className="h-4 w-4" />
            <span>Lead Enrichment</span>
          </TabsTrigger>
          <TabsTrigger value="outreach" className="flex items-center space-x-2">
            <MessageSquare className="h-4 w-4" />
            <span>Outreach Bot</span>
          </TabsTrigger>
          <TabsTrigger value="aor" className="flex items-center space-x-2">
            <TrendingUp className="h-4 w-4" />
            <span>AOR Generator</span>
          </TabsTrigger>
          <TabsTrigger value="code" className="flex items-center space-x-2">
            <Code className="h-4 w-4" />
            <span>GPT-4 Editor</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="enrichment" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Brain className="h-5 w-5 text-blue-500" />
                <span>Lead Enrichment Bot</span>
              </CardTitle>
              <CardDescription>
                Analyze raw lead data and extract structured information using GPT-4
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="vertical">Vertical</Label>
                  <Select value={selectedVertical} onValueChange={setSelectedVertical}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="auto">Auto</SelectItem>
                      <SelectItem value="realestate">Real Estate</SelectItem>
                      <SelectItem value="pets">Pets</SelectItem>
                      <SelectItem value="goods">Goods</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div /> {/* Empty space for layout */}
              </div>

              <div className="space-y-2">
                <Label htmlFor="rawLead">Raw Lead Data</Label>
                <Textarea
                  id="rawLead"
                  placeholder="Paste raw lead data here (Craigslist ad, Facebook post, etc.)"
                  value={rawLeadData}
                  onChange={(e) => setRawLeadData(e.target.value)}
                  rows={6}
                />
              </div>

              <Button 
                onClick={() => enrichLeadMutation.mutate({ rawLeadData, vertical: selectedVertical })}
                disabled={!rawLeadData || enrichLeadMutation.isPending}
                className="w-full"
              >
                {enrichLeadMutation.isPending ? 'Enriching...' : 'Enrich Lead with GPT-4'}
              </Button>

              {enrichmentResult && (
                <Card className="mt-4">
                  <CardHeader>
                    <CardTitle className="text-lg">Enrichment Results</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label className="text-sm font-medium">Category</Label>
                        <p className="text-sm">{enrichmentResult.category}</p>
                      </div>
                      <div>
                        <Label className="text-sm font-medium">Urgency</Label>
                        <Badge className={`${getUrgencyColor(enrichmentResult.urgency)} text-white`}>
                          {enrichmentResult.urgency}
                        </Badge>
                      </div>
                      <div>
                        <Label className="text-sm font-medium">Location</Label>
                        <p className="text-sm">{enrichmentResult.location}</p>
                      </div>
                      <div>
                        <Label className="text-sm font-medium">Buyer Intent</Label>
                        <p className="text-sm">{enrichmentResult.buyerIntent}</p>
                      </div>
                      <div>
                        <Label className="text-sm font-medium">Contact Guess</Label>
                        <p className="text-sm">{enrichmentResult.contactGuess || 'Not found'}</p>
                      </div>
                      <div>
                        <Label className="text-sm font-medium">Estimated Budget</Label>
                        <p className="text-sm">${enrichmentResult.estimatedBudget?.toLocaleString() || 'Unknown'}</p>
                      </div>
                    </div>
                    
                    {enrichmentResult.extractedInfo && Object.keys(enrichmentResult.extractedInfo).length > 0 && (
                      <div>
                        <Label className="text-sm font-medium">Additional Info</Label>
                        <pre className="text-xs bg-gray-100 p-2 rounded overflow-auto">
                          {JSON.stringify(enrichmentResult.extractedInfo, null, 2)}
                        </pre>
                      </div>
                    )}
                  </CardContent>
                </Card>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="outreach" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <MessageSquare className="h-5 w-5 text-green-500" />
                <span>Outreach Message Generator</span>
              </CardTitle>
              <CardDescription>
                Generate personalized outreach messages based on lead data
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="vertical-outreach">Vertical</Label>
                  <Select value={selectedVertical} onValueChange={setSelectedVertical}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="auto">Auto</SelectItem>
                      <SelectItem value="realestate">Real Estate</SelectItem>
                      <SelectItem value="pets">Pets</SelectItem>
                      <SelectItem value="goods">Goods</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="leadData">Lead Data (JSON format)</Label>
                <Textarea
                  id="leadData"
                  placeholder='{"name": "John Doe", "interest": "2015 Honda Civic", "urgency": "high", "budget": 12000}'
                  value={leadData}
                  onChange={(e) => setLeadData(e.target.value)}
                  rows={6}
                />
              </div>

              <Button 
                onClick={() => generateOutreachMutation.mutate({ leadData, vertical: selectedVertical })}
                disabled={!leadData || generateOutreachMutation.isPending}
                className="w-full"
              >
                {generateOutreachMutation.isPending ? 'Generating...' : 'Generate Outreach Message'}
              </Button>

              {outreachResult && (
                <Card className="mt-4">
                  <CardHeader>
                    <CardTitle className="text-lg flex items-center justify-between">
                      Outreach Message
                      <div className="flex space-x-2">
                        <Badge>{outreachResult.tone}</Badge>
                        <Badge>{outreachResult.platform}</Badge>
                      </div>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div>
                      <div className="flex items-center justify-between">
                        <Label className="text-sm font-medium">Subject Line</Label>
                        <Button
                          variant="ghost" 
                          size="sm"
                          onClick={() => copyToClipboard(outreachResult.subject, 'subject')}
                        >
                          {copiedStates.subject ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                        </Button>
                      </div>
                      <p className="text-sm bg-gray-50 p-2 rounded">{outreachResult.subject}</p>
                    </div>
                    
                    <div>
                      <div className="flex items-center justify-between">
                        <Label className="text-sm font-medium">Message</Label>
                        <Button
                          variant="ghost" 
                          size="sm"
                          onClick={() => copyToClipboard(outreachResult.message, 'message')}
                        >
                          {copiedStates.message ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                        </Button>
                      </div>
                      <p className="text-sm bg-gray-50 p-3 rounded whitespace-pre-wrap">{outreachResult.message}</p>
                    </div>
                  </CardContent>
                </Card>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="aor" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <TrendingUp className="h-5 w-5 text-purple-500" />
                <span>Auction Opportunity Report Generator</span>
              </CardTitle>
              <CardDescription>
                Generate comprehensive AORs by matching leads to inventory
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="vertical-aor">Vertical</Label>
                  <Select value={selectedVertical} onValueChange={setSelectedVertical}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="auto">Auto</SelectItem>
                      <SelectItem value="realestate">Real Estate</SelectItem>
                      <SelectItem value="pets">Pets</SelectItem>
                      <SelectItem value="goods">Goods</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="leadDataAOR">Lead Data (JSON)</Label>
                  <Textarea
                    id="leadDataAOR"
                    placeholder='{"interest": "2015 Honda Civic", "budget": 12000, "urgency": "high"}'
                    value={leadData}
                    onChange={(e) => setLeadData(e.target.value)}
                    rows={4}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="inventoryDataAOR">Inventory Data (JSON)</Label>
                  <Textarea
                    id="inventoryDataAOR"
                    placeholder='{"vehicle": "2015 Honda Civic LX", "mileage": 85000, "auctionPrice": 8500}'
                    value={inventoryData}
                    onChange={(e) => setInventoryData(e.target.value)}
                    rows={4}
                  />
                </div>
              </div>

              <Button 
                onClick={() => generateAORMutation.mutate({ leadData, inventoryData, vertical: selectedVertical })}
                disabled={!leadData || !inventoryData || generateAORMutation.isPending}
                className="w-full"
              >
                {generateAORMutation.isPending ? 'Generating AOR...' : 'Generate Auction Opportunity Report'}
              </Button>

              {aorResult && (
                <Card className="mt-4">
                  <CardHeader>
                    <CardTitle className="text-lg flex items-center justify-between">
                      Auction Opportunity Report
                      <Badge className={`${getRecommendationColor(aorResult.recommendation)} text-white`}>
                        {aorResult.recommendation.toUpperCase()}
                      </Badge>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-3 gap-4">
                      <div className="text-center">
                        <Label className="text-sm font-medium">Match Score</Label>
                        <p className="text-2xl font-bold text-blue-600">{aorResult.leadMatchSummary.matchScore}%</p>
                      </div>
                      <div className="text-center">
                        <Label className="text-sm font-medium">Max Bid</Label>
                        <p className="text-2xl font-bold text-green-600">
                          ${aorResult.financialBreakdown.maxBidThreshold?.toLocaleString()}
                        </p>
                      </div>
                      <div className="text-center">
                        <Label className="text-sm font-medium">Profit Margin</Label>
                        <p className="text-2xl font-bold text-purple-600">
                          ${aorResult.financialBreakdown.profitMargin?.toLocaleString()}
                        </p>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label className="text-sm font-medium">Key Matching Factors</Label>
                        <ul className="text-sm space-y-1 mt-1">
                          {aorResult.leadMatchSummary.keyMatchingFactors?.map((factor, idx) => (
                            <li key={idx} className="flex items-center space-x-2">
                              <span className="w-2 h-2 bg-green-500 rounded-full"></span>
                              <span>{factor}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                      <div>
                        <Label className="text-sm font-medium">Risk Factors</Label>
                        <ul className="text-sm space-y-1 mt-1">
                          {aorResult.leadMatchSummary.riskFactors?.map((risk, idx) => (
                            <li key={idx} className="flex items-center space-x-2">
                              <span className="w-2 h-2 bg-red-500 rounded-full"></span>
                              <span>{risk}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>

                    <div>
                      <Label className="text-sm font-medium">Market Analysis</Label>
                      <div className="grid grid-cols-2 gap-4 mt-2">
                        <div>
                          <p className="text-xs text-gray-600">Average Days to Sell</p>
                          <p className="font-medium">{aorResult.resaleVelocity.averageDaysToSell} days</p>
                        </div>
                        <div>
                          <p className="text-xs text-gray-600">Market Demand</p>
                          <Badge variant={aorResult.resaleVelocity.marketDemand === 'high' ? 'default' : 'secondary'}>
                            {aorResult.resaleVelocity.marketDemand}
                          </Badge>
                        </div>
                      </div>
                    </div>

                    <div>
                      <Label className="text-sm font-medium">Reasoning</Label>
                      <p className="text-sm bg-gray-50 p-3 rounded mt-1">{aorResult.reasoning}</p>
                    </div>
                  </CardContent>
                </Card>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="code" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Code className="h-5 w-5 text-orange-500" />
                <span>GPT-4 Code Editor</span>
              </CardTitle>
              <CardDescription>
                Generate and modify bot code using GPT-4
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="codeDescription">Code Description</Label>
                <Textarea
                  id="codeDescription"
                  placeholder="Describe what you want to build or modify (e.g., 'Add proxy rotation to scraper', 'Create email validation function')"
                  value={codeDescription}
                  onChange={(e) => setCodeDescription(e.target.value)}
                  rows={3}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="currentCode">Current Code (Optional)</Label>
                <Textarea
                  id="currentCode"
                  placeholder="Paste existing code here if you want to modify it"
                  value={currentCode}
                  onChange={(e) => setCurrentCode(e.target.value)}
                  rows={8}
                  className="font-mono text-sm"
                />
              </div>

              <Button 
                onClick={() => generateCodeMutation.mutate({ description: codeDescription, currentCode: currentCode || undefined })}
                disabled={!codeDescription || generateCodeMutation.isPending}
                className="w-full"
              >
                {generateCodeMutation.isPending ? 'Generating Code...' : 'Generate Code with GPT-4'}
              </Button>

              {generatedCode && (
                <Card className="mt-4">
                  <CardHeader>
                    <CardTitle className="text-lg flex items-center justify-between">
                      Generated Code
                      <Button
                        variant="ghost" 
                        size="sm"
                        onClick={() => copyToClipboard(generatedCode, 'code')}
                      >
                        {copiedStates.code ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                      </Button>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <pre className="text-xs bg-gray-900 text-green-400 p-4 rounded overflow-auto max-h-96">
                      {generatedCode}
                    </pre>
                  </CardContent>
                </Card>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}