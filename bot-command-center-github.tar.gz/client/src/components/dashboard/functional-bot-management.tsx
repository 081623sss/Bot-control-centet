import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Play, Pause, Square, Settings, RotateCcw, Camera, 
  AlertTriangle, CheckCircle, XCircle, Clock, Bot,
  Activity, Database, Zap, TrendingUp
} from 'lucide-react';
import { BotInstance, Alert as AlertType } from '@shared/schema';

interface HealthOverview {
  activeBots: number;
  failures24h: number;
  warnings: number;
  recentAlerts: AlertType[];
}

export function FunctionalBotManagement() {
  const [selectedBot, setSelectedBot] = useState<number | null>(null);
  const [showHealthDetails, setShowHealthDetails] = useState(false);
  const queryClient = useQueryClient();

  // Fetch health overview
  const { data: healthData, isLoading: healthLoading } = useQuery<{ success: boolean; data: HealthOverview }>({
    queryKey: ['/api/advanced/health-overview'],
    refetchInterval: 10000, // Refresh every 10 seconds
  });

  // Fetch bots with enhanced details
  const { data: botsData, isLoading: botsLoading } = useQuery<{ success: boolean; data: BotInstance[] }>({
    queryKey: ['/api/advanced/bots'],
    refetchInterval: 5000, // Refresh every 5 seconds
  });

  // Bot action mutations
  const startBotMutation = useMutation({
    mutationFn: async (botId: number) => {
      const response = await fetch(`/api/advanced/bots/${botId}/start`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      });
      if (!response.ok) throw new Error('Failed to start bot');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/advanced/bots'] });
      queryClient.invalidateQueries({ queryKey: ['/api/advanced/health-overview'] });
    },
  });

  const stopBotMutation = useMutation({
    mutationFn: async (botId: number) => {
      const response = await fetch(`/api/advanced/bots/${botId}/stop`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      });
      if (!response.ok) throw new Error('Failed to stop bot');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/advanced/bots'] });
      queryClient.invalidateQueries({ queryKey: ['/api/advanced/health-overview'] });
    },
  });

  const pauseBotMutation = useMutation({
    mutationFn: async (botId: number) => {
      const response = await fetch(`/api/advanced/bots/${botId}/pause`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      });
      if (!response.ok) throw new Error('Failed to pause bot');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/advanced/bots'] });
    },
  });

  const snapshotMutation = useMutation({
    mutationFn: async (botId: number) => {
      const response = await fetch(`/api/advanced/bots/${botId}/snapshot`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ description: `Manual snapshot - ${new Date().toISOString()}` }),
      });
      if (!response.ok) throw new Error('Failed to create snapshot');
      return response.json();
    },
  });

  const rollbackMutation = useMutation({
    mutationFn: async (botId: number) => {
      const response = await fetch(`/api/advanced/bots/${botId}/rollback`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      });
      if (!response.ok) throw new Error('Failed to rollback bot');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/advanced/bots'] });
    },
  });

  const bots = botsData?.data || [];
  const health = healthData?.data;

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'running': return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'stopped': return <XCircle className="w-4 h-4 text-red-500" />;
      case 'paused': return <Pause className="w-4 h-4 text-yellow-500" />;
      case 'error': return <AlertTriangle className="w-4 h-4 text-red-500" />;
      default: return <Clock className="w-4 h-4 text-gray-500" />;
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical': return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200';
      case 'high': return 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200';
      case 'medium': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200';
      case 'low': return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-200';
    }
  };

  return (
    <div className="space-y-4 sm:space-y-6">
      {/* Health Monitor Banner - Mobile-First */}
      <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-950 dark:to-indigo-950 border-blue-200 dark:border-blue-800">
        <CardHeader className="pb-2 sm:pb-3 p-3 sm:p-6">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 sm:gap-0">
            <CardTitle className="flex items-center gap-2 text-base sm:text-lg text-blue-900 dark:text-blue-100">
              <Activity className="w-4 h-4 sm:w-5 sm:h-5" />
              System Health Monitor
            </CardTitle>
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => setShowHealthDetails(!showHealthDetails)}
              className="border-blue-300 text-blue-700 hover:bg-blue-100 dark:border-blue-600 dark:text-blue-300 text-xs sm:text-sm self-start sm:self-auto"
            >
              {showHealthDetails ? 'Hide Details' : 'View Details'}
            </Button>
          </div>
        </CardHeader>
        <CardContent className="p-3 sm:p-6 pt-0">
          {healthLoading ? (
            <div className="text-blue-600 dark:text-blue-400 text-sm">Loading health data...</div>
          ) : health ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 sm:gap-4">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-green-100 dark:bg-green-900 rounded-lg">
                  <Bot className="w-5 h-5 text-green-600 dark:text-green-400" />
                </div>
                <div>
                  <div className="text-2xl font-bold text-green-600 dark:text-green-400">{health.activeBots}</div>
                  <div className="text-sm text-blue-700 dark:text-blue-300">Active Bots</div>
                </div>
              </div>
              
              <div className="flex items-center gap-3">
                <div className="p-2 bg-red-100 dark:bg-red-900 rounded-lg">
                  <XCircle className="w-5 h-5 text-red-600 dark:text-red-400" />
                </div>
                <div>
                  <div className="text-2xl font-bold text-red-600 dark:text-red-400">{health.failures24h}</div>
                  <div className="text-sm text-blue-700 dark:text-blue-300">Failures (24h)</div>
                </div>
              </div>
              
              <div className="flex items-center gap-3">
                <div className="p-2 bg-yellow-100 dark:bg-yellow-900 rounded-lg">
                  <AlertTriangle className="w-5 h-5 text-yellow-600 dark:text-yellow-400" />
                </div>
                <div>
                  <div className="text-2xl font-bold text-yellow-600 dark:text-yellow-400">{health.warnings}</div>
                  <div className="text-sm text-blue-700 dark:text-blue-300">Active Warnings</div>
                </div>
              </div>
            </div>
          ) : (
            <div className="text-red-600 dark:text-red-400">Failed to load health data</div>
          )}

          {/* Health Details Expandable */}
          {showHealthDetails && health?.recentAlerts && (
            <div className="mt-4 pt-4 border-t border-blue-200 dark:border-blue-700">
              <h4 className="font-medium text-blue-900 dark:text-blue-100 mb-3">Recent Alerts</h4>
              <div className="space-y-2 max-h-60 overflow-y-auto">
                {health.recentAlerts.length > 0 ? health.recentAlerts.map((alert) => (
                  <div key={alert.id} className="flex items-start gap-3 p-3 bg-white dark:bg-slate-800 rounded-lg border">
                    <AlertTriangle className={`w-4 h-4 mt-0.5 ${
                      alert.severity === 'high' ? 'text-red-500' : 
                      alert.severity === 'medium' ? 'text-yellow-500' : 'text-blue-500'
                    }`} />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <h5 className="font-medium text-slate-900 dark:text-white">{alert.title}</h5>
                        <Badge className={getSeverityColor(alert.severity)}>{alert.severity}</Badge>
                      </div>
                      <p className="text-sm text-slate-600 dark:text-slate-400">{alert.message}</p>
                      {alert.suggestedAction && (
                        <p className="text-xs text-blue-600 dark:text-blue-400 mt-1">
                          💡 {alert.suggestedAction}
                        </p>
                      )}
                      <p className="text-xs text-slate-500 dark:text-slate-500 mt-1">
                        {new Date(alert.createdAt).toLocaleString()}
                      </p>
                    </div>
                  </div>
                )) : (
                  <div className="text-center py-4 text-slate-500 dark:text-slate-400">
                    <CheckCircle className="w-8 h-8 mx-auto mb-2 text-green-500" />
                    <p>No recent alerts - system is healthy!</p>
                  </div>
                )}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Bot Management Grid */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {botsLoading ? (
          // Loading skeleton
          Array.from({ length: 6 }).map((_, i) => (
            <Card key={i} className="animate-pulse">
              <CardContent className="p-6">
                <div className="h-4 bg-slate-200 dark:bg-slate-700 rounded mb-2"></div>
                <div className="h-3 bg-slate-200 dark:bg-slate-700 rounded mb-4"></div>
                <div className="h-2 bg-slate-200 dark:bg-slate-700 rounded mb-4"></div>
                <div className="flex gap-2">
                  <div className="h-8 w-16 bg-slate-200 dark:bg-slate-700 rounded"></div>
                  <div className="h-8 w-16 bg-slate-200 dark:bg-slate-700 rounded"></div>
                </div>
              </CardContent>
            </Card>
          ))
        ) : bots.length > 0 ? bots.map((bot) => (
          <Card key={bot.id} className="bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-700 hover:shadow-lg transition-shadow">
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between">
                <div>
                  <CardTitle className="text-lg flex items-center gap-2">
                    {getStatusIcon(bot.status)}
                    {bot.name}
                  </CardTitle>
                  <p className="text-sm text-slate-600 dark:text-slate-400">
                    {bot.city} • {bot.platform} • {bot.vertical}
                  </p>
                </div>
                <Badge variant={bot.status === 'running' ? 'default' : 'secondary'}>
                  {bot.status}
                </Badge>
              </div>
            </CardHeader>

            <CardContent className="space-y-4">
              {/* Progress Bar for Running Bots */}
              {bot.status === 'running' && (
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Progress</span>
                    <span>{bot.progress || 0}%</span>
                  </div>
                  <Progress value={bot.progress || 0} className="h-2" />
                </div>
              )}

              {/* Stats */}
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <div className="text-slate-600 dark:text-slate-400">Today</div>
                  <div className="font-bold text-lg">{bot.dailyCount || 0}</div>
                </div>
                <div>
                  <div className="text-slate-600 dark:text-slate-400">Success Rate</div>
                  <div className="font-bold text-lg text-green-600 dark:text-green-400">
                    {bot.successRate ? `${bot.successRate}%` : 'N/A'}
                  </div>
                </div>
                <div>
                  <div className="text-slate-600 dark:text-slate-400">Total Scraped</div>
                  <div className="font-bold">{bot.totalScraped || 0}</div>
                </div>
                <div>
                  <div className="text-slate-600 dark:text-slate-400">Last Run</div>
                  <div className="font-bold text-xs">
                    {bot.lastRun ? new Date(bot.lastRun).toLocaleString() : 'Never'}
                  </div>
                </div>
              </div>

              {/* Control Buttons */}
              <div className="flex flex-wrap gap-2 pt-2">
                {bot.status === 'running' ? (
                  <Button 
                    size="sm" 
                    variant="outline"
                    onClick={() => pauseBotMutation.mutate(bot.id)}
                    disabled={pauseBotMutation.isPending}
                    className="flex-1"
                  >
                    <Pause className="w-3 h-3 mr-1" />
                    Pause
                  </Button>
                ) : (
                  <Button 
                    size="sm" 
                    variant="default"
                    onClick={() => startBotMutation.mutate(bot.id)}
                    disabled={startBotMutation.isPending}
                    className="flex-1 bg-green-600 hover:bg-green-700"
                  >
                    <Play className="w-3 h-3 mr-1" />
                    Start
                  </Button>
                )}

                <Button 
                  size="sm" 
                  variant="outline"
                  onClick={() => stopBotMutation.mutate(bot.id)}
                  disabled={stopBotMutation.isPending}
                  className="flex-1"
                >
                  <Square className="w-3 h-3 mr-1" />
                  Stop
                </Button>
              </div>

              <div className="flex gap-2">
                <Button 
                  size="sm" 
                  variant="outline"
                  onClick={() => snapshotMutation.mutate(bot.id)}
                  disabled={snapshotMutation.isPending}
                  className="flex-1"
                >
                  <Camera className="w-3 h-3 mr-1" />
                  Snapshot
                </Button>

                <Button 
                  size="sm" 
                  variant="outline"
                  onClick={() => rollbackMutation.mutate(bot.id)}
                  disabled={rollbackMutation.isPending}
                  className="flex-1"
                >
                  <RotateCcw className="w-3 h-3 mr-1" />
                  Rollback
                </Button>

                <Button 
                  size="sm" 
                  variant="outline"
                  onClick={() => setSelectedBot(bot.id)}
                  className="flex-1"
                >
                  <Settings className="w-3 h-3 mr-1" />
                  Config
                </Button>
              </div>

              {/* Version Info */}
              <div className="text-xs text-slate-500 dark:text-slate-400 pt-2 border-t">
                Version: {bot.version} • Type: {bot.type}
              </div>
            </CardContent>
          </Card>
        )) : (
          <div className="col-span-full text-center py-12">
            <Bot className="w-16 h-16 mx-auto mb-4 text-slate-400" />
            <h3 className="text-lg font-medium text-slate-900 dark:text-white mb-2">No Bots Found</h3>
            <p className="text-slate-600 dark:text-slate-400">
              Connect your first bot to get started with automated lead generation.
            </p>
          </div>
        )}
      </div>

      {/* Action Status Messages */}
      {(startBotMutation.isSuccess || stopBotMutation.isSuccess || pauseBotMutation.isSuccess || 
        snapshotMutation.isSuccess || rollbackMutation.isSuccess) && (
        <Alert className="border-green-200 bg-green-50 dark:border-green-800 dark:bg-green-950">
          <CheckCircle className="w-4 h-4 text-green-600" />
          <AlertDescription className="text-green-800 dark:text-green-200">
            Action completed successfully! Bot status has been updated.
          </AlertDescription>
        </Alert>
      )}

      {(startBotMutation.isError || stopBotMutation.isError || pauseBotMutation.isError || 
        snapshotMutation.isError || rollbackMutation.isError) && (
        <Alert className="border-red-200 bg-red-50 dark:border-red-800 dark:bg-red-950">
          <XCircle className="w-4 h-4 text-red-600" />
          <AlertDescription className="text-red-800 dark:text-red-200">
            Action failed. Please check your connection to the Termius server and try again.
          </AlertDescription>
        </Alert>
      )}
    </div>
  );
}