import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { useToast } from '@/hooks/use-toast'
import { 
  Wifi, 
  WifiOff, 
  RefreshCw, 
  ExternalLink, 
  Copy,
  Terminal,
  CheckCircle,
  XCircle,
  AlertTriangle,
  Zap
} from 'lucide-react'

interface NgrokStatus {
  connected: boolean
  publicUrl: string | null
  error: string | null
  pid: number | null
}

export default function NgrokStatus() {
  const [status, setStatus] = useState<NgrokStatus>({
    connected: false,
    publicUrl: null,
    error: null,
    pid: null
  })
  const [isLoading, setIsLoading] = useState(false)
  const { toast } = useToast()

  const fetchStatus = async () => {
    try {
      const response = await fetch('/api/public/ngrok-status')
      const data = await response.json()
      
      if (data.success) {
        setStatus(data.status)
      } else {
        console.error('Failed to fetch ngrok status:', data.message)
      }
    } catch (error) {
      console.error('Error fetching ngrok status:', error)
    }
  }

  const restartNgrok = async () => {
    setIsLoading(true)
    try {
      const response = await fetch('/api/ngrok/restart', {
        method: 'POST',
        credentials: 'include'
      })
      const data = await response.json()
      
      if (data.success) {
        toast({
          title: "Ngrok Restarted",
          description: "Tunnel restart initiated successfully",
        })
        // Wait a moment then refresh status
        setTimeout(fetchStatus, 2000)
      } else {
        toast({
          title: "Restart Failed",
          description: data.message,
          variant: "destructive"
        })
      }
    } catch (error) {
      toast({
        title: "Restart Failed",
        description: "Network error while restarting tunnel",
        variant: "destructive"
      })
    } finally {
      setIsLoading(false)
    }
  }

  const copyUrl = () => {
    if (status.publicUrl) {
      navigator.clipboard.writeText(status.publicUrl)
      toast({
        title: "URL Copied",
        description: "Ngrok URL copied to clipboard",
      })
    }
  }

  const openUrl = () => {
    if (status.publicUrl) {
      window.open(status.publicUrl, '_blank')
    }
  }

  useEffect(() => {
    fetchStatus()
    const interval = setInterval(fetchStatus, 5000) // Check every 5 seconds
    return () => clearInterval(interval)
  }, [])

  const getStatusIcon = () => {
    if (status.connected) {
      return <CheckCircle className="w-5 h-5 text-green-400" />
    } else if (status.error) {
      return <XCircle className="w-5 h-5 text-red-400" />
    } else {
      return <AlertTriangle className="w-5 h-5 text-yellow-400" />
    }
  }

  const getStatusBadge = () => {
    if (status.connected) {
      return (
        <Badge className="bg-green-500/20 text-green-300 border-green-400/50">
          <Wifi className="w-3 h-3 mr-1" />
          Connected ✅
        </Badge>
      )
    } else {
      return (
        <Badge variant="destructive" className="bg-red-500/20 text-red-300 border-red-400/50">
          <WifiOff className="w-3 h-3 mr-1" />
          Disconnected
        </Badge>
      )
    }
  }

  return (
    <Card className="bg-gradient-to-br from-slate-800/50 to-blue-800/20 border-blue-500/30 shadow-xl backdrop-blur-sm">
      <CardHeader className="pb-3 sm:pb-4 border-b border-blue-500/20 p-3 sm:p-6">
        <CardTitle className="text-white flex items-center gap-2 sm:gap-3 text-base sm:text-lg">
          <div className="p-1.5 sm:p-2 bg-blue-500/20 rounded-lg">
            <Zap className="w-4 h-4 sm:w-5 sm:h-5 text-blue-400" />
          </div>
          Termius Bot Server Status
          {getStatusBadge()}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3 sm:space-y-4 p-3 sm:p-6">
        {/* Connection Status */}
        <div className="flex items-center gap-2 sm:gap-3">
          {getStatusIcon()}
          <div className="flex-1 min-w-0">
            <div className="text-white font-medium text-sm sm:text-base">
              {status.connected ? 'Tunnel Active' : 'Tunnel Inactive'}
            </div>
            <div className="text-xs sm:text-sm text-slate-400 truncate">
              {status.connected 
                ? 'Bot server accessible via ngrok tunnel'
                : 'Bot server not reachable'
              }
            </div>
          </div>
        </div>

        {/* Public URL */}
        {status.publicUrl && (
          <div className="space-y-2">
            <div className="text-xs sm:text-sm text-blue-200 font-medium">Public Tunnel URL:</div>
            <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2 p-2 sm:p-3 bg-slate-900/50 rounded-lg border border-blue-500/30">
              <div className="flex items-center gap-2 flex-1 min-w-0">
                <Terminal className="w-3 h-3 sm:w-4 sm:h-4 text-blue-400 flex-shrink-0" />
                <code className="text-blue-200 text-xs sm:text-sm font-mono break-all">
                  {status.publicUrl}
                </code>
              </div>
              <div className="flex gap-2 flex-shrink-0">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={copyUrl}
                  className="bg-blue-500/20 border-blue-400/50 text-blue-200 hover:bg-blue-500/30 text-xs px-2 py-1"
                >
                  <Copy className="w-3 h-3" />
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={openUrl}
                  className="bg-green-500/20 border-green-400/50 text-green-200 hover:bg-green-500/30 text-xs px-2 py-1"
                >
                  <ExternalLink className="w-3 h-3" />
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* Error Display */}
        {status.error && (
          <div className="p-3 bg-red-500/10 border border-red-400/30 rounded-lg">
            <div className="text-sm text-red-200 font-medium mb-1">Error:</div>
            <div className="text-xs text-red-300 font-mono break-words">
              {status.error}
            </div>
          </div>
        )}

        {/* Process Info */}
        {status.pid && (
          <div className="text-xs text-slate-400">
            Process ID: {status.pid}
          </div>
        )}

        {/* Controls */}
        <div className="flex gap-2 pt-2">
          <Button
            onClick={fetchStatus}
            size="sm"
            variant="outline"
            className="bg-blue-500/20 border-blue-400/50 text-blue-200 hover:bg-blue-500/30"
          >
            <RefreshCw className="w-3 h-3 mr-1" />
            Refresh
          </Button>
          <Button
            onClick={restartNgrok}
            disabled={isLoading}
            size="sm"
            variant="outline"
            className="bg-orange-500/20 border-orange-400/50 text-orange-200 hover:bg-orange-500/30"
          >
            <Zap className="w-3 h-3 mr-1" />
            {isLoading ? 'Restarting...' : 'Restart Tunnel'}
          </Button>
        </div>

        {/* Info */}
        <div className="text-xs text-slate-400 border-t border-slate-700/50 pt-3">
          <div className="flex items-center gap-1">
            <Terminal className="w-3 h-3" />
            Bot commands are sent to <code>/bot-command</code> endpoint
          </div>
        </div>
      </CardContent>
    </Card>
  )
}