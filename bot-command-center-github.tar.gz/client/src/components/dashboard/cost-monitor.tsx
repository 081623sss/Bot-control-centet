import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { 
  DollarSign, 
  Brain, 
  Zap, 
  TrendingUp, 
  TrendingDown,
  AlertTriangle,
  Database,
  Globe,
  Calendar
} from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { getQueryFn } from "@/lib/queryClient";
import type { GptStats } from "@/lib/types";

interface CostMonitorProps {
  className?: string;
}

interface BotCost {
  botId: number;
  botName: string;
  tokensUsed: number;
  cost: number;
  requests: number;
  platform: string;
}

interface ApiStats {
  openai: {
    tokensUsed: number;
    cost: number;
    requests: number;
    dailyLimit: number;
    weeklyUsage: number;
  };
  airtable: {
    requests: number;
    estimated: boolean;
    limit: number;
  };
  supabase: {
    requests: number;
    estimated: boolean;
    bandwidth: number;
  };
}

export default function CostMonitor({ className }: CostMonitorProps) {
  // Get GPT usage stats
  const { data: gptStats } = useQuery({
    queryKey: ['/api/gpt-stats'],
    queryFn: getQueryFn({ on401: "returnNull" }),
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  // Get bot-specific costs (mocked for now, would come from backend)
  const botCosts: BotCost[] = [
    {
      botId: 1,
      botName: "Orlando Scraper",
      tokensUsed: 12500,
      cost: 0.0375,
      requests: 45,
      platform: "craigslist"
    },
    {
      botId: 2,
      botName: "Tampa Scraper", 
      tokensUsed: 8900,
      cost: 0.0267,
      requests: 32,
      platform: "craigslist"
    },
    {
      botId: 3,
      botName: "Enrichment Bot",
      tokensUsed: 45000,
      cost: 0.135,
      requests: 123,
      platform: "api"
    },
    {
      botId: 4,
      botName: "Outreach Bot",
      tokensUsed: 23000,
      cost: 0.069,
      requests: 67,
      platform: "email"
    },
    {
      botId: 5,
      botName: "Matching Bot",
      tokensUsed: 18500,
      cost: 0.0555,
      requests: 54,
      platform: "api"
    }
  ];

  // Mock API stats (would come from backend monitoring)
  const apiStats: ApiStats = {
    openai: {
      tokensUsed: gptStats?.totalTokens || 108000,
      cost: gptStats?.totalCost || 0.324,
      requests: gptStats?.requestCount || 321,
      dailyLimit: 1000000,
      weeklyUsage: 756000
    },
    airtable: {
      requests: 1250,
      estimated: true,
      limit: 5000
    },
    supabase: {
      requests: 3420,
      estimated: true,
      bandwidth: 45.2
    }
  };

  const dailyBudget = 5.00; // $5 daily budget
  const weeklyBudget = 30.00; // $30 weekly budget
  const currentDailyCost = apiStats.openai.cost;
  const weeklyProjection = currentDailyCost * 7;

  const getDailyUsageStatus = () => {
    const percentage = (currentDailyCost / dailyBudget) * 100;
    if (percentage > 90) return { color: "text-red-400", bg: "bg-red-500", status: "critical" };
    if (percentage > 70) return { color: "text-amber-400", bg: "bg-amber-500", status: "warning" };
    return { color: "text-emerald-400", bg: "bg-emerald-500", status: "good" };
  };

  const getWeeklyProjectionStatus = () => {
    const percentage = (weeklyProjection / weeklyBudget) * 100;
    if (percentage > 90) return { color: "text-red-400", icon: TrendingUp, status: "Over Budget" };
    if (percentage > 70) return { color: "text-amber-400", icon: TrendingUp, status: "High Usage" };
    return { color: "text-emerald-400", icon: TrendingDown, status: "On Track" };
  };

  const dailyStatus = getDailyUsageStatus();
  const weeklyStatus = getWeeklyProjectionStatus();
  const WeeklyIcon = weeklyStatus.icon;

  return (
    <div className={`space-y-6 ${className}`}>
      {/* Cost Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="bg-slate-900 border-slate-700">
          <CardHeader className="pb-3">
            <CardTitle className="text-white flex items-center gap-2 text-lg">
              <DollarSign className="w-5 h-5 text-green-400" />
              Daily Cost
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-end gap-2">
                <span className="text-3xl font-bold text-white">
                  ${currentDailyCost.toFixed(4)}
                </span>
                <span className="text-slate-400 text-sm">/ ${dailyBudget.toFixed(2)}</span>
              </div>
              
              <Progress 
                value={(currentDailyCost / dailyBudget) * 100} 
                className="h-2"
              />
              
              <div className="flex justify-between items-center">
                <Badge 
                  className={`${dailyStatus.color} bg-transparent border-current`}
                  variant="outline"
                >
                  {dailyStatus.status}
                </Badge>
                <span className="text-slate-400 text-sm">
                  {((currentDailyCost / dailyBudget) * 100).toFixed(1)}% used
                </span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-900 border-slate-700">
          <CardHeader className="pb-3">
            <CardTitle className="text-white flex items-center gap-2 text-lg">
              <Calendar className="w-5 h-5 text-blue-400" />
              Weekly Projection
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-end gap-2">
                <span className="text-3xl font-bold text-white">
                  ${weeklyProjection.toFixed(2)}
                </span>
                <span className="text-slate-400 text-sm">/ ${weeklyBudget.toFixed(2)}</span>
              </div>
              
              <div className="flex items-center gap-2">
                <WeeklyIcon className={`w-4 h-4 ${weeklyStatus.color}`} />
                <Badge 
                  className={`${weeklyStatus.color} bg-transparent border-current`}
                  variant="outline"
                >
                  {weeklyStatus.status}
                </Badge>
              </div>
              
              <p className="text-slate-400 text-sm">
                Based on current daily usage
              </p>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-900 border-slate-700">
          <CardHeader className="pb-3">
            <CardTitle className="text-white flex items-center gap-2 text-lg">
              <Brain className="w-5 h-5 text-purple-400" />
              Token Usage
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-end gap-2">
                <span className="text-3xl font-bold text-white">
                  {(apiStats.openai.tokensUsed / 1000).toFixed(1)}K
                </span>
                <span className="text-slate-400 text-sm">tokens today</span>
              </div>
              
              <Progress 
                value={(apiStats.openai.tokensUsed / apiStats.openai.dailyLimit) * 100} 
                className="h-2"
              />
              
              <div className="flex justify-between text-sm">
                <span className="text-slate-400">
                  {apiStats.openai.requests} requests
                </span>
                <span className="text-slate-400">
                  {((apiStats.openai.tokensUsed / apiStats.openai.dailyLimit) * 100).toFixed(1)}%
                </span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Bot-Specific Costs */}
      <Card className="bg-slate-900 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Zap className="w-5 h-5 text-yellow-400" />
            Bot Cost Breakdown
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {botCosts.map((bot) => (
              <div key={bot.botId} className="flex items-center justify-between p-4 bg-slate-800 rounded-lg">
                <div className="flex items-center gap-3">
                  <div className={`w-3 h-3 rounded-full ${
                    bot.platform === 'craigslist' ? 'bg-blue-400' :
                    bot.platform === 'api' ? 'bg-purple-400' :
                    bot.platform === 'email' ? 'bg-green-400' : 'bg-gray-400'
                  }`} />
                  <div>
                    <p className="text-white font-medium">{bot.botName}</p>
                    <p className="text-slate-400 text-sm">{bot.platform} • {bot.requests} requests</p>
                  </div>
                </div>
                
                <div className="text-right">
                  <p className="text-white font-bold">${bot.cost.toFixed(4)}</p>
                  <p className="text-slate-400 text-sm">{(bot.tokensUsed / 1000).toFixed(1)}K tokens</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* API Service Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="bg-slate-900 border-slate-700">
          <CardHeader className="pb-3">
            <CardTitle className="text-white flex items-center gap-2 text-lg">
              <Brain className="w-5 h-5 text-green-400" />
              OpenAI API
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-slate-400">Daily Usage:</span>
                <span className="text-white">{apiStats.openai.requests} requests</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Tokens:</span>
                <span className="text-white">{(apiStats.openai.tokensUsed / 1000).toFixed(1)}K</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Cost:</span>
                <span className="text-white">${apiStats.openai.cost.toFixed(4)}</span>
              </div>
              
              <Progress 
                value={(apiStats.openai.tokensUsed / apiStats.openai.dailyLimit) * 100} 
                className="h-2"
              />
              
              <p className="text-slate-400 text-xs">
                {((apiStats.openai.tokensUsed / apiStats.openai.dailyLimit) * 100).toFixed(1)}% of daily limit
              </p>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-900 border-slate-700">
          <CardHeader className="pb-3">
            <CardTitle className="text-white flex items-center gap-2 text-lg">
              <Database className="w-5 h-5 text-orange-400" />
              Airtable API
              {apiStats.airtable.estimated && (
                <Badge variant="outline" className="text-orange-400 border-orange-400/50 text-xs">
                  EST
                </Badge>
              )}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-slate-400">Requests:</span>
                <span className="text-white">{apiStats.airtable.requests}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Limit:</span>
                <span className="text-white">{apiStats.airtable.limit}/day</span>
              </div>
              
              <Progress 
                value={(apiStats.airtable.requests / apiStats.airtable.limit) * 100} 
                className="h-2"
              />
              
              <p className="text-slate-400 text-xs">
                {((apiStats.airtable.requests / apiStats.airtable.limit) * 100).toFixed(1)}% of daily limit
              </p>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-900 border-slate-700">
          <CardHeader className="pb-3">
            <CardTitle className="text-white flex items-center gap-2 text-lg">
              <Globe className="w-5 h-5 text-emerald-400" />
              Supabase
              {apiStats.supabase.estimated && (
                <Badge variant="outline" className="text-emerald-400 border-emerald-400/50 text-xs">
                  EST
                </Badge>
              )}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-slate-400">DB Requests:</span>
                <span className="text-white">{apiStats.supabase.requests}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Bandwidth:</span>
                <span className="text-white">{apiStats.supabase.bandwidth} MB</span>
              </div>
              
              <div className="flex items-center gap-2 mt-2">
                <div className="w-3 h-3 rounded-full bg-emerald-500" />
                <span className="text-emerald-400 text-sm">Within limits</span>
              </div>
              
              <p className="text-slate-400 text-xs">
                Free tier: 500MB/month
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Cost Alerts */}
      {currentDailyCost > dailyBudget * 0.8 && (
        <Card className="bg-amber-500/10 border-amber-500/20">
          <CardContent className="pt-6">
            <div className="flex items-start gap-3">
              <AlertTriangle className="w-5 h-5 text-amber-400 mt-0.5" />
              <div>
                <h4 className="text-amber-400 font-medium">High Usage Alert</h4>
                <p className="text-amber-300 text-sm mt-1">
                  You've used {((currentDailyCost / dailyBudget) * 100).toFixed(0)}% of your daily budget. 
                  Consider optimizing prompts or reducing request frequency.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}