import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';
import Editor from '@monaco-editor/react';
import {
  Play,
  Square,
  RotateCcw,
  Save,
  History,
  FileCode,
  FileJson,
  FileText,
  FolderTree,
  Settings,
  AlertTriangle,
  CheckCircle,
  Code2,
  Terminal
} from 'lucide-react';

interface BotFile {
  id: number;
  botId: number;
  fileName: string;
  filePath: string;
  content: string;
  fileType: 'js' | 'json' | 'env' | 'txt';
  isProtected: boolean;
  lastModified: string;
}

interface BotInstance {
  id: number;
  name: string;
  city: string;
  platform: string;
  vertical: string;
  status: 'running' | 'stopped' | 'paused' | 'error';
  type: string;
  version: string;
}

interface FileHistory {
  id: number;
  fileName: string;
  content: string;
  timestamp: string;
  version: number;
}

interface FunctionInfo {
  name: string;
  line: number;
  type: 'function' | 'class' | 'export';
}

interface LiveBotEditorProps {
  onClose?: () => void;
}

export function LiveBotEditor({ onClose }: LiveBotEditorProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // State management
  const [selectedBot, setSelectedBot] = useState<BotInstance | null>(null);
  const [selectedFile, setSelectedFile] = useState<BotFile | null>(null);
  const [editorContent, setEditorContent] = useState('');
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);
  const [functions, setFunctions] = useState<FunctionInfo[]>([]);
  const [activeTab, setActiveTab] = useState('editor');

  // Fetch bots
  const { data: bots = [], isLoading: botsLoading } = useQuery({
    queryKey: ['/api/bots'],
    queryFn: async () => {
      const response = await fetch('/api/bots', { credentials: 'include' });
      if (!response.ok) throw new Error('Failed to fetch bots');
      return response.json();
    }
  });

  // Fetch bot files
  const { data: files = [], isLoading: filesLoading } = useQuery({
    queryKey: ['/api/bot-files', selectedBot?.id],
    enabled: !!selectedBot,
    queryFn: async () => {
      const response = await fetch(`/api/bot-files/${selectedBot!.id}`, { credentials: 'include' });
      if (!response.ok) throw new Error('Failed to fetch bot files');
      return response.json();
    }
  });

  // Fetch file history
  const { data: fileHistory = [] } = useQuery({
    queryKey: ['/api/file-history', selectedFile?.id],
    enabled: !!selectedFile,
    queryFn: async () => {
      const response = await fetch(`/api/file-history/${selectedFile!.id}`, { credentials: 'include' });
      if (!response.ok) throw new Error('Failed to fetch file history');
      return response.json();
    }
  });

  // Bot control mutations
  const botCommandMutation = useMutation({
    mutationFn: async ({ bot, action }: { bot: string; action: 'start' | 'stop' | 'restart' }) => {
      const response = await fetch('/api/bot-command', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ bot, action })
      });
      if (!response.ok) throw new Error('Bot command failed');
      return response.json();
    },
    onSuccess: (data, variables) => {
      toast({
        title: "Bot Command Executed",
        description: `Successfully ${variables.action}ed ${variables.bot}`,
      });
      queryClient.invalidateQueries({ queryKey: ['/api/bots'] });
    },
    onError: () => {
      toast({
        title: "Command Failed",
        description: "Failed to execute bot command",
        variant: "destructive"
      });
    }
  });

  // Save file mutation
  const saveFileMutation = useMutation({
    mutationFn: async ({ fileId, content }: { fileId: number; content: string }) => {
      const response = await fetch(`/api/bot-files/${fileId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ content })
      });
      if (!response.ok) throw new Error('Failed to save file');
      return response.json();
    },
    onSuccess: () => {
      setHasUnsavedChanges(false);
      toast({
        title: "File Saved",
        description: `${selectedFile?.fileName} has been saved successfully`,
      });
      queryClient.invalidateQueries({ queryKey: ['/api/bot-files', selectedBot?.id] });
      queryClient.invalidateQueries({ queryKey: ['/api/file-history', selectedFile?.id] });
    },
    onError: () => {
      toast({
        title: "Save Failed",
        description: "Failed to save file changes",
        variant: "destructive"
      });
    }
  });

  // Rollback mutation
  const rollbackMutation = useMutation({
    mutationFn: async ({ fileId, historyId }: { fileId: number; historyId: number }) => {
      const response = await fetch(`/api/bot-files/${fileId}/rollback/${historyId}`, {
        method: 'POST',
        credentials: 'include'
      });
      if (!response.ok) throw new Error('Failed to rollback file');
      return response.json();
    },
    onSuccess: (data) => {
      setEditorContent(data.content);
      setHasUnsavedChanges(false);
      toast({
        title: "File Restored",
        description: "File has been restored to previous version",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/bot-files', selectedBot?.id] });
    }
  });

  // Function to parse JavaScript functions
  const parseJavaScriptFunctions = (content: string): FunctionInfo[] => {
    const functions: FunctionInfo[] = [];
    const lines = content.split('\n');
    
    lines.forEach((line, index) => {
      // Function declarations
      const funcMatch = line.match(/^\s*function\s+([a-zA-Z_$][a-zA-Z0-9_$]*)/);
      if (funcMatch) {
        functions.push({
          name: funcMatch[1],
          line: index + 1,
          type: 'function'
        });
      }
      
      // Arrow functions
      const arrowMatch = line.match(/^\s*(?:const|let|var)\s+([a-zA-Z_$][a-zA-Z0-9_$]*)\s*=\s*(?:async\s+)?\(/);
      if (arrowMatch) {
        functions.push({
          name: arrowMatch[1],
          line: index + 1,
          type: 'function'
        });
      }
      
      // Class declarations
      const classMatch = line.match(/^\s*class\s+([a-zA-Z_$][a-zA-Z0-9_$]*)/);
      if (classMatch) {
        functions.push({
          name: classMatch[1],
          line: index + 1,
          type: 'class'
        });
      }
      
      // Exports
      const exportMatch = line.match(/^\s*export\s+(?:function\s+)?([a-zA-Z_$][a-zA-Z0-9_$]*)/);
      if (exportMatch) {
        functions.push({
          name: exportMatch[1],
          line: index + 1,
          type: 'export'
        });
      }
    });
    
    return functions;
  };

  // Update functions when editor content changes
  useEffect(() => {
    if (selectedFile?.fileType === 'js' && editorContent) {
      const parsedFunctions = parseJavaScriptFunctions(editorContent);
      setFunctions(parsedFunctions);
    } else {
      setFunctions([]);
    }
  }, [editorContent, selectedFile]);

  // Handle file selection
  const handleFileSelect = (file: BotFile) => {
    if (hasUnsavedChanges) {
      if (!confirm('You have unsaved changes. Are you sure you want to switch files?')) {
        return;
      }
    }
    setSelectedFile(file);
    setEditorContent(file.content);
    setHasUnsavedChanges(false);
  };

  // Handle editor content change
  const handleEditorChange = (value: string | undefined) => {
    if (value !== undefined) {
      setEditorContent(value);
      setHasUnsavedChanges(value !== selectedFile?.content);
    }
  };

  // Get file icon
  const getFileIcon = (fileType: string) => {
    switch (fileType) {
      case 'js': return <FileCode className="w-4 h-4 text-yellow-400" />;
      case 'json': return <FileJson className="w-4 h-4 text-blue-400" />;
      case 'env': return <FileText className="w-4 h-4 text-green-400" />;
      default: return <FileText className="w-4 h-4 text-gray-400" />;
    }
  };

  // Get function icon
  const getFunctionIcon = (type: string) => {
    switch (type) {
      case 'function': return <Code2 className="w-3 h-3 text-blue-400" />;
      case 'class': return <Settings className="w-3 h-3 text-purple-400" />;
      case 'export': return <Terminal className="w-3 h-3 text-green-400" />;
      default: return <Code2 className="w-3 h-3 text-gray-400" />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 text-white">
      <div className="max-w-[1800px] mx-auto p-8">
        {/* Enhanced Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-gradient-to-r from-orange-500 to-red-500 rounded-xl shadow-lg">
              <Code2 className="w-8 h-8 text-white" />
            </div>
            <div>
              <h1 className="text-4xl font-bold bg-gradient-to-r from-white to-blue-100 bg-clip-text text-transparent">
                Live Bot Editor
              </h1>
              <p className="text-blue-200 mt-2 text-lg">Professional bot development environment</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Badge variant="secondary" className="bg-blue-500/20 text-blue-200 border-blue-400 px-4 py-2 text-sm">
              <Terminal className="h-4 w-4 mr-2" />
              Live Environment
            </Badge>
            {onClose && (
              <Button variant="outline" onClick={onClose} className="border-blue-400 text-blue-200 hover:bg-blue-500/20">
                Close Editor
              </Button>
            )}
          </div>
        </div>

        <div className="grid grid-cols-12 gap-8 h-[calc(100vh-200px)]">
          {/* Enhanced Left Sidebar */}
          <div className="col-span-4 space-y-6">
            {/* Bot Selection Card */}
            <Card className="bg-gradient-to-br from-slate-800/50 to-blue-800/20 border-blue-500/30 shadow-xl backdrop-blur-sm">
              <CardHeader className="pb-4">
                <CardTitle className="text-white flex items-center gap-3 text-lg">
                  <div className="p-2 bg-orange-500/20 rounded-lg">
                    <FolderTree className="w-5 h-5 text-orange-400" />
                  </div>
                  Select Bot Instance
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Select 
                  value={selectedBot?.id?.toString() || ''} 
                  onValueChange={(value) => {
                    const bot = bots.find((b: any) => b.id === parseInt(value));
                    setSelectedBot(bot || null);
                    setSelectedFile(null);
                    setEditorContent('');
                    setHasUnsavedChanges(false);
                  }}
                >
                  <SelectTrigger className="bg-slate-700/50 border-blue-400/50 text-white h-12 backdrop-blur-sm">
                    <SelectValue placeholder="Choose a bot to edit..." />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-800 border-blue-400/50">
                    {bots.map((bot: any) => (
                      <SelectItem key={bot.id} value={bot.id.toString()} className="text-white hover:bg-blue-500/20">
                        <div className="flex items-center gap-3 py-1">
                          <div className={`w-3 h-3 rounded-full shadow-lg ${
                            bot.status === 'running' ? 'bg-green-400 shadow-green-400/50' : 
                            bot.status === 'error' ? 'bg-red-400 shadow-red-400/50' : 'bg-yellow-400 shadow-yellow-400/50'
                          }`} />
                          <div className="flex flex-col">
                            <span className="font-medium">{bot.name}</span>
                            <span className="text-xs text-gray-400">{bot.city} • {bot.platform}</span>
                          </div>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </CardContent>
            </Card>

            {/* Enhanced File Browser */}
            {selectedBot && (
              <Card className="bg-gradient-to-br from-slate-800/50 to-blue-800/20 border-blue-500/30 shadow-xl backdrop-blur-sm flex-1">
                <CardHeader className="pb-4">
                  <CardTitle className="text-white flex items-center gap-3 text-lg">
                    <div className="p-2 bg-blue-500/20 rounded-lg">
                      <FileCode className="w-5 h-5 text-blue-400" />
                    </div>
                    Bot Files
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-[350px]">
                    <div className="space-y-2">
                      {files.map((file: BotFile) => (
                        <Button
                          key={file.id}
                          variant={selectedFile?.id === file.id ? "secondary" : "ghost"}
                          className={`w-full justify-start p-4 h-auto rounded-lg transition-all ${
                            selectedFile?.id === file.id 
                              ? "bg-blue-500/30 border border-blue-400/50 shadow-lg" 
                              : "hover:bg-slate-700/50 hover:border-blue-400/30 border border-transparent"
                          }`}
                          onClick={() => handleFileSelect(file)}
                        >
                          <div className="flex items-center gap-3 w-full">
                            {getFileIcon(file.fileType)}
                            <div className="flex-1 text-left">
                              <div className="text-sm font-medium text-white">{file.fileName}</div>
                              <div className="flex items-center gap-2 mt-1">
                                {file.isProtected && (
                                  <Badge variant="outline" className="text-xs bg-red-500/20 text-red-300 border-red-400/50">
                                    Protected
                                  </Badge>
                                )}
                                <span className="text-xs text-slate-400">
                                  {new Date(file.lastModified).toLocaleDateString()}
                                </span>
                              </div>
                            </div>
                            {hasUnsavedChanges && selectedFile?.id === file.id && (
                              <div className="w-2 h-2 bg-orange-400 rounded-full"></div>
                            )}
                          </div>
                        </Button>
                      ))}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>
            )}

            {/* Function Scanner */}
            {selectedFile?.fileType === 'js' && functions.length > 0 && (
              <Card className="bg-slate-900 border-slate-700">
                <CardHeader className="pb-3">
                  <CardTitle className="text-white text-sm">Functions</CardTitle>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-[200px]">
                    <div className="space-y-1">
                      {functions.map((func, index) => (
                        <div
                          key={index}
                          className="flex items-center gap-2 p-1 rounded hover:bg-slate-800 cursor-pointer text-sm"
                          onClick={() => {
                            // Could implement jumping to line here
                          }}
                        >
                          {getFunctionIcon(func.type)}
                          <span className="flex-1">{func.name}</span>
                          <span className="text-xs text-slate-400">:{func.line}</span>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Enhanced Main Editor Area */}
          <div className="col-span-8">
            <Tabs value={activeTab} onValueChange={setActiveTab} className="h-full">
              <TabsList className="grid w-full grid-cols-3 bg-gradient-to-r from-slate-800/50 to-blue-800/20 border border-blue-500/30 backdrop-blur-sm">
                <TabsTrigger 
                  value="editor" 
                  className="data-[state=active]:bg-blue-500/30 data-[state=active]:text-white data-[state=active]:shadow-lg text-blue-200"
                >
                  <Code2 className="w-4 h-4 mr-2" />
                  Code Editor
                </TabsTrigger>
                <TabsTrigger 
                  value="controls" 
                  className="data-[state=active]:bg-blue-500/30 data-[state=active]:text-white data-[state=active]:shadow-lg text-blue-200"
                >
                  <Play className="w-4 h-4 mr-2" />
                  Bot Controls
                </TabsTrigger>
                <TabsTrigger 
                  value="history" 
                  className="data-[state=active]:bg-blue-500/30 data-[state=active]:text-white data-[state=active]:shadow-lg text-blue-200"
                >
                  <History className="w-4 h-4 mr-2" />
                  Version History
                </TabsTrigger>
              </TabsList>

              {/* Enhanced Editor Tab */}
              <TabsContent value="editor" className="mt-6 h-[calc(100%-80px)]">
                <Card className="bg-gradient-to-br from-slate-800/50 to-blue-800/20 border-blue-500/30 shadow-xl backdrop-blur-sm h-full">
                  <CardHeader className="pb-4 border-b border-blue-500/20">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-white flex items-center gap-3 text-xl">
                        <div className="p-2 bg-blue-500/20 rounded-lg">
                          <FileCode className="w-6 h-6 text-blue-400" />
                        </div>
                        {selectedFile ? selectedFile.fileName : 'Select a file to edit'}
                        {hasUnsavedChanges && (
                          <Badge variant="outline" className="bg-orange-500/20 text-orange-300 border-orange-400/50 px-3 py-1">
                            • Unsaved Changes
                          </Badge>
                        )}
                      </CardTitle>
                      {selectedFile && (
                        <div className="flex items-center gap-3">
                          {selectedFile.isProtected && (
                            <Badge variant="outline" className="bg-yellow-500/20 text-yellow-300 border-yellow-400/50 px-3 py-1">
                              <AlertTriangle className="w-3 h-3 mr-1" />
                              Protected File
                            </Badge>
                          )}
                          <Button 
                            size="lg" 
                            className="bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white shadow-lg px-6"
                            onClick={() => selectedFile && saveFileMutation.mutate({ 
                              fileId: selectedFile.id, 
                              content: editorContent 
                            })}
                            disabled={!hasUnsavedChanges || saveFileMutation.isPending}
                          >
                            <Save className="w-4 h-4 mr-2" />
                            {saveFileMutation.isPending ? 'Saving...' : 'Save File'}
                          </Button>
                        </div>
                      )}
                    </div>
                  </CardHeader>
                  <CardContent className="h-[calc(100%-100px)] p-6">
                    {selectedFile ? (
                      <div className="h-full border-2 border-blue-500/30 rounded-xl overflow-hidden shadow-2xl bg-slate-900/50">
                        <Editor
                          height="100%"
                          defaultLanguage={selectedFile.fileType === 'js' ? 'javascript' : 'json'}
                          value={editorContent}
                          onChange={handleEditorChange}
                          theme="vs-dark"
                          options={{
                            minimap: { enabled: true },
                            fontSize: 16,
                            lineNumbers: 'on',
                            scrollBeyondLastLine: false,
                            automaticLayout: true,
                            readOnly: selectedFile.isProtected,
                            wordWrap: 'on',
                            fontFamily: 'Fira Code, Monaco, "Cascadia Code", "Roboto Mono", Consolas, "Courier New", monospace',
                            fontLigatures: true,
                            cursorStyle: 'line',
                            cursorBlinking: 'smooth',
                            renderLineHighlight: 'all',
                            selectOnLineNumbers: true,
                            roundedSelection: false,
                            scrollbar: {
                              vertical: 'auto',
                              horizontal: 'auto',
                              verticalScrollbarSize: 14,
                              horizontalScrollbarSize: 14
                            }
                          }}
                        />
                      </div>
                    ) : (
                      <div className="h-full flex items-center justify-center text-slate-400 bg-slate-900/30 rounded-xl border-2 border-dashed border-blue-500/30">
                        <div className="text-center">
                          <div className="p-4 bg-blue-500/10 rounded-full mb-6 mx-auto w-fit">
                            <FileCode className="w-16 h-16 text-blue-400" />
                          </div>
                          <h3 className="text-xl font-medium mb-3 text-white">No File Selected</h3>
                          <p>Choose a bot and file to start editing</p>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Bot Controls Tab */}
              <TabsContent value="controls" className="mt-4">
                <Card className="bg-slate-900 border-slate-700">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                      <Terminal className="w-5 h-5 text-green-400" />
                      Bot Controls
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {selectedBot ? (
                      <div className="space-y-4">
                        <div className="flex items-center gap-3 p-4 bg-slate-800 rounded-lg">
                          <div className={`w-4 h-4 rounded-full ${
                            selectedBot.status === 'running' ? 'bg-green-400' : 
                            selectedBot.status === 'error' ? 'bg-red-400' : 'bg-yellow-400'
                          }`} />
                          <div className="flex-1">
                            <h3 className="font-medium">{selectedBot.name}</h3>
                            <p className="text-sm text-slate-400">
                              {selectedBot.city} • {selectedBot.platform} • {selectedBot.vertical}
                            </p>
                          </div>
                          <Badge variant="outline" className="capitalize">
                            {selectedBot.status}
                          </Badge>
                        </div>

                        <div className="grid grid-cols-3 gap-3">
                          <Button 
                            className="bg-green-600 hover:bg-green-700"
                            onClick={() => botCommandMutation.mutate({ 
                              bot: selectedBot.name, 
                              action: 'start' 
                            })}
                            disabled={botCommandMutation.isPending || selectedBot.status === 'running'}
                          >
                            <Play className="w-4 h-4 mr-1" />
                            Start Bot
                          </Button>
                          
                          <Button 
                            variant="destructive"
                            onClick={() => botCommandMutation.mutate({ 
                              bot: selectedBot.name, 
                              action: 'stop' 
                            })}
                            disabled={botCommandMutation.isPending || selectedBot.status === 'stopped'}
                          >
                            <Square className="w-4 h-4 mr-1" />
                            Stop Bot
                          </Button>
                          
                          <Button 
                            variant="outline"
                            onClick={() => botCommandMutation.mutate({ 
                              bot: selectedBot.name, 
                              action: 'restart' 
                            })}
                            disabled={botCommandMutation.isPending}
                          >
                            <RotateCcw className="w-4 h-4 mr-1" />
                            Restart
                          </Button>
                        </div>

                        {botCommandMutation.isPending && (
                          <Alert className="border-blue-200 bg-blue-50/10">
                            <Terminal className="w-4 h-4" />
                            <AlertDescription>
                              Executing command... This may take a few seconds.
                            </AlertDescription>
                          </Alert>
                        )}
                      </div>
                    ) : (
                      <div className="text-center py-8 text-slate-400">
                        Select a bot to show controls
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Version History Tab */}
              <TabsContent value="history" className="mt-4">
                <Card className="bg-slate-900 border-slate-700">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                      <History className="w-5 h-5 text-purple-400" />
                      Version History
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {selectedFile ? (
                      <ScrollArea className="h-[400px]">
                        <div className="space-y-3">
                          {fileHistory.map((history: FileHistory) => (
                            <div key={history.id} className="flex items-center justify-between p-3 bg-slate-800 rounded-lg">
                              <div>
                                <div className="font-medium">Version {history.version}</div>
                                <div className="text-sm text-slate-400">
                                  {new Date(history.timestamp).toLocaleString()}
                                </div>
                              </div>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => rollbackMutation.mutate({
                                  fileId: selectedFile.id,
                                  historyId: history.id
                                })}
                                disabled={rollbackMutation.isPending}
                              >
                                <RotateCcw className="w-3 h-3 mr-1" />
                                Restore
                              </Button>
                            </div>
                          ))}
                          {fileHistory.length === 0 && (
                            <div className="text-center py-8 text-slate-400">
                              No version history available
                            </div>
                          )}
                        </div>
                      </ScrollArea>
                    ) : (
                      <div className="text-center py-8 text-slate-400">
                        Select a file to view version history
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </div>
  );
}