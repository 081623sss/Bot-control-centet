import { useToast } from '@/hooks/use-toast'

interface BotCommandResponse {
  success: boolean
  message: string
  result?: any
  error?: string
}

export const useBotCommands = () => {
  const { toast } = useToast()

  const sendBotCommand = async (
    command: string, 
    botName?: string, 
    payload?: any
  ): Promise<BotCommandResponse> => {
    try {
      const response = await fetch('/api/ngrok/bot-command', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify({
          command,
          botName,
          payload
        })
      })

      const data = await response.json()

      if (data.success) {
        toast({
          title: "Command Executed",
          description: `${command} completed successfully for ${botName || 'system'}`,
        })
        return data
      } else {
        toast({
          title: "Command Failed",
          description: data.message || `Failed to execute ${command}`,
          variant: "destructive"
        })
        return data
      }
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Network error'
      toast({
        title: "Connection Error",
        description: "Failed to communicate with bot server",
        variant: "destructive"
      })
      return {
        success: false,
        message: errorMessage,
        error: errorMessage
      }
    }
  }

  const startBot = async (botName: string) => {
    return sendBotCommand('start', botName)
  }

  const stopBot = async (botName: string) => {
    return sendBotCommand('stop', botName)
  }

  const restartBot = async (botName: string) => {
    return sendBotCommand('restart', botName)
  }

  const rollbackBot = async (botName: string, version?: string) => {
    return sendBotCommand('rollback', botName, { version })
  }

  const snapshotBot = async (botName: string, description?: string) => {
    return sendBotCommand('snapshot', botName, { description })
  }

  const getBotStatus = async (botName: string) => {
    return sendBotCommand('status', botName)
  }

  const getBotLogs = async (botName: string, lines = 50) => {
    return sendBotCommand('logs', botName, { lines })
  }

  const systemCommand = async (command: string, payload?: any) => {
    return sendBotCommand(command, undefined, payload)
  }

  return {
    sendBotCommand,
    startBot,
    stopBot,
    restartBot,
    rollbackBot,
    snapshotBot,
    getBotStatus,
    getBotLogs,
    systemCommand
  }
}