import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { PlayCircle, PauseCircle, StopCircle, Download } from "lucide-react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { BotInstance } from "@shared/schema";

interface QuickActionsProps {
  bots: BotInstance[];
  onRefresh: () => void;
  onLogRefresh: () => void;
}

export default function QuickActions({ bots, onRefresh, onLogRefresh }: QuickActionsProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const bulkActionMutation = useMutation({
    mutationFn: async (action: string) => {
      return apiRequest("POST", `/api/bots/bulk/${action}`, {});
    },
    onSuccess: (_, action) => {
      queryClient.invalidateQueries({ queryKey: ["/api/bots"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      queryClient.invalidateQueries({ queryKey: ["/api/logs"] });
      onRefresh();
      onLogRefresh();
      toast({
        title: "Success",
        description: `Bulk ${action} operation completed`,
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to perform bulk operation",
        variant: "destructive",
      });
    },
  });

  const handleBulkAction = (action: string) => {
    bulkActionMutation.mutate(action);
  };

  const handleExportData = () => {
    const data = {
      bots,
      exportedAt: new Date().toISOString(),
    };
    
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `bot-data-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    toast({
      title: "Success",
      description: "Bot data exported successfully",
    });
  };

  const actions = [
    {
      title: "Start All",
      icon: PlayCircle,
      color: "bg-emerald-600 hover:bg-emerald-700",
      action: () => handleBulkAction("start"),
    },
    {
      title: "Pause All",
      icon: PauseCircle,
      color: "bg-amber-600 hover:bg-amber-700",
      action: () => handleBulkAction("pause"),
    },
    {
      title: "Stop All",
      icon: StopCircle,
      color: "bg-red-600 hover:bg-red-700",
      action: () => handleBulkAction("stop"),
    },
    {
      title: "Export Data",
      icon: Download,
      color: "bg-blue-600 hover:bg-blue-700",
      action: handleExportData,
    },
  ];

  return (
    <Card className="bg-slate-900 border-slate-700">
      <CardHeader>
        <CardTitle className="text-lg font-semibold text-white">Quick Actions</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {actions.map((action, index) => (
            <Button
              key={index}
              onClick={action.action}
              disabled={bulkActionMutation.isPending}
              className={`${action.color} p-3 h-auto flex-col space-y-2`}
            >
              <action.icon className="w-6 h-6" />
              <span className="text-sm font-medium">{action.title}</span>
            </Button>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
