import { useState } from "react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { MapPin, Play } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

// Florida cities for Super Smart Stealz operations
const FLORIDA_CITIES = [
  "Miami",
  "Tampa", 
  "Orlando",
  "Jacksonville",
  "St. Petersburg",
  "Hialeah",
  "Tallahassee",
  "Fort Lauderdale",
  "Port St. Lucie",
  "Cape Coral",
  "Pembroke Pines",
  "Hollywood",
  "Miramar",
  "Gainesville",
  "Coral Springs",
  "Clearwater",
  "Palm Bay",
  "Pompano Beach",
  "West Palm Beach",
  "Lakeland"
]

export function CitySelector() {
  const [selectedCity, setSelectedCity] = useState("")
  const [customCity, setCustomCity] = useState("")
  const [isStarting, setIsStarting] = useState(false)
  const { toast } = useToast()

  const handleStartScraper = async () => {
    const city = selectedCity || customCity
    if (!city) {
      toast({
        title: "City Required",
        description: "Please select or enter a city to start scraping",
        variant: "destructive"
      })
      return
    }

    setIsStarting(true)
    try {
      const response = await fetch("/api/start-scraper", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ city, platform: "craigslist" })
      })

      if (response.ok) {
        toast({
          title: "Scraper Started",
          description: `Bot started for ${city} on Craigslist`,
        })
      } else {
        throw new Error("Failed to start scraper")
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to start scraper bot",
        variant: "destructive"
      })
    } finally {
      setIsStarting(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <MapPin className="h-5 w-5" />
          City Target Selection
        </CardTitle>
        <CardDescription>
          Choose a city to start lead scraping bots for Super Smart Stealz
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="text-sm font-medium mb-2 block">
              Select City
            </label>
            <Select value={selectedCity} onValueChange={setSelectedCity}>
              <SelectTrigger>
                <SelectValue placeholder="Choose a Florida city..." />
              </SelectTrigger>
              <SelectContent>
                {FLORIDA_CITIES.map(city => (
                  <SelectItem key={city} value={city}>{city}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div>
            <label className="text-sm font-medium mb-2 block">
              Or Enter Custom City
            </label>
            <Input
              value={customCity}
              onChange={(e) => {
                setCustomCity(e.target.value)
                if (e.target.value) setSelectedCity("")
              }}
              placeholder="Enter any city..."
            />
          </div>
        </div>

        <div className="flex justify-between items-center pt-4 border-t">
          <div className="text-sm text-muted-foreground">
            Target: {selectedCity || customCity || "No city selected"}
          </div>
          <Button 
            onClick={handleStartScraper}
            disabled={!selectedCity && !customCity || isStarting}
            className="flex items-center gap-2"
          >
            <Play className="h-4 w-4" />
            {isStarting ? "Starting..." : "Start Scraper"}
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}