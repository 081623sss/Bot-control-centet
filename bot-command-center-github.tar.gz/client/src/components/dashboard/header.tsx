import { Bot, LogOut, Shield, Settings } from "lucide-react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

export default function Header() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const handleLogout = async () => {
    try {
      const response = await fetch('/api/auth/logout', {
        method: 'POST',
        credentials: 'include'
      });

      const data = await response.json();
      
      if (data.success) {
        toast({
          title: "Logged Out",
          description: "You have been securely logged out.",
        });
        setLocation('/');
      } else {
        toast({
          title: "Logout Error",
          description: data.message || "Failed to logout properly.",
          variant: "destructive"
        });
      }
    } catch (error) {
      toast({
        title: "Network Error",
        description: "Failed to logout. Please try again.",
        variant: "destructive"
      });
    }
  };

  return (
    <header className="bg-slate-900 border-b border-slate-700 px-6 py-4">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="bg-blue-600 p-2 rounded-lg">
            <Bot className="text-white w-6 h-6" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white">Bot Command Center</h1>
            <p className="text-slate-400 text-sm">Manage and monitor your automation bots</p>
          </div>
        </div>
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse-slow"></div>
            <span className="text-emerald-500 text-sm font-medium">Connected</span>
          </div>
          
          <div className="flex items-center gap-2 px-3 py-1.5 bg-slate-800 border border-slate-700 rounded-full">
            <Shield className="w-4 h-4 text-blue-400" />
            <span className="text-slate-300 text-sm">2FA Secured</span>
          </div>

          <Button
            variant="ghost"
            size="sm"
            onClick={() => setLocation('/security')}
            className="text-slate-400 hover:text-blue-400 hover:bg-blue-400/10"
          >
            <Settings className="w-4 h-4 mr-2" />
            Security
          </Button>

          <Button
            variant="ghost"
            size="sm"
            onClick={handleLogout}
            className="text-slate-400 hover:text-red-400 hover:bg-red-400/10"
          >
            <LogOut className="w-4 h-4 mr-2" />
            Logout
          </Button>
        </div>
      </div>
    </header>
  );
}
