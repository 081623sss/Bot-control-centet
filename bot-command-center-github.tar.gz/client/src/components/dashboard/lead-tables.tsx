import { useState, useEffect } from "react"
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { RefreshCw, Filter, Edit2, Save, X, ChevronLeft, ChevronRight, Database } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { apiRequest } from "@/lib/queryClient"

interface LeadTableData {
  tableName: string
  displayName: string
  description: string
  fields: string[]
  editableFields: string[]
}

const tableConfig: LeadTableData[] = [
  {
    tableName: "raw_leads",
    displayName: "Raw Leads",
    description: "Scraped leads before GPT enrichment",
    fields: ["id", "title", "description", "city", "gptStatus", "contactName", "contactEmail", "contactPhone", "leadSource", "createdAt"],
    editableFields: ["contactName", "contactEmail", "contactPhone", "gptStatus"]
  },
  {
    tableName: "auto_leads",
    displayName: "Auto",
    description: "Automotive leads from buyers",
    fields: ["id", "make", "model", "year", "budget", "contactName", "contactPhone", "urgency", "status", "createdAt"],
    editableFields: ["contactName", "contactPhone", "urgency", "status"]
  },
  {
    tableName: "goods_leads", 
    displayName: "Goods",
    description: "General merchandise buying leads",
    fields: ["id", "productType", "quantity", "buyerBudget", "contactInfo", "urgency", "leadStatus", "createdAt"],
    editableFields: ["contactInfo", "urgency", "leadStatus"]
  },
  {
    tableName: "real_estate_leads",
    displayName: "Real Estate", 
    description: "Property investment leads",
    fields: ["id", "propertyType", "zipCode", "bedrooms", "urgency", "contactEmail", "contactPhone", "status", "createdAt"],
    editableFields: ["contactEmail", "contactPhone", "urgency", "status"]
  },
  {
    tableName: "hot_leads",
    displayName: "Hot Leads",
    description: "Qualified leads ready for action",
    fields: ["id", "leadTitle", "buyerName", "vertical", "buyerBudget", "currentPrice", "potentialProfit", "status", "aorUrl", "createdAt"],
    editableFields: ["status"]
  },
  {
    tableName: "users",
    displayName: "Users",
    description: "Platform users (Admins and VAs)",
    fields: ["id", "email", "role", "name", "company", "isActive", "lastLogin", "activeSession", "createdAt"],
    editableFields: ["name", "company", "isActive"]
  },
  {
    tableName: "sessions",
    displayName: "Sessions",
    description: "Login sessions and security audit",
    fields: ["id", "userId", "timestamp", "ipAddress", "action", "createdAt"],
    editableFields: []
  }
]

interface EditingCell {
  rowId: string | number
  field: string
  value: string
}

export function LeadTables() {
  const [selectedTable, setSelectedTable] = useState("auto_leads")
  const [currentPage, setCurrentPage] = useState(1)
  const [filterStatus, setFilterStatus] = useState("all")
  const [filterCity, setFilterCity] = useState("")
  const [searchTerm, setSearchTerm] = useState("")
  const [editingCell, setEditingCell] = useState<EditingCell | null>(null)
  const [isRoleRestricted, setIsRoleRestricted] = useState(false)
  
  const { toast } = useToast()
  const queryClient = useQueryClient()
  
  const currentTableConfig = tableConfig.find(t => t.tableName === selectedTable)
  const itemsPerPage = 25

  // Check user role for restrictions
  const { data: authStatus } = useQuery({
    queryKey: ["/api/auth/status"],
    staleTime: 5 * 60 * 1000
  })

  useEffect(() => {
    if (authStatus?.user?.role === "virtual_assistant") {
      setIsRoleRestricted(true)
    }
  }, [authStatus])

  // Fetch table data
  const { data: tableData, isLoading, refetch } = useQuery({
    queryKey: ["/api/lead-tables", selectedTable, currentPage, filterStatus, filterCity, searchTerm],
    enabled: !!selectedTable,
    staleTime: 30 * 1000,
    refetchInterval: 60 * 1000
  })

  // Update cell mutation
  const updateCellMutation = useMutation({
    mutationFn: async ({ tableName, rowId, field, value }: {
      tableName: string
      rowId: string | number
      field: string
      value: string
    }) => {
      return await apiRequest(`/api/lead-tables/${tableName}/${rowId}`, {
        method: "PATCH",
        body: JSON.stringify({ [field]: value })
      })
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/lead-tables", selectedTable] })
      setEditingCell(null)
      toast({
        title: "Success",
        description: "Record updated successfully"
      })
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update record",
        variant: "destructive"
      })
    }
  })

  const handleCellEdit = (rowId: string | number, field: string, currentValue: string) => {
    if (isRoleRestricted && !currentTableConfig?.editableFields.includes(field)) {
      toast({
        title: "Access Restricted",
        description: "You can only edit contact fields",
        variant: "destructive"
      })
      return
    }
    
    setEditingCell({ rowId, field, value: currentValue || "" })
  }

  const handleCellSave = () => {
    if (!editingCell || !currentTableConfig) return
    
    updateCellMutation.mutate({
      tableName: selectedTable,
      rowId: editingCell.rowId,
      field: editingCell.field,
      value: editingCell.value
    })
  }

  const handleCellCancel = () => {
    setEditingCell(null)
  }

  const applyFilters = () => {
    setCurrentPage(1)
    refetch()
  }

  const clearFilters = () => {
    setFilterStatus("all")
    setFilterCity("")
    setSearchTerm("")
    setCurrentPage(1)
    refetch()
  }

  const formatCellValue = (value: any, field: string) => {
    if (value === null || value === undefined) return "-"
    
    if (field.includes("created_at") || field.includes("updated_at") || field.includes("expires_at")) {
      return new Date(value).toLocaleString()
    }
    
    if (field === "status") {
      const statusColors: Record<string, string> = {
        "new": "bg-blue-100 text-blue-800",
        "contacted": "bg-yellow-100 text-yellow-800", 
        "qualified": "bg-green-100 text-green-800",
        "closed": "bg-gray-100 text-gray-800",
        "active": "bg-green-100 text-green-800",
        "inactive": "bg-red-100 text-red-800"
      }
      
      return (
        <Badge className={statusColors[value] || "bg-gray-100 text-gray-800"}>
          {value}
        </Badge>
      )
    }
    
    if (typeof value === "string" && value.length > 50) {
      return value.substring(0, 50) + "..."
    }
    
    return String(value)
  }

  const isFieldEditable = (field: string) => {
    if (isRoleRestricted) {
      return ["contact_name", "contact_email", "contact_phone", "status"].includes(field)
    }
    return currentTableConfig?.editableFields.includes(field) || false
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Database className="h-5 w-5" />
            Lead Tables Management
          </CardTitle>
          <CardDescription>
            View and manage live data from Supabase database tables
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs value={selectedTable} onValueChange={setSelectedTable}>
            <TabsList className="grid grid-cols-4 lg:grid-cols-7 mb-6">
              {tableConfig.map((table) => (
                <TabsTrigger 
                  key={table.tableName} 
                  value={table.tableName}
                  className="text-xs"
                >
                  {table.displayName}
                </TabsTrigger>
              ))}
            </TabsList>

            {tableConfig.map((table) => (
              <TabsContent key={table.tableName} value={table.tableName}>
                <div className="space-y-4">
                  {/* Table Info */}
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-lg font-semibold">{table.displayName}</h3>
                      <p className="text-sm text-muted-foreground">{table.description}</p>
                    </div>
                    <Button 
                      onClick={() => refetch()} 
                      variant="outline" 
                      size="sm"
                      disabled={isLoading}
                    >
                      <RefreshCw className={`h-4 w-4 mr-2 ${isLoading ? "animate-spin" : ""}`} />
                      Refresh
                    </Button>
                  </div>

                  {/* Filters */}
                  <div className="flex flex-wrap gap-4 p-4 bg-muted/50 rounded-lg">
                    <div className="flex-1 min-w-[200px]">
                      <Input
                        placeholder="Search..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                      />
                    </div>
                    
                    {table.fields.includes("status") && (
                      <Select value={filterStatus} onValueChange={setFilterStatus}>
                        <SelectTrigger className="w-[150px]">
                          <SelectValue placeholder="Filter Status" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">All Statuses</SelectItem>
                          <SelectItem value="new">New</SelectItem>
                          <SelectItem value="contacted">Contacted</SelectItem>
                          <SelectItem value="qualified">Qualified</SelectItem>
                          <SelectItem value="closed">Closed</SelectItem>
                          <SelectItem value="active">Active</SelectItem>
                          <SelectItem value="inactive">Inactive</SelectItem>
                        </SelectContent>
                      </Select>
                    )}
                    
                    {table.fields.includes("city") && (
                      <Input
                        placeholder="Filter by City"
                        value={filterCity}
                        onChange={(e) => setFilterCity(e.target.value)}
                        className="w-[150px]"
                      />
                    )}
                    
                    <Button onClick={applyFilters} size="sm">
                      <Filter className="h-4 w-4 mr-2" />
                      Apply
                    </Button>
                    
                    <Button onClick={clearFilters} variant="outline" size="sm">
                      Clear
                    </Button>
                  </div>

                  {/* Data Table */}
                  <div className="border rounded-lg overflow-hidden">
                    <div className="overflow-x-auto max-h-[600px]">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            {table.fields.map((field) => (
                              <TableHead key={field} className="whitespace-nowrap">
                                {field.replace(/_/g, " ").replace(/\b\w/g, l => l.toUpperCase())}
                              </TableHead>
                            ))}
                            {!isRoleRestricted && <TableHead>Actions</TableHead>}
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {isLoading ? (
                            <TableRow>
                              <TableCell colSpan={table.fields.length + 1} className="text-center py-8">
                                <div className="flex items-center justify-center">
                                  <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                                  Loading data...
                                </div>
                              </TableCell>
                            </TableRow>
                          ) : tableData?.data?.length > 0 ? (
                            tableData.data.map((row: any, index: number) => (
                              <TableRow key={row.id || index}>
                                {table.fields.map((field) => (
                                  <TableCell key={field} className="max-w-[200px]">
                                    {editingCell?.rowId === row.id && editingCell?.field === field ? (
                                      <div className="flex items-center gap-2">
                                        <Input
                                          value={editingCell.value}
                                          onChange={(e) => setEditingCell({
                                            ...editingCell,
                                            value: e.target.value
                                          })}
                                          className="h-8"
                                          autoFocus
                                        />
                                        <Button
                                          size="sm"
                                          onClick={handleCellSave}
                                          disabled={updateCellMutation.isPending}
                                        >
                                          <Save className="h-3 w-3" />
                                        </Button>
                                        <Button
                                          size="sm"
                                          variant="outline"
                                          onClick={handleCellCancel}
                                        >
                                          <X className="h-3 w-3" />
                                        </Button>
                                      </div>
                                    ) : (
                                      <div 
                                        className={`cursor-pointer hover:bg-muted/50 p-1 rounded ${
                                          isFieldEditable(field) ? "border-dashed border-transparent hover:border-muted-foreground/50" : ""
                                        }`}
                                        onClick={() => isFieldEditable(field) && handleCellEdit(row.id, field, row[field])}
                                      >
                                        {formatCellValue(row[field], field)}
                                        {isFieldEditable(field) && (
                                          <Edit2 className="h-3 w-3 ml-1 inline opacity-50" />
                                        )}
                                      </div>
                                    )}
                                  </TableCell>
                                ))}
                                {!isRoleRestricted && (
                                  <TableCell>
                                    <Button variant="ghost" size="sm">
                                      <Edit2 className="h-4 w-4" />
                                    </Button>
                                  </TableCell>
                                )}
                              </TableRow>
                            ))
                          ) : (
                            <TableRow>
                              <TableCell colSpan={table.fields.length + 1} className="text-center py-8 text-muted-foreground">
                                No data found
                              </TableCell>
                            </TableRow>
                          )}
                        </TableBody>
                      </Table>
                    </div>
                  </div>

                  {/* Pagination */}
                  {tableData?.totalPages > 1 && (
                    <div className="flex items-center justify-between">
                      <div className="text-sm text-muted-foreground">
                        Showing {((currentPage - 1) * itemsPerPage) + 1} to {Math.min(currentPage * itemsPerPage, tableData?.totalCount || 0)} of {tableData?.totalCount || 0} results
                      </div>
                      <div className="flex items-center gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
                          disabled={currentPage === 1}
                        >
                          <ChevronLeft className="h-4 w-4" />
                          Previous
                        </Button>
                        <span className="text-sm">
                          Page {currentPage} of {tableData?.totalPages || 1}
                        </span>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setCurrentPage(prev => Math.min(tableData?.totalPages || 1, prev + 1))}
                          disabled={currentPage >= (tableData?.totalPages || 1)}
                        >
                          Next
                          <ChevronRight className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  )}
                </div>
              </TabsContent>
            ))}
          </Tabs>
        </CardContent>
      </Card>
    </div>
  )
}