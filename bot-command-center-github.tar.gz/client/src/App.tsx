import { useState, useEffect } from 'react';
import { QueryClient, QueryClientProvider, useQuery } from '@tanstack/react-query';
import { LoginPage } from './pages/login';
import CleanDashboard from './components/dashboard/clean-dashboard';
import { Card, CardContent } from '@/components/ui/card';
import { Loader2, Bot } from 'lucide-react';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      refetchOnWindowFocus: false,
      staleTime: 5 * 60 * 1000, // 5 minutes
    },
  },
});

interface User {
  id: number;
  email: string;
  name: string;
  role: string;
}

function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isInitializing, setIsInitializing] = useState(true);

  // Check authentication status
  const { data: authStatus, isLoading, error } = useQuery({
    queryKey: ['/api/auth/status'],
    queryFn: async () => {
      const response = await fetch('/api/auth/status', {
        credentials: 'include'
      });
      if (!response.ok && response.status !== 401) {
        throw new Error('Failed to check authentication status');
      }
      return response.json();
    },
    retry: false
  });

  useEffect(() => {
    if (!isLoading) {
      if (authStatus?.authenticated && authStatus?.user) {
        setUser(authStatus.user);
      } else {
        setUser(null);
      }
      setIsInitializing(false);
    }
  }, [authStatus, isLoading]);

  const handleLoginSuccess = (userData: User) => {
    setUser(userData);
    queryClient.invalidateQueries({ queryKey: ['/api/auth/status'] });
  };

  const handleLogout = () => {
    setUser(null);
    queryClient.clear();
  };

  if (isInitializing || isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-gray-900">
        <Card className="w-full max-w-md">
          <CardContent className="flex flex-col items-center justify-center p-8">
            <Bot className="h-12 w-12 text-blue-600 mb-4" />
            <Loader2 className="h-8 w-8 animate-spin text-blue-600 mb-4" />
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
              Super Smart Stealz
            </h2>
            <p className="text-gray-600 dark:text-gray-400 text-center">
              Initializing Bot Command Center...
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!user) {
    return <LoginPage onLoginSuccess={handleLoginSuccess} />;
  }

  return <CleanDashboard />;
}

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <div />
      </AuthProvider>
    </QueryClientProvider>
  );
}