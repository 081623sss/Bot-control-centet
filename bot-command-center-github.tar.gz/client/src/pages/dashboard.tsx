import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Progress } from '@/components/ui/progress';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  Play, 
  Square, 
  RotateCcw, 
  Settings, 
  Activity, 
  TrendingUp, 
  Users, 
  DollarSign, 
  Bot,
  Shield,
  LogOut,
  Plus,
  Trash2,
  Edit3,
  Database,
  Clock,
  AlertCircle,
  CheckCircle,
  XCircle
} from 'lucide-react';
import { apiRequest } from '@/lib/queryClient';
import CleanDashboard from '@/components/dashboard/clean-dashboard';

interface User {
  id: number;
  email: string;
  name: string;
  role: string;
}

interface BotInstance {
  id: number;
  name: string;
  city: string;
  platform: string;
  vertical: string;
  type: string;
  status: string;
  dailyCount: number;
  totalScraped: number;
  successRate: string;
  progress: number;
  version: string;
  lastRun: string | null;
  config: any;
  gptPrompts: any;
}

interface Stats {
  totalBots: number;
  runningBots: number;
  totalLeads: number;
  dailyLeads: number;
  activeSubscriptions: number;
  totalCost: number;
}

interface DashboardProps {
  user: User;
  onLogout: () => void;
}

export default function Dashboard({ user, onLogout }: DashboardProps) {
  const [selectedCity, setSelectedCity] = useState('');
  const [selectedPlatform, setSelectedPlatform] = useState('');
  const [selectedVertical, setSelectedVertical] = useState('');
  const [selectedType, setSelectedType] = useState('');
  const [isCreatingBot, setIsCreatingBot] = useState(false);
  const [editingPrompts, setEditingPrompts] = useState<number | null>(null);
  const [prompts, setPrompts] = useState<Record<string, string>>({});

  const queryClient = useQueryClient();

  const cities = ['Orlando', 'Tampa', 'Miami', 'Jacksonville', 'Fort Lauderdale', 'Tallahassee'];
  const platforms = ['craigslist', 'offerup', 'facebook', 'reddit'];
  const verticals = ['auto', 'real_estate', 'pets'];
  const botTypes = ['scraper', 'enrichment', 'outreach', 'matching'];

  // Fetch bots
  const { data: bots = [], isLoading: botsLoading, refetch: refetchBots } = useQuery({
    queryKey: ['/api/bots'],
    queryFn: async () => {
      const response = await fetch('/api/bots', {
        credentials: 'include'
      });
      if (!response.ok) throw new Error('Failed to fetch bots');
      return response.json();
    }
  });

  // Fetch stats
  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ['/api/stats'],
    queryFn: async () => {
      const response = await fetch('/api/stats', {
        credentials: 'include'
      });
      if (!response.ok) throw new Error('Failed to fetch stats');
      return response.json();
    }
  });

  // Fetch activity logs
  const { data: logs = [], isLoading: logsLoading } = useQuery({
    queryKey: ['/api/logs'],
    queryFn: async () => {
      const response = await fetch('/api/logs?limit=50', {
        credentials: 'include'
      });
      if (!response.ok) throw new Error('Failed to fetch logs');
      return response.json();
    }
  });

  // Create bot mutation
  const createBotMutation = useMutation({
    mutationFn: async (botData: any) => {
      const response = await fetch('/api/bots', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(botData),
        credentials: 'include'
      });
      if (!response.ok) throw new Error('Failed to create bot');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/bots'] });
      queryClient.invalidateQueries({ queryKey: ['/api/stats'] });
      setSelectedCity('');
      setSelectedPlatform('');
      setSelectedVertical('');
      setSelectedType('');
      setIsCreatingBot(false);
    }
  });

  // Start bot mutation
  const startBotMutation = useMutation({
    mutationFn: async (botId: number) => {
      const response = await fetch(`/api/bots/${botId}/start`, {
        method: 'POST',
        credentials: 'include'
      });
      if (!response.ok) throw new Error('Failed to start bot');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/bots'] });
      queryClient.invalidateQueries({ queryKey: ['/api/stats'] });
    }
  });

  // Stop bot mutation
  const stopBotMutation = useMutation({
    mutationFn: async (botId: number) => {
      const response = await fetch(`/api/bots/${botId}/stop`, {
        method: 'POST',
        credentials: 'include'
      });
      if (!response.ok) throw new Error('Failed to stop bot');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/bots'] });
      queryClient.invalidateQueries({ queryKey: ['/api/stats'] });
    }
  });

  // Delete bot mutation
  const deleteBotMutation = useMutation({
    mutationFn: async (botId: number) => {
      const response = await fetch(`/api/bots/${botId}`, {
        method: 'DELETE',
        credentials: 'include'
      });
      if (!response.ok) throw new Error('Failed to delete bot');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/bots'] });
      queryClient.invalidateQueries({ queryKey: ['/api/stats'] });
    }
  });

  // Update prompts mutation
  const updatePromptsMutation = useMutation({
    mutationFn: async ({ botId, prompts }: { botId: number; prompts: any }) => {
      const response = await fetch(`/api/bots/${botId}/prompts`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompts }),
        credentials: 'include'
      });
      if (!response.ok) throw new Error('Failed to update prompts');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/bots'] });
      setEditingPrompts(null);
    }
  });

  const handleCreateBot = () => {
    if (!selectedCity || !selectedPlatform || !selectedVertical || !selectedType) {
      return;
    }

    const botData = {
      name: `${selectedCity} ${selectedPlatform.charAt(0).toUpperCase() + selectedPlatform.slice(1)} ${selectedType.charAt(0).toUpperCase() + selectedType.slice(1)} Bot`,
      city: selectedCity,
      platform: selectedPlatform,
      vertical: selectedVertical,
      type: selectedType,
      status: 'stopped',
      dailyCount: 0,
      totalScraped: 0,
      successRate: '0.00',
      progress: 0,
      version: '1.0.0',
      config: {
        leadTarget: 50,
        schedule: { enabled: false }
      },
      gptPrompts: {
        enrichment: 'Analyze and enrich this lead data with relevant insights.',
        outreach: 'Create a personalized outreach message for this lead.',
        matching: 'Match this lead to the most appropriate dealer or vertical.'
      }
    };

    createBotMutation.mutate(botData);
  };

  const handleLogout = async () => {
    try {
      await fetch('/api/auth/logout', {
        method: 'POST',
        credentials: 'include'
      });
      onLogout();
    } catch (error) {
      console.error('Logout error:', error);
      onLogout(); // Force logout anyway
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'running':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'stopped':
        return <XCircle className="h-4 w-4 text-gray-500" />;
      case 'error':
        return <AlertCircle className="h-4 w-4 text-red-500" />;
      default:
        return <XCircle className="h-4 w-4 text-gray-500" />;
    }
  };

  const getStatusBadge = (status: string) => {
    const variant = status === 'running' ? 'default' : status === 'error' ? 'destructive' : 'secondary';
    return (
      <Badge variant={variant} className="capitalize">
        {status}
      </Badge>
    );
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <header className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <Bot className="h-8 w-8 text-blue-600" />
                <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
                  Super Smart Stealz
                </h1>
              </div>
              <Badge variant="outline" className="text-xs">
                Bot Command Center
              </Badge>
            </div>
            <div className="flex items-center space-x-4">
              <div className="text-sm text-gray-600 dark:text-gray-400">
                Welcome, {user.name}
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={handleLogout}
                className="flex items-center space-x-2"
              >
                <LogOut className="h-4 w-4" />
                <span>Logout</span>
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="p-6">
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-7">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="bots">Bot Management</TabsTrigger>
            <TabsTrigger value="advanced">Advanced Features</TabsTrigger>
            <TabsTrigger value="prompts">GPT Prompts</TabsTrigger>
            <TabsTrigger value="subscriptions">Subscriptions</TabsTrigger>
            <TabsTrigger value="logs">Activity Logs</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Bots</CardTitle>
                  <Bot className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stats?.totalBots || 0}</div>
                  <p className="text-xs text-muted-foreground">
                    {stats?.runningBots || 0} running
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Leads</CardTitle>
                  <Database className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stats?.totalLeads || 0}</div>
                  <p className="text-xs text-muted-foreground">
                    {stats?.dailyLeads || 0} today
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Active Subscriptions</CardTitle>
                  <Users className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stats?.activeSubscriptions || 0}</div>
                  <p className="text-xs text-muted-foreground">
                    Paying customers
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Cost</CardTitle>
                  <DollarSign className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">${stats?.totalCost?.toFixed(2) || '0.00'}</div>
                  <p className="text-xs text-muted-foreground">
                    OpenAI API costs
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* Recent Activity */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Activity className="h-5 w-5" />
                  <span>Recent Activity</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[300px]">
                  <div className="space-y-3">
                    {logs.slice(0, 10).map((log: any) => (
                      <div key={log.id} className="flex items-center space-x-3 text-sm">
                        <div className="flex-shrink-0">
                          {log.status === 'success' ? (
                            <CheckCircle className="h-4 w-4 text-green-500" />
                          ) : log.status === 'error' ? (
                            <XCircle className="h-4 w-4 text-red-500" />
                          ) : (
                            <AlertCircle className="h-4 w-4 text-yellow-500" />
                          )}
                        </div>
                        <div className="flex-1">
                          <p className="text-gray-900 dark:text-gray-100">{log.message}</p>
                          <p className="text-xs text-gray-500">
                            {new Date(log.timestamp).toLocaleString()}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Bot Management Tab */}
          <TabsContent value="bots" className="space-y-6">
            <AdvancedBotControl 
              bots={bots} 
              onRefresh={refetchBots} 
              onLogRefresh={() => queryClient.invalidateQueries({ queryKey: ['/api/logs'] })}
            />
          </TabsContent>

          {/* Advanced Features Tab */}
          <TabsContent value="advanced" className="space-y-6">
            <AdvancedFeaturesSimple />
          </TabsContent>

          {/* GPT Prompts Tab */}
          <TabsContent value="prompts" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {bots.map((bot: BotInstance) => (
                <Card key={bot.id}>
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                      <span>{bot.name}</span>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => {
                          setEditingPrompts(bot.id);
                          setPrompts(bot.gptPrompts || {});
                        }}
                      >
                        <Edit3 className="h-4 w-4 mr-1" />
                        Edit
                      </Button>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {editingPrompts === bot.id ? (
                      <div className="space-y-4">
                        <div className="space-y-2">
                          <Label>Enrichment Prompt</Label>
                          <Textarea
                            value={prompts['enrichment'] || ''}
                            onChange={(e) => setPrompts({...prompts, enrichment: e.target.value})}
                            rows={3}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label>Outreach Prompt</Label>
                          <Textarea
                            value={prompts['outreach'] || ''}
                            onChange={(e) => setPrompts({...prompts, outreach: e.target.value})}
                            rows={3}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label>Matching Prompt</Label>
                          <Textarea
                            value={prompts['matching'] || ''}
                            onChange={(e) => setPrompts({...prompts, matching: e.target.value})}
                            rows={3}
                          />
                        </div>
                        <div className="flex space-x-2">
                          <Button
                            size="sm"
                            onClick={() => updatePromptsMutation.mutate({ botId: bot.id, prompts })}
                            disabled={updatePromptsMutation.isPending}
                          >
                            Save
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => setEditingPrompts(null)}
                          >
                            Cancel
                          </Button>
                        </div>
                      </div>
                    ) : (
                      <div className="space-y-3">
                        <div>
                          <Label className="text-sm font-medium">Enrichment</Label>
                          <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                            {bot.gptPrompts?.enrichment || 'No prompt set'}
                          </p>
                        </div>
                        <div>
                          <Label className="text-sm font-medium">Outreach</Label>
                          <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                            {bot.gptPrompts?.outreach || 'No prompt set'}
                          </p>
                        </div>
                        <div>
                          <Label className="text-sm font-medium">Matching</Label>
                          <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                            {bot.gptPrompts?.matching || 'No prompt set'}
                          </p>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Subscriptions Tab */}
          <TabsContent value="subscriptions" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Subscription Management</CardTitle>
                <CardDescription>
                  Manage dealer subscriptions and vertical assignments
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Alert>
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>
                    Subscription management feature coming soon. This will allow you to manage dealer 
                    subscriptions, assign bots to specific verticals, and configure lead distribution.
                  </AlertDescription>
                </Alert>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Activity Logs Tab */}
          <TabsContent value="logs" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Activity className="h-5 w-5" />
                  <span>Activity Logs</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[600px]">
                  <div className="space-y-4">
                    {logs.map((log: any) => (
                      <div key={log.id} className="flex items-start space-x-3 p-3 rounded-lg border">
                        <div className="flex-shrink-0 mt-1">
                          {log.status === 'success' ? (
                            <CheckCircle className="h-4 w-4 text-green-500" />
                          ) : log.status === 'error' ? (
                            <XCircle className="h-4 w-4 text-red-500" />
                          ) : (
                            <AlertCircle className="h-4 w-4 text-yellow-500" />
                          )}
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center justify-between">
                            <p className="font-medium text-gray-900 dark:text-gray-100">
                              {log.action.replace('_', ' ').charAt(0).toUpperCase() + log.action.replace('_', ' ').slice(1)}
                            </p>
                            <Badge variant="outline" className="text-xs">
                              {log.status}
                            </Badge>
                          </div>
                          <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                            {log.message}
                          </p>
                          <div className="flex items-center space-x-4 text-xs text-gray-500 mt-2">
                            <span>{new Date(log.timestamp).toLocaleString()}</span>
                            {log.ipAddress && <span>IP: {log.ipAddress}</span>}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Settings Tab */}
          <TabsContent value="settings" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Settings className="h-5 w-5" />
                  <span>Security Settings</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Alert>
                  <Shield className="h-4 w-4" />
                  <AlertDescription>
                    Security settings including IP whitelist management, session controls, and 
                    password changes will be available here. Your account is currently protected 
                    by enterprise-grade 2FA security.
                  </AlertDescription>
                </Alert>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}