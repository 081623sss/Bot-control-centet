import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { 
  Shield, 
  Users, 
  Globe, 
  Lock, 
  Plus, 
  Trash2, 
  AlertTriangle, 
  CheckCircle,
  Clock,
  Monitor,
  Key
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface ActiveSession {
  tokenPreview: string;
  email: string;
  ip: string;
  userAgent: string;
  createdAt: string;
  expiresAt: string;
}

interface SecurityStats {
  activeSessions: number;
  pendingVerifications: number;
  whitelistedIPs: number;
  blockedIPs: number;
}

export default function SecuritySettings() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // State for forms
  const [newIP, setNewIP] = useState('');
  const [passwordForm, setPasswordForm] = useState({
    current: '',
    new: '',
    confirm: ''
  });

  // Fetch active sessions
  const { data: sessionsData, isLoading: sessionsLoading } = useQuery({
    queryKey: ['/api/auth/security/sessions'],
    refetchInterval: 30000 // Refresh every 30 seconds
  });

  // Fetch whitelisted IPs
  const { data: whitelistData, isLoading: whitelistLoading } = useQuery({
    queryKey: ['/api/auth/security/whitelist'],
    refetchInterval: 60000 // Refresh every minute
  });

  // Fetch security stats
  const { data: statsData, isLoading: statsLoading } = useQuery({
    queryKey: ['/api/auth/security/stats'],
    refetchInterval: 30000
  });

  // Add IP to whitelist mutation
  const addIPMutation = useMutation({
    mutationFn: async (ip: string) => {
      const response = await apiRequest('/api/auth/security/whitelist', {
        method: 'POST',
        body: JSON.stringify({ ip })
      });
      return response.json();
    },
    onSuccess: (data) => {
      if (data.success) {
        toast({
          title: "IP Added",
          description: data.message,
        });
        setNewIP('');
        queryClient.invalidateQueries({ queryKey: ['/api/auth/security/whitelist'] });
        queryClient.invalidateQueries({ queryKey: ['/api/auth/security/stats'] });
      } else {
        toast({
          title: "Error",
          description: data.message,
          variant: "destructive"
        });
      }
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to add IP to whitelist",
        variant: "destructive"
      });
    }
  });

  // Remove IP from whitelist mutation
  const removeIPMutation = useMutation({
    mutationFn: async (ip: string) => {
      const response = await apiRequest(`/api/auth/security/whitelist/${encodeURIComponent(ip)}`, {
        method: 'DELETE'
      });
      return response.json();
    },
    onSuccess: (data) => {
      if (data.success) {
        toast({
          title: "IP Removed",
          description: data.message,
        });
        queryClient.invalidateQueries({ queryKey: ['/api/auth/security/whitelist'] });
        queryClient.invalidateQueries({ queryKey: ['/api/auth/security/stats'] });
      } else {
        toast({
          title: "Error",
          description: data.message,
          variant: "destructive"
        });
      }
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to remove IP from whitelist",
        variant: "destructive"
      });
    }
  });

  // Revoke session mutation
  const revokeSessionMutation = useMutation({
    mutationFn: async (token: string) => {
      const response = await apiRequest(`/api/auth/security/sessions/${token}`, {
        method: 'DELETE'
      });
      return response.json();
    },
    onSuccess: (data) => {
      if (data.success) {
        toast({
          title: "Session Revoked",
          description: data.message,
        });
        queryClient.invalidateQueries({ queryKey: ['/api/auth/security/sessions'] });
        queryClient.invalidateQueries({ queryKey: ['/api/auth/security/stats'] });
      } else {
        toast({
          title: "Error",
          description: data.message,
          variant: "destructive"
        });
      }
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to revoke session",
        variant: "destructive"
      });
    }
  });

  // Change password mutation
  const changePasswordMutation = useMutation({
    mutationFn: async (passwords: { currentPassword: string; newPassword: string }) => {
      const response = await apiRequest('/api/auth/security/password', {
        method: 'PUT',
        body: JSON.stringify(passwords)
      });
      return response.json();
    },
    onSuccess: (data) => {
      if (data.success) {
        toast({
          title: "Password Changed",
          description: data.message,
        });
        setPasswordForm({ current: '', new: '', confirm: '' });
        // Redirect to login since all sessions are revoked
        setTimeout(() => {
          window.location.href = '/';
        }, 2000);
      } else {
        toast({
          title: "Error",
          description: data.message,
          variant: "destructive"
        });
      }
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to change password",
        variant: "destructive"
      });
    }
  });

  const handleAddIP = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newIP.trim()) return;
    
    // Basic IP validation
    const ipRegex = /^(\d{1,3}\.){3}\d{1,3}$|^::1$|^localhost$/;
    if (!ipRegex.test(newIP.trim())) {
      toast({
        title: "Invalid IP",
        description: "Please enter a valid IP address",
        variant: "destructive"
      });
      return;
    }

    addIPMutation.mutate(newIP.trim());
  };

  const handleChangePassword = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!passwordForm.current || !passwordForm.new || !passwordForm.confirm) {
      toast({
        title: "Missing Fields",
        description: "Please fill in all password fields",
        variant: "destructive"
      });
      return;
    }

    if (passwordForm.new !== passwordForm.confirm) {
      toast({
        title: "Password Mismatch",
        description: "New password and confirmation do not match",
        variant: "destructive"
      });
      return;
    }

    if (passwordForm.new.length < 8) {
      toast({
        title: "Weak Password",
        description: "Password must be at least 8 characters long",
        variant: "destructive"
      });
      return;
    }

    changePasswordMutation.mutate({
      currentPassword: passwordForm.current,
      newPassword: passwordForm.new
    });
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString();
  };

  const formatUserAgent = (userAgent: string) => {
    if (userAgent.includes('Chrome')) return '🌐 Chrome';
    if (userAgent.includes('Firefox')) return '🦊 Firefox';
    if (userAgent.includes('Safari')) return '🧭 Safari';
    if (userAgent.includes('Edge')) return '🌐 Edge';
    return '🖥️ Unknown';
  };

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-white mb-2">Security Settings</h1>
        <p className="text-slate-400">Manage authentication, IP whitelist, and security policies</p>
      </div>

      {/* Security Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
        <Card className="bg-slate-900 border-slate-700">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-blue-600/20 rounded-lg flex items-center justify-center">
                <Users className="w-5 h-5 text-blue-400" />
              </div>
              <div>
                <p className="text-2xl font-bold text-white">
                  {statsLoading ? '...' : statsData?.stats?.activeSessions || 0}
                </p>
                <p className="text-sm text-slate-400">Active Sessions</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-900 border-slate-700">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-green-600/20 rounded-lg flex items-center justify-center">
                <Globe className="w-5 h-5 text-green-400" />
              </div>
              <div>
                <p className="text-2xl font-bold text-white">
                  {statsLoading ? '...' : statsData?.stats?.whitelistedIPs || 0}
                </p>
                <p className="text-sm text-slate-400">Whitelisted IPs</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-900 border-slate-700">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-yellow-600/20 rounded-lg flex items-center justify-center">
                <Clock className="w-5 h-5 text-yellow-400" />
              </div>
              <div>
                <p className="text-2xl font-bold text-white">
                  {statsLoading ? '...' : statsData?.stats?.pendingVerifications || 0}
                </p>
                <p className="text-sm text-slate-400">Pending 2FA</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-900 border-slate-700">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-red-600/20 rounded-lg flex items-center justify-center">
                <Shield className="w-5 h-5 text-red-400" />
              </div>
              <div>
                <p className="text-2xl font-bold text-white">
                  {statsLoading ? '...' : statsData?.stats?.blockedIPs || 0}
                </p>
                <p className="text-sm text-slate-400">Blocked IPs</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Active Sessions */}
        <Card className="bg-slate-900 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Monitor className="w-5 h-5" />
              Active Sessions
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {sessionsLoading ? (
              <div className="text-center py-4 text-slate-400">Loading sessions...</div>
            ) : !sessionsData?.sessions?.length ? (
              <div className="text-center py-4 text-slate-400">No active sessions</div>
            ) : (
              sessionsData.sessions.map((session: ActiveSession, index: number) => (
                <div key={index} className="flex items-center justify-between p-3 bg-slate-800 rounded-lg">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-sm font-mono text-slate-300">{session.tokenPreview}</span>
                      <Badge variant="outline" className="text-xs border-slate-600 text-slate-400">
                        {session.ip}
                      </Badge>
                    </div>
                    <div className="text-xs text-slate-400">
                      {formatUserAgent(session.userAgent)} • {formatDate(session.createdAt)}
                    </div>
                  </div>
                  <Button
                    size="sm"
                    variant="destructive"
                    onClick={() => revokeSessionMutation.mutate(session.tokenPreview.replace('...', ''))}
                    disabled={revokeSessionMutation.isPending}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              ))
            )}
          </CardContent>
        </Card>

        {/* IP Whitelist Management */}
        <Card className="bg-slate-900 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Globe className="w-5 h-5" />
              IP Whitelist
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <form onSubmit={handleAddIP} className="flex gap-2">
              <Input
                placeholder="192.168.1.100"
                value={newIP}
                onChange={(e) => setNewIP(e.target.value)}
                className="bg-slate-800 border-slate-600 text-white"
              />
              <Button 
                type="submit" 
                disabled={addIPMutation.isPending}
                className="bg-blue-600 hover:bg-blue-700"
              >
                <Plus className="w-4 h-4" />
              </Button>
            </form>

            <div className="space-y-2">
              {whitelistLoading ? (
                <div className="text-center py-4 text-slate-400">Loading whitelist...</div>
              ) : !whitelistData?.whitelistedIPs?.length ? (
                <div className="text-center py-4 text-slate-400">No whitelisted IPs</div>
              ) : (
                whitelistData.whitelistedIPs.map((ip: string, index: number) => (
                  <div key={index} className="flex items-center justify-between p-2 bg-slate-800 rounded">
                    <span className="text-slate-300 font-mono">{ip}</span>
                    <Button
                      size="sm"
                      variant="destructive"
                      onClick={() => removeIPMutation.mutate(ip)}
                      disabled={removeIPMutation.isPending}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Password Change */}
      <Card className="bg-slate-900 border-slate-700 mt-8">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Key className="w-5 h-5" />
            Change Password
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Alert className="border-yellow-500/20 bg-yellow-500/10 mb-6">
            <AlertTriangle className="w-4 h-4 text-yellow-400" />
            <AlertDescription className="text-yellow-300">
              Changing your password will revoke all active sessions and require re-authentication.
            </AlertDescription>
          </Alert>

          <form onSubmit={handleChangePassword} className="space-y-4 max-w-md">
            <div className="space-y-2">
              <Label htmlFor="current" className="text-slate-300">Current Password</Label>
              <Input
                id="current"
                type="password"
                value={passwordForm.current}
                onChange={(e) => setPasswordForm(prev => ({ ...prev, current: e.target.value }))}
                className="bg-slate-800 border-slate-600 text-white"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="new" className="text-slate-300">New Password</Label>
              <Input
                id="new"
                type="password"
                value={passwordForm.new}
                onChange={(e) => setPasswordForm(prev => ({ ...prev, new: e.target.value }))}
                className="bg-slate-800 border-slate-600 text-white"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="confirm" className="text-slate-300">Confirm New Password</Label>
              <Input
                id="confirm"
                type="password"
                value={passwordForm.confirm}
                onChange={(e) => setPasswordForm(prev => ({ ...prev, confirm: e.target.value }))}
                className="bg-slate-800 border-slate-600 text-white"
              />
            </div>

            <Button 
              type="submit" 
              disabled={changePasswordMutation.isPending}
              className="bg-red-600 hover:bg-red-700"
            >
              {changePasswordMutation.isPending ? (
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                  Changing Password...
                </div>
              ) : (
                'Change Password'
              )}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}