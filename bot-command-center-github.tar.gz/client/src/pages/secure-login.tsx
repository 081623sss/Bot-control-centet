import { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useToast } from "@/hooks/use-toast";
import { Shield, Mail, Clock, AlertTriangle, CheckCircle, Lock } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

type AuthStep = 'credentials' | '2fa' | 'success';

interface AuthState {
  step: AuthStep;
  email: string;
  password: string;
  verificationCode: string;
  error: string;
  success: string;
  isLoading: boolean;
  expiresIn: number;
  timeLeft: number;
}

export default function SecureLogin() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [state, setState] = useState<AuthState>({
    step: 'credentials',
    email: 'admin@supersmartstealz.com',
    password: '',
    verificationCode: '',
    error: '',
    success: '',
    isLoading: false,
    expiresIn: 0,
    timeLeft: 0
  });

  // Countdown timer for verification code
  useEffect(() => {
    let interval: NodeJS.Timeout;
    
    if (state.step === '2fa' && state.timeLeft > 0) {
      interval = setInterval(() => {
        setState(prev => ({
          ...prev,
          timeLeft: Math.max(0, prev.timeLeft - 1)
        }));
      }, 1000);
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [state.step, state.timeLeft]);

  // Check authentication status on mount
  useEffect(() => {
    checkAuthStatus();
  }, []);

  const checkAuthStatus = async () => {
    try {
      const response = await fetch('/api/auth/status');
      const data = await response.json();
      
      if (data.authenticated) {
        setLocation('/dashboard');
      }
    } catch (error) {
      // Not authenticated, stay on login page
    }
  };

  const handleCredentialsSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!state.email || !state.password) {
      setState(prev => ({ ...prev, error: 'Please enter both email and password.' }));
      return;
    }

    setState(prev => ({ ...prev, isLoading: true, error: '', success: '' }));

    try {
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          email: state.email,
          password: state.password
        })
      });

      const data = await response.json();

      if (data.success && data.sessionToken) {
        // Development mode - direct login success
        toast({
          title: "Login Successful",
          description: data.message || "Welcome to Bot Command Center",
        });
        setLocation('/dashboard');
      } else if (data.success && data.step === '2fa_required') {
        setState(prev => ({
          ...prev,
          step: '2fa',
          success: data.message,
          expiresIn: data.expiresIn,
          timeLeft: data.expiresIn,
          error: '',
          isLoading: false
        }));
      } else {
        setState(prev => ({
          ...prev,
          error: data.message || 'Login failed. Please try again.',
          isLoading: false
        }));
      }
    } catch (error: any) {
      setState(prev => ({
        ...prev,
        error: error.message || 'Network error. Please check your connection.',
        isLoading: false
      }));
    }
  };

  const handleVerificationSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!state.verificationCode || state.verificationCode.length !== 6) {
      setState(prev => ({ ...prev, error: 'Please enter the 6-digit verification code.' }));
      return;
    }

    setState(prev => ({ ...prev, isLoading: true, error: '' }));

    try {
      const response = await fetch('/api/auth/verify', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          code: state.verificationCode
        })
      });

      const data = await response.json();

      if (data.success) {
        setState(prev => ({
          ...prev,
          step: 'success',
          success: 'Login successful! Redirecting to dashboard...',
          error: '',
          isLoading: false
        }));

        // Redirect to dashboard after a brief success message
        setTimeout(() => {
          setLocation('/dashboard');
        }, 1500);
      } else {
        setState(prev => ({
          ...prev,
          error: data.message || 'Invalid verification code. Please try again.',
          isLoading: false
        }));
      }
    } catch (error: any) {
      setState(prev => ({
        ...prev,
        error: error.message || 'Verification failed. Please try again.',
        isLoading: false
      }));
    }
  };

  const handleStartOver = () => {
    setState({
      step: 'credentials',
      email: 'admin@supersmartstealz.com',
      password: '',
      verificationCode: '',
      error: '',
      success: '',
      isLoading: false,
      expiresIn: 0,
      timeLeft: 0
    });
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const renderCredentialsStep = () => (
    <form onSubmit={handleCredentialsSubmit} className="space-y-6">
      <div className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="email" className="text-slate-300">
            Admin Email
          </Label>
          <Input
            id="email"
            type="email"
            value={state.email}
            onChange={(e) => setState(prev => ({ ...prev, email: e.target.value }))}
            className="bg-slate-800 border-slate-600 text-white placeholder:text-slate-400 focus:border-blue-500"
            disabled={state.isLoading}
            readOnly
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="password" className="text-slate-300">
            Master Password
          </Label>
          <Input
            id="password"
            type="password"
            placeholder="Enter your admin password"
            value={state.password}
            onChange={(e) => setState(prev => ({ ...prev, password: e.target.value }))}
            className="bg-slate-800 border-slate-600 text-white placeholder:text-slate-400 focus:border-blue-500"
            disabled={state.isLoading}
            autoFocus
          />
        </div>
      </div>
      
      <Button
        type="submit"
        disabled={state.isLoading || !state.password.trim()}
        className="w-full bg-blue-600 hover:bg-blue-700 text-white"
      >
        {state.isLoading ? (
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
            Verifying Credentials...
          </div>
        ) : (
          <div className="flex items-center gap-2">
            <Lock className="w-4 h-4" />
            Continue to 2FA
          </div>
        )}
      </Button>
    </form>
  );

  const render2FAStep = () => (
    <div className="space-y-6">
      <div className="text-center space-y-3">
        <div className="w-16 h-16 bg-green-600/20 rounded-full flex items-center justify-center mx-auto">
          <Mail className="w-8 h-8 text-green-400" />
        </div>
        <div>
          <h3 className="text-lg font-semibold text-white mb-1">
            Check Your Email
          </h3>
          <p className="text-slate-400 text-sm">
            We've sent a 6-digit verification code to
          </p>
          <p className="text-blue-400 font-medium">
            {state.email}
          </p>
        </div>
      </div>

      <form onSubmit={handleVerificationSubmit} className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="code" className="text-slate-300">
            Verification Code
          </Label>
          <Input
            id="code"
            type="text"
            placeholder="123456"
            value={state.verificationCode}
            onChange={(e) => {
              const value = e.target.value.replace(/\D/g, '').slice(0, 6);
              setState(prev => ({ ...prev, verificationCode: value }));
            }}
            className="bg-slate-800 border-slate-600 text-white placeholder:text-slate-400 focus:border-blue-500 text-center text-2xl font-mono tracking-wider"
            disabled={state.isLoading}
            maxLength={6}
            autoFocus
          />
        </div>

        {state.timeLeft > 0 && (
          <div className="flex items-center justify-center gap-2 text-slate-400 text-sm">
            <Clock className="w-4 h-4" />
            Code expires in {formatTime(state.timeLeft)}
          </div>
        )}

        <div className="space-y-3">
          <Button
            type="submit"
            disabled={state.isLoading || state.verificationCode.length !== 6}
            className="w-full bg-green-600 hover:bg-green-700 text-white"
          >
            {state.isLoading ? (
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                Verifying Code...
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4" />
                Verify & Login
              </div>
            )}
          </Button>

          <Button
            type="button"
            variant="outline"
            onClick={handleStartOver}
            disabled={state.isLoading}
            className="w-full border-slate-600 text-slate-300 hover:bg-slate-800"
          >
            Start Over
          </Button>
        </div>
      </form>
    </div>
  );

  const renderSuccessStep = () => (
    <div className="text-center space-y-6">
      <div className="w-16 h-16 bg-green-600/20 rounded-full flex items-center justify-center mx-auto">
        <CheckCircle className="w-8 h-8 text-green-400" />
      </div>
      
      <div>
        <h3 className="text-xl font-semibold text-white mb-2">
          Login Successful!
        </h3>
        <p className="text-slate-400">
          Redirecting to your dashboard...
        </p>
      </div>

      <div className="w-8 h-8 border-2 border-blue-600/30 border-t-blue-600 rounded-full animate-spin mx-auto"></div>
    </div>
  );

  return (
    <div className="min-h-screen bg-slate-950 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-slate-950 to-slate-900"></div>
      
      <Card className="w-full max-w-md bg-slate-900 border-slate-700 shadow-2xl relative z-10">
        <CardHeader className="text-center space-y-4">
          <div className="mx-auto w-16 h-16 bg-blue-600/20 rounded-full flex items-center justify-center">
            <Shield className="w-8 h-8 text-blue-400" />
          </div>
          
          <div>
            <CardTitle className="text-2xl font-bold text-white mb-2">
              Bot Command Center
            </CardTitle>
            <p className="text-slate-400 text-sm">
              {state.step === 'credentials' && 'Secure Authentication Required'}
              {state.step === '2fa' && 'Two-Factor Authentication'}
              {state.step === 'success' && 'Access Granted'}
            </p>
          </div>
        </CardHeader>
        
        <CardContent className="space-y-6">
          {state.error && (
            <Alert className="border-red-500/20 bg-red-500/10">
              <AlertTriangle className="w-4 h-4 text-red-400" />
              <AlertDescription className="text-red-300">
                {state.error}
              </AlertDescription>
            </Alert>
          )}

          {state.success && (
            <Alert className="border-green-500/20 bg-green-500/10">
              <CheckCircle className="w-4 h-4 text-green-400" />
              <AlertDescription className="text-green-300">
                {state.success}
              </AlertDescription>
            </Alert>
          )}
          
          {state.step === 'credentials' && renderCredentialsStep()}
          {state.step === '2fa' && render2FAStep()}
          {state.step === 'success' && renderSuccessStep()}
          
          <div className="text-center">
            <p className="text-slate-400 text-xs">
              🛡️ Protected by enterprise-grade security with 2FA
            </p>
          </div>
        </CardContent>
      </Card>
      
      {/* Background decoration */}
      <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-blue-600 via-purple-600 to-blue-600"></div>
    </div>
  );
}