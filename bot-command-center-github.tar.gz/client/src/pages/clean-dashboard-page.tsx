import CleanDashboard from '@/components/dashboard/clean-dashboard';

export function Dashboard() {
  return <CleanDashboard />;
}

export default Dashboard;