#!/bin/bash
set -e

echo "Starting Railway build process..."

# Build backend first (fast)
echo "Building backend..."
esbuild server/index.ts --platform=node --packages=external --bundle --format=esm --outdir=dist

# Build frontend with optimizations
echo "Building frontend..."
export NODE_OPTIONS="--max-old-space-size=2048"
vite build --mode production --logLevel silent

echo "Build completed successfully!"