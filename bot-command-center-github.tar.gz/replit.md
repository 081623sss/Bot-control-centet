# Bot Command Center - replit.md

## Overview

Super Smart Stealz is a multi-channel surplus and liquidation resale platform that scrapes real-time buyer demand (Craigslist wanted ads), enriches leads using GPT, and matches them to auction listings (GSA, AllSurplus) or dealer inventory. Each match generates an AOR (Auction Opportunity Report) with auction overview, financial breakdown, resale potential, velocity analysis, lead match score, max bid recommendation, and approval tier. The Bot Command Center provides enterprise-grade management for hundreds of vertical bots across multiple client accounts.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript
- **Build Tool**: Vite for development and building
- **UI Framework**: shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with custom CSS variables for theming
- **State Management**: TanStack Query (React Query) for server state
- **Routing**: Wouter for client-side routing
- **Form Handling**: React Hook Form with Zod validation

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **API Design**: RESTful API with JSON responses
- **Session Management**: Built-in session handling with connect-pg-simple
- **Development**: Hot reload with Vite integration in development mode

### Business Logic & Data Flow

**Core Business Model**: Multi-channel surplus/liquidation resale matching buyer demand to auction inventory.

**Data Pipeline**:
1. **Lead Scraping**: Bots extract buyer demand from Craigslist wanted ads, Facebook marketplace, etc.
2. **Lead Enrichment**: GPT analyzes raw leads for intent, urgency, categorization, contact extraction
3. **Lead Routing**: Enriched leads flow to vertical-specific tables (auto_leads, goods_leads, real_estate_leads)
4. **Inventory Matching**: System matches leads against auction listings (GSA, AllSurplus) and dealer inventory
5. **AOR Generation**: Each match creates an Auction Opportunity Report with financial analysis and recommendations
6. **Hot Leads**: Qualified matches stored in hot_leads table for client delivery

**AOR (Auction Opportunity Report) Structure**:
- Auction Overview: Item details, auction house, timeline
- Financial Breakdown: Acquisition cost, fees, total investment, profit margin
- Resale Potential: Market value analysis, platform recommendations
- Resale Velocity: Average days to sell, seasonal factors, market demand
- Lead Match Score: Compatibility percentage with buyer requirements
- Max Bid Recommendation: Optimal bidding threshold for profitability
- Approval Tier: Risk assessment (pursue/caution/pass)

**Subscription Model**: Platform sells bot access to auto dealers and real estate investors requiring multi-client support and custom data sources.

### Database Schema
The application uses three main tables:
- `bot_instances`: Stores bot configuration and status information
- `activity_logs`: Tracks system activities and events
- `system_metrics`: Monitors system performance and health

## Key Components

### Dashboard Components
- **Header**: Main navigation with connection status
- **Overview Stats**: Key performance indicators display
- **Bot Control Panel**: Individual bot management interface
- **Activity Feed**: Real-time activity logging
- **System Status**: Service health monitoring
- **Performance Metrics**: CPU, memory, and network monitoring
- **Quick Actions**: Bulk operations for bot management

### Data Management
- **Storage Layer**: Abstracted storage interface with in-memory fallback
- **Real-time Updates**: Query invalidation for live data updates
- **Error Handling**: Comprehensive error boundaries and user feedback

## Data Flow

1. **Client Requests**: Frontend makes API calls using TanStack Query
2. **API Processing**: Express routes handle requests and validate data
3. **Database Operations**: Drizzle ORM manages database interactions
4. **Response Handling**: JSON responses with proper error handling
5. **UI Updates**: Automatic cache invalidation triggers UI refreshes

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL database connectivity
- **drizzle-orm**: Type-safe database ORM
- **@tanstack/react-query**: Server state management
- **@radix-ui/***: Accessible UI component primitives
- **tailwindcss**: Utility-first CSS framework
- **react-hook-form**: Form state management
- **zod**: Schema validation

### Development Tools
- **tsx**: TypeScript execution for development
- **esbuild**: Fast JavaScript bundler for production
- **@replit/vite-plugin-***: Replit-specific development tools

## Deployment Strategy

### Development
- Uses Vite dev server with HMR (Hot Module Replacement)
- TypeScript compilation with strict mode enabled
- Database migrations handled via Drizzle Kit

### Production Build
- Frontend built with Vite and output to `dist/public`
- Backend bundled with esbuild for Node.js execution
- Environment variables required: `DATABASE_URL`

### Database Setup
- PostgreSQL database required (Neon serverless supported)
- Schema managed through Drizzle migrations
- Database push command: `npm run db:push`

## Recent Changes
- July 02, 2025: **COMPLETE SYSTEM REBUILD**: Transformed from simple bot dashboard to comprehensive business management platform
- July 02, 2025: **NEW DATABASE ARCHITECTURE**: Implemented PostgreSQL with comprehensive schema for users, subscriptions, bots, leads, and vertical management
- July 02, 2025: **MULTI-VERTICAL SYSTEM**: Added support for Auto, Real Estate, and Pets verticals with dedicated lead tables
- July 02, 2025: **ENTERPRISE AUTHENTICATION**: Built secure 2FA system with email verification, IP whitelisting, and session management
- July 02, 2025: **BOT MANAGEMENT PLATFORM**: Created comprehensive bot control system supporting Craigslist, OfferUp, Facebook, Reddit
- July 02, 2025: **GPT INTEGRATION**: Added customizable GPT prompts per bot (enrichment, outreach, matching) with live editing
- July 02, 2025: **SUBSCRIPTION SYSTEM**: Designed dealer subscription management with vertical assignments and lead routing
- July 02, 2025: **COST MONITORING**: Implemented OpenAI API cost tracking and usage analytics
- July 02, 2025: **SECURE API LAYER**: Built comprehensive REST API with authentication middleware and activity logging
- July 02, 2025: **PROFESSIONAL UI**: Created modern dashboard with tabbed interface, real-time stats, and comprehensive bot controls
- July 02, 2025: **NGROK INTEGRATION**: Connected Replit frontend to Termius bot server via Ngrok (https://f1e9-2600-3c0a-00-f03c-95ff.ngrok.io)
- July 02, 2025: **DUAL API ARCHITECTURE**: Implemented hybrid system - Replit handles authentication, Termius handles bot operations
- July 02, 2025: **REAL-TIME CONNECTION STATUS**: Added live connection monitoring for each bot showing Termius server connectivity
- July 02, 2025: **8 ADVANCED FEATURES IMPLEMENTED**: Added comprehensive advanced features dashboard with GPT-4 editor, file management, AI assistant, health monitoring, subscription management, database sync, prompt management, and dev tools
- July 02, 2025: **ADVANCED FEATURES TAB**: Created new "Advanced Features" tab in dashboard with 8 specialized interfaces for enterprise bot management
- July 02, 2025: **GPT-4 CODE GENERATION**: Built inline code editor with GPT-4 integration for bot script enhancement and modification
- July 02, 2025: **ENHANCED DATABASE SCHEMA**: Extended PostgreSQL schema with tables for alerts, bot files, GPT prompts, command history, and file management
- July 02, 2025: **SUPABASE DATABASE INTEGRATION**: Successfully connected live Supabase PostgreSQL database and seeded with comprehensive sample data
- July 02, 2025: **LIVE TABLES INTERFACE**: Created functional "Tables" tab with real-time lead management for all verticals (auto, real estate, pets, etc.)
- July 02, 2025: **DATABASE SEEDING SYSTEM**: Implemented one-click database seeding with sample bots, leads, and business data
- July 02, 2025: **OPENAI API INTEGRATION**: Connected live OpenAI API key and built comprehensive GPT-powered features
- July 02, 2025: **GPT SERVICE LAYER**: Created complete GPT service with lead enrichment, outreach generation, AOR creation, and code generation
- July 02, 2025: **GPT FEATURES DASHBOARD**: Built comprehensive 4-tab interface for Lead Enrichment Bot, Outreach Bot, AOR Generator, and GPT-4 Code Editor
- July 02, 2025: **REAL GPT FUNCTIONALITY**: All GPT features now powered by actual OpenAI API with cost tracking and activity logging
- July 02, 2025: **SUPER SMART STEALZ BUSINESS MODEL**: Updated system architecture to properly support surplus/liquidation resale platform business logic
- July 02, 2025: **ENHANCED GPT PROMPTS**: Redesigned all GPT prompts to align with Super Smart Stealz arbitrage business model and AOR generation requirements
- July 02, 2025: **COMPREHENSIVE AOR SYSTEM**: Implemented detailed Auction Opportunity Report generation with financial analysis, resale velocity, and bidding strategies
- July 02, 2025: **MULTI-VERTICAL LEAD PROCESSING**: Enhanced lead enrichment to support auto, real estate, goods, and commercial equipment verticals with arbitrage focus
- July 03, 2025: **CUSTOM LEADTABLEMANAGER INTEGRATION**: Successfully integrated user-provided LeadTableManager component with direct Supabase connectivity
- July 03, 2025: **SUPABASE CLIENT SETUP**: Added @supabase/supabase-js package and configured direct database access for Tables tab
- July 03, 2025: **TABLES TAB ENHANCEMENT**: Replaced default Tables interface with custom LeadTableManager featuring table selection, inline editing, and toast notifications
- July 03, 2025: **DUAL BOT EDITOR SYSTEM**: Added both advanced LiveBotEditor (Monaco with GPT-4) and SimpleBotEditor (lightweight textarea) for flexible bot script management
- July 03, 2025: **SIMPLE BOT EDITOR**: Created lightweight file editor component with load, save, and create functionality for basic bot script operations
- July 03, 2025: **BOT FILE HANDLERS**: Implemented complete backend API for bot file operations (read, save, create, list) with authentication and file system management
- July 03, 2025: **BOTS DIRECTORY**: Created bots/ directory structure with example scraper.js file for testing bot editor functionality
- July 03, 2025: **COMPREHENSIVE NGROK INTEGRATION**: Implemented complete Ngrok-based Termius server integration with ngrok tunnel auto-setup, authentication tokens, and professional dashboard components
- July 03, 2025: **ENHANCED BOT EDITOR STYLING**: Completely redesigned both Live Bot Editor and Simple Bot Editor with modern gradients, glass-morphism effects, professional typography, and enhanced Monaco editor with custom fonts
- July 03, 2025: **NGROK TUNNEL ESTABLISHED**: Successfully configured ngrok tunnel (https://a94b-34-75-238-152.ngrok-free.app) with auto-restart capabilities and real-time connection monitoring
- July 03, 2025: **BOT COMMAND API SYSTEM**: Created comprehensive bot command service layer with secure Bearer token authentication and complete CRUD operations for bot management
- July 03, 2025: **PROFESSIONAL DASHBOARD INTEGRATION**: Added NgrokStatus component to dashboard with real-time monitoring, connection status indicators, URL copying, and professional UI styling
- July 03, 2025: **COMPREHENSIVE MOBILE OPTIMIZATION**: Implemented complete mobile-first responsive design across all dashboard pages, components, and interfaces for full mobile phone compatibility
- July 03, 2025: **LIVE CRAIGSLIST BOT INTEGRATION**: Successfully connected live Craigslist Scraper Bot to dashboard with comprehensive management interface, real-time status monitoring, and performance analytics
- July 03, 2025: **CRAIGSLIST BOT SERVICE LAYER**: Built complete backend service for bot control (start/stop/status/rollback/snapshot) with Termius server integration via Ngrok
- July 03, 2025: **BOT ANALYTICS DASHBOARD**: Created comprehensive analytics interface showing weekly/monthly leads, GPT token usage, cost breakdown, and performance metrics
- July 03, 2025: **MULTI-TAB BOT INTEGRATION**: Integrated Craigslist bot across Overview (status widget), Bots (full management), and Analytics (performance data) tabs
- July 03, 2025: **COMPLETE LIVE BOT INTEGRATION**: Implemented full connection to user's Termius Craigslist scraper with direct Ngrok communication, environment variables, and comprehensive error handling
- July 03, 2025: **LIVE CRAIGSLIST BOT MANAGER**: Created comprehensive live bot management system with PM2 command integration, real-time status monitoring, and mobile-responsive interface
- July 03, 2025: **ENHANCED TERMIUS CONNECTIVITY**: Updated system configuration for user's live Ngrok URL (https://elfd-2600-3c0a-00-f03c-95ff.ngrok-free.app) with automatic connection detection and fallback handling
- July 03, 2025: **NGROK TUNNEL CONFIGURATION**: Updated environment to latest working Ngrok URL with proper server order (Express first, then Ngrok tunnel)
- July 03, 2025: **EXTERNAL TUNNEL INTEGRATION**: Disabled local Ngrok service and configured system to use external tunnel (https://elfd-2600-3c0a-00-f03c-95ff.ngrok-free.app)
- July 03, 2025: **DASHBOARD CONFIGURATION COMPLETE**: All environment variables updated, frontend restarted, awaiting Express server API endpoint response
- July 03, 2025: **API ENDPOINT SYNCHRONIZATION**: Fixed parameter mapping between frontend (bot/action) and backend (command/botName) for proper request handling
- July 03, 2025: **COMPLETE SYSTEM REBUILD**: Cleared cache, updated ngrok service for external tunnel integration, system ready for live Express server connection
- July 03, 2025: **SUCCESSFUL NGROK CONNECTION**: Established working connection to live Ngrok tunnel with proper API endpoint routing (/api/ngrok/bot-command) and authentication system
- July 03, 2025: **PRODUCTION BOT CONTROLS**: Implemented complete bot lifecycle management (start/stop/restart/rollback/snapshot) with direct PM2 integration and live status reporting
- July 03, 2025: **ENVIRONMENT CONFIGURATION**: Added VITE_NGROK_PUBLIC_URL and VITE_BOT_TOKEN environment variables for secure remote bot communication
- July 03, 2025: **COMPREHENSIVE ERROR HANDLING**: Built robust offline detection, connection status monitoring, and user-friendly error messages for bot server connectivity issues
- July 04, 2025: **ENVIRONMENT UPDATE**: Updated VITE_NGROK_URL to new tunnel (https://9453-2600-3c0a-00-f03c-95ff.ngrok-free.app) with system restart for configuration refresh
- July 04, 2025: **SYSTEM READY FOR CONNECTION**: Restarted development server, API integration confirmed working, waiting for live Express server on Termius with proper /api/ngrok/bot-command endpoint
- July 04, 2025: **SUCCESSFUL CONNECTION ESTABLISHED**: Updated to custom Ngrok URL (https://sss-control.ngrok.io), resolved port conflicts, established working connection to Express server
- July 04, 2025: **BOT COMMANDS VERIFIED**: Confirmed start/stop commands working perfectly, identified status command needs implementation on Express server

## Rollback System
The project includes a file-based versioning system (`rollbackManager.js`) that:
- Creates timestamped snapshots of scraper scripts before changes
- Allows rollback to specific versions via API endpoints
- Integrates with the process manager for safe version switching
- Provides snapshot metadata (filename, version, creation date, file size)

## Production Features
- PM2 process management for robust deployment
- Slack integration for real-time monitoring alerts
- GPT cost tracking with daily usage reports
- Error logging with stack trace capture
- Multi-platform scraper architecture
- File-based configuration with city-specific setups
- Secure authentication system with session management (24-hour expiry)
- Environment-based password protection using VITE_DASHBOARD_PASSWORD

## Secure Authentication System
The dashboard is protected by an enterprise-grade authentication system featuring:

### Two-Factor Authentication (2FA)
- Primary authentication via email (`admin@supersmartstealz.com`) and secure password
- Secondary authentication via 6-digit codes sent to Gmail SMTP
- Code expires in 5 minutes with visual countdown timer
- Artificial delays to prevent timing attacks

### IP Security & Whitelisting
- Only allows login from pre-approved IP addresses
- Automatic security alerts for unauthorized IP attempts
- Dynamic IP whitelist management through security settings
- Localhost variations automatically whitelisted for development

### Session Management
- Secure HTTP-only session cookies with 24-hour expiry
- Session token validation with anti-hijacking protection
- IP consistency checks to prevent session theft
- Manual session revocation capabilities

### Rate Limiting & Attack Prevention
- Maximum 3 login attempts per IP before 15-minute lockout
- Progressive delays on failed authentication attempts
- Comprehensive security event logging to `logs/auth.log`
- Generic error messages to prevent information disclosure

### Security Features
- bcrypt password hashing with 12 rounds
- CSRF protection with SameSite cookies
- Security headers (CSP, XSS protection, etc.)
- Real-time monitoring of active sessions and blocked IPs

### Administrative Controls
- Security settings page for managing IP whitelist
- Active session monitoring and revocation
- Password change functionality (revokes all sessions)
- Authentication statistics and security metrics

## User Preferences

Preferred communication style: Simple, everyday language.